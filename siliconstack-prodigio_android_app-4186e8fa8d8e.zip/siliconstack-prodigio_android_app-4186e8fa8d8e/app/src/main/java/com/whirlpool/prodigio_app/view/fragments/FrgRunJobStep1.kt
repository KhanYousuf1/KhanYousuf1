package com.whirlpool.prodigio_app.view.fragments

import android.app.Activity
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.card.MaterialCardView
import com.whirlpool.prodigio_app.AppApplication
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.Region
import com.whirlpool.prodigio_app.communication.response.TestSuit
import com.whirlpool.prodigio_app.databinding.FrgRunJobStep1Binding
import com.whirlpool.prodigio_app.databinding.LayoutRunJobCounterHeaderBinding
import com.whirlpool.prodigio_app.databinding.LayoutRunJobNextPreviousButtonsBinding
import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.utils.CustomDialoge
import com.whirlpool.prodigio_app.utils.CustomToast
import com.whirlpool.prodigio_app.view.dialoges.DlgDropDownEnvironment
import com.whirlpool.prodigio_app.view.dialoges.DlgDropDownExecutionMode
import com.whirlpool.prodigio_app.view.dialoges.DlgDropDownPlatform
import com.whirlpool.prodigio_app.view.dialoges.DlgDropDownRegion
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModel
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModelFactory
import org.kodein.di.Kodein
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance

class FrgRunJobStep1 : Fragment(), KodeinAware,
    DlgDropDownExecutionMode.BottomSheetDlgExecutionModeListner,
    DlgDropDownEnvironment.BottomSheetDlgEnvironmentListner {


    private val TAG = FrgExecution::class.java.name

    override val kodein: Kodein by kodein(AppApplication.appContext)

    lateinit var viewModel: ExecutionViewModel


    lateinit var binding: FrgRunJobStep1Binding
    lateinit var counterHeaderBindig: LayoutRunJobCounterHeaderBinding
    lateinit var nextPreviuosButtonsBinding: LayoutRunJobNextPreviousButtonsBinding

    //dlg
    lateinit var bottomDlgExecutionMode: DlgDropDownExecutionMode
    lateinit var bottomDlgEnvironment: DlgDropDownEnvironment



    var ExecutionModeObservable: MutableLiveData<ArrayList<String>> =
        MutableLiveData<ArrayList<String>>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        val factory: ExecutionViewModelFactory by instance() // dependency injection
        viewModel = ViewModelProvider(this, factory).get(ExecutionViewModel::class.java)
        binding = DataBindingUtil.inflate(
            inflater, R.layout.frg_run_job_step_1, container, false
        )
        counterHeaderBindig = binding.llCounterHeader
        nextPreviuosButtonsBinding = binding.llRunJobsButtons
        val rootview = binding.root
        initUI()
        initCounterHeaderAndBottomButtoms()
        registerClicks()
        return rootview
    }


    fun initUI() {

    }

    fun initCounterHeaderAndBottomButtoms() {
        //counter header
        counterHeaderBindig.ivArrowLeft.visibility = View.INVISIBLE
        counterHeaderBindig.ivArrowRight.setOnClickListener {
            doValidate()
        }
        counterHeaderBindig.tvCounter.text = "1"
        counterHeaderBindig.tvHeader.text = "Select Environment"

        //bottom buttons
        nextPreviuosButtonsBinding.cvPrevious.visibility = View.INVISIBLE
        nextPreviuosButtonsBinding.cvPrevious.setOnClickListener {

        }
        nextPreviuosButtonsBinding.cvNext.setOnClickListener {
            doValidate()
        }

    }

    private fun registerClicks() {
        binding.cvExecutionMode.setOnClickListener {
            bottomDlgExecutionMode = DlgDropDownExecutionMode()
            val array = ArrayList<String>()
            array.add("DeviceFarm")
            array.add("Head Spin")
            array.add("Local")
            array.add("Server")
            bottomDlgExecutionMode.items = array
            bottomDlgExecutionMode.mListner = this
            bottomDlgExecutionMode.show(parentFragmentManager, TAG)
        }

        binding.cvEnvironment.setOnClickListener {
            bottomDlgEnvironment = DlgDropDownEnvironment()
            val array = ArrayList<String>()
            array.add("STG")
            array.add("Dev")
            array.add("Prod")
            array.add("QA")
            bottomDlgEnvironment.items = array
            bottomDlgEnvironment.mListner = this
            bottomDlgEnvironment.show(parentFragmentManager, TAG)
        }
    }

    fun doValidate() {
        val exec_mode = binding.etExecutionMode.text.toString()
        val environment = binding.etEnvironment.text.toString()
        val version = binding.etVersionMobileApp.text.toString()
        val textexecName = binding.etTestExeName.text.toString()

        if (exec_mode.isEmpty() || exec_mode.isNullOrBlank()) {
            binding.tvErrorExecutionMode.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorExecutionMode.visibility = View.GONE
        }

        if (environment.isEmpty() || environment.isNullOrBlank()) {
            binding.tvErrorEnvironment.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorEnvironment.visibility = View.GONE
        }
        if (version.isEmpty() || version.isNullOrBlank()) {
            binding.tvErrorVersionMobileApp.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorVersionMobileApp.visibility = View.GONE
        }

        if (textexecName.isEmpty() || textexecName.isNullOrBlank()) {
            binding.tvErrorTestExeName.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorTestExeName.visibility = View.GONE
        }

        checkDuplicateEntry(textexecName,exec_mode)

    }

    fun checkDuplicateEntry(textexecName : String,exec_mode : String ){
        CustomDialoge.showDialog(context as Activity?, "Loading...")

        Coroutines.main {
            val params: HashMap<String?, String?> = HashMap()
            params.put("resource", textexecName)
            params.put("id", "0")
            params.put("type", exec_mode.toString().uppercase())
            val res =
                viewModel.checkForDuplicateForRunJob(params)
            Log.d(TAG, "checkForDuplicateForRunJob: respo : " + params)
            Log.d(TAG, "checkForDuplicateForRunJob: respo : " + res)
            Log.d(TAG, "checkForDuplicateForRunJob: respo : " + res.body())
            CustomDialoge.closeDialog(context as Activity?)
            if (res.isSuccessful) {
                if (res.body().equals("false")) {
                    requireActivity().supportFragmentManager.beginTransaction()
                        .replace(R.id.fl_container, FrgRunJobStep2())
                        .commit()
                } else {
                    CustomToast.showToast("This name is already exist")
                }
            } else {
                CustomToast.showToast(res.message())
            }
        }

        /*val res = viewModel.getAllRegionsByProject(projectTypeId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            regionObservable.value = res.body() as ArrayList<Region>
            Log.d(FrgTestSuiteExecutionTimeTrend.TAG, "getAllRegionsByProject: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            CustomToast.showToast(res.message())
            Log.d(FrgTestSuiteExecutionTimeTrend.TAG, "getAllRegionsByProject: Error : ${res.body()} ")
        }*/


    }

    override fun onExecutionModeSelected(type: Int, item: String) {
        binding.etExecutionMode.setText(item)
        bottomDlgExecutionMode.dismiss()
        binding.tvErrorExecutionMode.visibility = View.GONE
    }

    override fun onExecutionEnvironment(type: Int, item: String) {
        binding.etEnvironment.setText(item)
        bottomDlgEnvironment.dismiss()
        binding.tvErrorEnvironment.visibility = View.GONE
    }


}