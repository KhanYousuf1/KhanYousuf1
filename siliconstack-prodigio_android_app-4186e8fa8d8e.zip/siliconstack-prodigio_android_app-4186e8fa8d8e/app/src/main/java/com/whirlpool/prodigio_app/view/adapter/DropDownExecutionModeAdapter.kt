package com.whirlpool.prodigio_app.view.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.Region
import com.whirlpool.prodigio_app.databinding.ItemDropDownOptionsBinding
import com.whirlpool.prodigio_app.view.dialoges.DlgDropDownExecutionMode
import com.whirlpool.prodigio_app.view.dialoges.DlgDropDownRegion

class DropDownExecutionModeAdapter(
    var items: ArrayList<String>,
    var mListner: DlgDropDownExecutionMode.BottomSheetDlgExecutionModeListner
) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TAG = "DocumentAdapter"
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = DataBindingUtil.inflate<ItemDropDownOptionsBinding>(
            LayoutInflater.from(parent.context), R.layout.item_drop_down_options,
            parent, false
        )
        return ItemHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val viewHolder = holder as ItemHolder
        var item = items.get(position)
        viewHolder.binding.txtProjectType.setText("${item}")
        viewHolder.binding.llMain.setOnClickListener() {
            mListner.onExecutionModeSelected(position,item)
        }

    }

    override fun getItemCount(): Int {
        return items.count()
    }

    inner class ItemHolder(val binding: ItemDropDownOptionsBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }


}