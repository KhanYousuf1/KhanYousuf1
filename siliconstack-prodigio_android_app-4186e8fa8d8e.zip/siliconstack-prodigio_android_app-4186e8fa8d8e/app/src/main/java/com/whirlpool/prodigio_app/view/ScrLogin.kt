package com.whirlpool.prodigio_app.view

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.util.Log
import android.view.View
import androidx.databinding.DataBindingUtil
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.databinding.ActivityScrLoginBinding
import androidx.lifecycle.ViewModelProvider
import com.whirlpool.prodigio_app.AppApplication.Companion.getInstance
import com.whirlpool.prodigio_app.communication.Constant
import com.whirlpool.prodigio_app.storage.UserData
import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.utils.CustomDialoge
import com.whirlpool.prodigio_app.utils.CustomIntent
import com.whirlpool.prodigio_app.utils.CustomToast
import com.whirlpool.prodigio_app.viewmodel.LoginViewModel
import com.whirlpool.prodigio_app.viewmodel.LoginViewModelFactory
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance
import android.content.Intent

import android.content.pm.PackageManager
import com.whirlpool.prodigio_app.BuildConfig
import android.app.Activity

import android.content.Intent.FLAG_ACTIVITY_NEW_TASK


class ScrLogin : AppCompatActivity(), View.OnClickListener, KodeinAware {

    val TAG = ScrLogin::class.java.name

    override val kodein by kodein()
    private val factory: LoginViewModelFactory by instance()

    lateinit var binding: ActivityScrLoginBinding
    lateinit var viewModel: LoginViewModel

    var showPassword: Boolean = false
    val userData = UserData.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = resources.getColor(R.color.white)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            window.statusBarColor = Color.WHITE
        }
        binding = DataBindingUtil.setContentView(this, R.layout.activity_scr_login)
        viewModel = ViewModelProvider(this, factory).get(LoginViewModel::class.java)

        initUI()
        handleClick()
    }

    fun initUI() {
        binding.ivPasswordVisibility.setImageDrawable(resources.getDrawable(R.drawable.ic_password_hide))
    }

    fun handleClick() {
        binding.ivPasswordVisibility.setOnClickListener(this)
        binding.btLogin.setOnClickListener(this)

    }

    @SuppressLint("UseCompatLoadingForDrawables")
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.iv_password_visibility -> {
                if (!showPassword) {
                    showPassword = true
                    binding.ivPasswordVisibility.setImageDrawable(resources.getDrawable(R.drawable.ic_password_show))
                    binding.etPassword.transformationMethod =
                        HideReturnsTransformationMethod.getInstance()
                } else {
                    showPassword = false
                    binding.ivPasswordVisibility.setImageDrawable(resources.getDrawable(R.drawable.ic_password_hide))
                    binding.etPassword.transformationMethod =
                        PasswordTransformationMethod.getInstance()
                }
            }
            R.id.bt_login -> {
                val username = binding.etUsername.text.toString()
                val password = binding.etPassword.text.toString()
                if (viewModel.validate(username, password)) {
                    call_login(username, password)
                }
            }

        }
    }


    fun call_login(username: String, password: String) {
        Coroutines.main {
            CustomDialoge.showDialog(this, Constant.PROGRESS)
            val params: HashMap<String?, String?> = HashMap<String?, String?>()
            params.put("username", username)
            params.put("password", password)
            Log.d(TAG, "call_login: Username : ${username}")
            Log.d(TAG, "call_login: password : ${password}")
            val res = viewModel.login(params)
            CustomDialoge.closeDialog(this)
            Log.d(TAG, "call_login: res : " + res)
            Log.d(TAG, "call_login: res body : " + res.body())
            if (res.isSuccessful) {
                userData?.setRememberMe(binding.cbRememberMe.isChecked)
                userData?.setTOKEN(res.body()?.token)
                CustomIntent.startActivity(this, ScrHome::class.java)

            } else {
                CustomToast.showToast(res.message())
            }
        }
    }

}