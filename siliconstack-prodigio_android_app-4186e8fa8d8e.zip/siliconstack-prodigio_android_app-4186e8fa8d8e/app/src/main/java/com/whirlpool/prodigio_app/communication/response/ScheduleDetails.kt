package com.whirlpool.prodigio_app.communication.response

data class ScheduleDetails(
    val devices: ArrayList<Device>,
    val jobStatus: Int,
    val suiteStatus: Int,
    val testSuiteId: Int,
    val testSuiteName: String
)

data class Device(
    val cases: ArrayList<Case>,
    val templateName: String
)

data class Case(
    val caseStatus: Int,
    val testCaseId: Int,
    val testCaseName: String
)
