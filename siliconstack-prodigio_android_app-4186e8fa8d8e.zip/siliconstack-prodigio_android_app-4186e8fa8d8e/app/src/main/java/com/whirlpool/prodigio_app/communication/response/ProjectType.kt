package com.whirlpool.prodigio_app.communication.response

data class ProjectType (
    val projectTypeId: Int,
    val createdOn: String,
    val isDeleted: Boolean,
    val projectTypeDesc: String,
    val projectTypeName: String,
    val modifiedOn: String,
    val createdBy: Int,
    val modifiedBy: Int
)