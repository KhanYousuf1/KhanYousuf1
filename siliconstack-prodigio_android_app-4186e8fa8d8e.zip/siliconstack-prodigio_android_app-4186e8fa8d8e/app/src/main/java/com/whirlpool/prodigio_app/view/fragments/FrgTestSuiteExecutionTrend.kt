package com.whirlpool.prodigio_app.view.fragments

import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.whirlpool.prodigio_app.AppApplication
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.databinding.FrgTestSuiteExecutionTrendBinding
import org.kodein.di.Kodein
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.anychart.AnyChart
import com.anychart.chart.common.dataentry.DataEntry
import com.anychart.chart.common.dataentry.ValueDataEntry
import com.anychart.charts.Cartesian
import com.anychart.data.Set
import com.anychart.enums.Orientation
import com.anychart.enums.ScaleStackMode
import com.anychart.scales.Linear
import com.google.gson.Gson
import com.whirlpool.prodigio_app.communication.response.*

import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.utils.CustomDialoge
import com.whirlpool.prodigio_app.utils.CustomToast
import com.whirlpool.prodigio_app.view.dialoges.*
import com.whirlpool.prodigio_app.viewmodel.*
import java.lang.reflect.Array
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class FrgTestSuiteExecutionTrend : Fragment(), KodeinAware,
    DlgDropDownProjectType.BottomSheetDlgProjectTypeListner,
    DlgDropDownRegion.BottomSheetDlgRegionListner,
    DlgDropDownBrand.BottomSheetDlgBrandListner,
    DlgDropDownProductName.BottomSheetDlgProductNameListner,
    DlgDropDownTestSuite.BottomSheetDlgTestSuiteListner,
    DlgDropDownPlatform.BottomSheetDlgPlatformListner,
    DlgDropDownENV.BottomSheetDlgENVListner,
    DlgFromDate.BottomSheetDlgFromDateListner,
    DlgToDate.BottomSheetDlgToDateListner,
    DlgDropDownAll.BottomSheetDlgAllListner {

    companion object {
        private const val TAG = "FrgTestSuiteExecutionTr"
    }

    override val kodein: Kodein by kodein(AppApplication.appContext)

    lateinit var viewModel: DashboardGraphViewModel
    lateinit var binding: FrgTestSuiteExecutionTrendBinding

    //bottomSheetDialoge
    lateinit var bottomDlgProjectType: DlgDropDownProjectType
    lateinit var bottomDlgRegion: DlgDropDownRegion
    lateinit var bottomDlgBrand: DlgDropDownBrand
    lateinit var bottomDlgProductName: DlgDropDownProductName
    lateinit var bottomDlgTestSuite: DlgDropDownTestSuite
    lateinit var bottomDlgPlatform: DlgDropDownPlatform
    lateinit var bottomDlgEnv: DlgDropDownENV
    lateinit var bottomDlgAll: DlgDropDownAll
    lateinit var bottomDlgFromDate: DlgFromDate
    lateinit var bottomDlgToDate: DlgToDate

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val factory: DashboardGraphViewModelFactory by instance()  // dependency injection
        viewModel = ViewModelProvider(this, factory).get(DashboardGraphViewModel::class.java)

        binding = DataBindingUtil.inflate(
            inflater, R.layout.frg_test_suite_execution_trend, container, false
        )
        val rootview = binding.root
        init()
        registerClicks()
        return rootview
    }

    private fun init() {

        binding.anyChartView.visibility = View.GONE
        binding.linearLayoutGraphInfo.visibility = View.GONE
        binding.linearLayoutMapError.visibility = View.VISIBLE
        Coroutines.main {
            getAllProjects()
//            getAllUsers()
        }
        Observe()
        initBottomDialoge()
    }


    fun setGraphData() {

        binding.anyChartView.visibility = View.VISIBLE
        binding.linearLayoutGraphInfo.visibility = View.VISIBLE
        binding.linearLayoutMapError.visibility = View.GONE
        val cartesian: Cartesian = AnyChart.cartesian()
        cartesian.animation(true)
        cartesian.background("#FAFAFA")
        cartesian.title("")

        cartesian.yScale().stackMode(ScaleStackMode.VALUE)

        val scalesLinear: Linear = Linear.instantiate()
        scalesLinear.minimum(0.0)
//        scalesLinear.maximum(5000.0)
//        scalesLinear.ticks("{ interval: 500 }")

        val extraXAxis = cartesian.xAxis(1.0)
        extraXAxis.orientation(Orientation.LEFT)
            .scale(scalesLinear)
        extraXAxis.labels()
            .padding(0.0, 0.0, 0.0, 5.0)
            .format("{%Value}")

        val extraYAxis = cartesian.yAxis(1.0)
        extraYAxis.orientation(Orientation.BOTTOM)
            .scale(scalesLinear)

        var labels = extraYAxis.labels();
        labels.enabled(false);


        val data: MutableList<DataEntry> = ArrayList()

        var maxCount = 6
        if (getDashboardCountsForTestExecutionTrendsObservable.value != null) {
            getDashboardCountsForTestExecutionTrendsObservable.value!!.map {
                data.add(CustomDataEntry(it.date, it.total, it.unknown, it.failed, it.passed))
                if (it.total!! > maxCount) {
                    maxCount = it.total!!
                }
            }
        } else {
            Log.d(TAG, "setGraphData: ")
        }
        scalesLinear.maximum(maxCount)
        scalesLinear.ticks("{ interval: ${maxCount / 6} }")
        /*data.add(CustomDataEntry("P1", 96.5, 440, 1200, 1600))
        data.add(CustomDataEntry("P2", 77.1, 794, 1124, 1724))
        data.add(CustomDataEntry("P3", 73.2, 726, 1006, 1806))
        data.add(CustomDataEntry("P4", 61.1, 441, 1021, 1621))
        data.add(CustomDataEntry("P5", 70.0, 800, 1500, 1700))
        data.add(CustomDataEntry("P6", 60.7, 507, 1007, 1907))
        data.add(CustomDataEntry("P7", 62.1, 401, 921, 1821))
        data.add(CustomDataEntry("P8", 75.1, 671, 971, 1671))
        data.add(CustomDataEntry("P9", 80.0, 980, 1080, 1880))
        data.add(CustomDataEntry("P10", 54.1, 541, 1041, 1641))
        data.add(CustomDataEntry("P11", 51.3, 813, 1113, 1913))
        data.add(CustomDataEntry("P12", 59.1, 691, 1091, 1691))
*/
        val set = Set.instantiate()
        set.data(data)
        val lineData = set.mapAs("{ x: 'x', value: '' }")
        val column0Data = set.mapAs("{ x: 'x', value: 'value1' }")
        val column1Data = set.mapAs("{ x: 'x', value: 'value2' }")
        val column2Data = set.mapAs("{ x: 'x', value: 'value2' }")
        val column3Data = set.mapAs("{ x: 'x', value: 'value3' }")
        val column4Data = set.mapAs("{ x: 'x', value: 'value4' }")
        cartesian.addSeries(set)
//        var label = cartesian.get

//        cartesian.crosshair(true)
//        val line = cartesian.line(lineData)
//        line.yScale(scalesLinear)
        cartesian.column(column1Data).color("#B7EB8F").labels("Total")
        cartesian.column(column2Data).color("#FFE58F").labels("Unknown")
        cartesian.column(column3Data).color("#91D5FF").labels("Failed")
        cartesian.column(column4Data).color("#1890FF").labels("Passed")

        binding.anyChartView.setChart(cartesian)
    }


    private class CustomDataEntry internal constructor(
        x: kotlin.String?,
        value1: Number?,
        value2: Number?,
        value3: Number?,
        value4: Number?,
    ) :
        ValueDataEntry(x, value1) {
        init {
            setValue("value1", value1)
            setValue("value2", value2)
            setValue("value3", value3)
            setValue("value4", value4)
        }
    }


    fun initBottomDialoge() {


    }

    fun Observe() {
        projectTypesObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgProjectType = DlgDropDownProjectType(it, this)
                bottomDlgProjectType.mListner = this
            }
        })

        regionObservable.observe(requireActivity(), {
            it?.let {
                        bottomDlgRegion = DlgDropDownRegion()
                        bottomDlgRegion.items = it
                        bottomDlgRegion.mListner = this

                if (bottomDlgRegion != null && !bottomDlgRegion.isVisible) {
                    bottomDlgRegion.show(parentFragmentManager, TAG)
                }
            }
        })

        brandObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgBrand = DlgDropDownBrand()
                bottomDlgBrand.items = it
                bottomDlgBrand.mListner = this
                if (bottomDlgBrand != null && !bottomDlgBrand.isVisible) {
                    bottomDlgBrand.show(parentFragmentManager, TAG)
                }
            }
        })
        productNameObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgProductName = DlgDropDownProductName()
                bottomDlgProductName.items = it
                bottomDlgProductName.mListner = this
                if (bottomDlgProductName != null && !bottomDlgProductName.isVisible) {
                    bottomDlgProductName.show(parentFragmentManager, TAG)
                }
            }
        })
        testSuitObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgTestSuite = DlgDropDownTestSuite()
                bottomDlgTestSuite.items = it
                bottomDlgTestSuite.mListner = this
                if (bottomDlgTestSuite != null && !bottomDlgTestSuite.isVisible) {
                    bottomDlgTestSuite.show(parentFragmentManager, TAG)
                }
            }
        })
        platformObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgPlatform = DlgDropDownPlatform()
                bottomDlgPlatform.items = it
                bottomDlgPlatform.mListner = this
                if (bottomDlgPlatform != null && !bottomDlgPlatform.isVisible) {
                    bottomDlgPlatform.show(parentFragmentManager, TAG)
                }
            }
        })

        envObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgEnv = DlgDropDownENV()
                bottomDlgEnv.items = it
                bottomDlgEnv.mListner = this
                if (bottomDlgEnv != null && !bottomDlgEnv.isVisible) {
                    bottomDlgEnv.show(parentFragmentManager, TAG)
                }
            }
        })

        userObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgAll = DlgDropDownAll()
                bottomDlgAll.items = it
                bottomDlgAll.mListner = this
                if (bottomDlgAll != null && !bottomDlgAll.isVisible) {
                    bottomDlgAll.show(parentFragmentManager, TAG)
                }
            }
        })

        getDashboardCountsForTestExecutionTrendsObservable.observe(requireActivity(), {
            it?.let {
                Log.d(TAG, "Observe: SET DATA TO GRAPH")
                setGraphData()
            }
        })
    }

    var projectTypesObservable: MutableLiveData<ArrayList<ProjectType>> =
        MutableLiveData<ArrayList<ProjectType>>()
    var regionObservable: MutableLiveData<ArrayList<Region>> = MutableLiveData<ArrayList<Region>>()
    var brandObservable: MutableLiveData<ArrayList<Brand>> = MutableLiveData<ArrayList<Brand>>()
    var productNameObservable: MutableLiveData<ArrayList<ProductName>> =
        MutableLiveData<ArrayList<ProductName>>()
    var testSuitObservable: MutableLiveData<ArrayList<TestSuit>> =
        MutableLiveData<ArrayList<TestSuit>>()
    var platformObservable: MutableLiveData<ArrayList<Platform>> =
        MutableLiveData<ArrayList<Platform>>()
    var envObservable: MutableLiveData<ArrayList<String>> = MutableLiveData<ArrayList<String>>()
    var userObservable: MutableLiveData<ArrayList<User>> = MutableLiveData<ArrayList<User>>()
    var getDashboardCountsForTestExecutionTrendsObservable: MutableLiveData<List<DashboardGraphs.GetDashboardCountsForTestExecutionTrendsResponse>> =
        MutableLiveData<List<DashboardGraphs.GetDashboardCountsForTestExecutionTrendsResponse>>()

    suspend fun getAllProjects() {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllProjectType()
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            projectTypesObservable.value = res.body() as ArrayList<ProjectType>
            Log.d(Companion.TAG, "getAllProjects: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllProjects: Error : ")
        }
    }


    suspend fun getAllRegionsByProject(projectTypeId: Int) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllRegionsByProject(projectTypeId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            regionObservable.value = res.body() as ArrayList<Region>
            Log.d(Companion.TAG, "getAllRegionsByProject: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllRegionsByProject: Error : ${res.body()} ")
        }
    }

    suspend fun getAllBrands(regionId: Int) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllBrands(regionId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            brandObservable.value = res.body() as ArrayList<Brand>
            Log.d(Companion.TAG, "getAllBrands: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllBrands: Error : ${res.body()} ")
        }
    }


    suspend fun getAllProductNames(
        brandId: Int,
        projectTypeId: Int,
        regionId: Int
    ) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllProductNames(brandId, projectTypeId, regionId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            productNameObservable.value = res.body() as ArrayList<ProductName>
            Log.d(Companion.TAG, "getAllProductNames: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllProductNames: Error : ${res.body()} ")
        }
    }


    suspend fun getTestSuiteNameByProjectName(projectName: String) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getTestSuiteNameByProjectName(projectName)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            testSuitObservable.value = res.body() as ArrayList<TestSuit>
            Log.d(Companion.TAG, "getTestSuiteNameByProjectName: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getTestSuiteNameByProjectName: Error : ${res.body()} ")
        }
    }

    suspend fun getAllPlatform(projectTypeId: Int) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllPlatform(projectTypeId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            platformObservable.value = res.body() as ArrayList<Platform>
            Log.d(Companion.TAG, "getAllPlatform: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllPlatform: Error : ${res.body()} ")
        }
    }

    suspend fun getAllUsers() {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllUsers()
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            userObservable.value = res.body() as ArrayList<User>
            Log.d(Companion.TAG, "getAllUsers: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllUsers: Error : ${res.body()} ")
        }
    }


    fun registerClicks() {
        binding.llProjectType.setOnClickListener {
            if (this::bottomDlgProjectType.isInitialized) {
                if (bottomDlgProjectType != null && !bottomDlgProjectType.isVisible) {
                    bottomDlgProjectType.show(parentFragmentManager, TAG)
                }
            }
        }
        binding.llRegion.setOnClickListener {
            if (selectedProjectType != null) {
                binding.tvErrorProjectType.visibility = View.GONE
                Coroutines.main {
                    getAllRegionsByProject(selectedProjectType!!.projectTypeId)
                }
            } else {
                binding.tvErrorProjectType.visibility = View.VISIBLE
            }
//            bottomDlgRegion.show(parentFragmentManager, TAG)
        }
        binding.cvBrand.setOnClickListener {
            if (selectedRegion != null) {
                binding.tvErrorRegion.visibility = View.GONE
                Coroutines.main {
                    getAllBrands(selectedRegion!!.regionId)
                }
            } else {
                binding.tvErrorRegion.visibility = View.VISIBLE
            }
//            bottomDlgBrand.show(parentFragmentManager, TAG)
        }
        binding.llProoductName.setOnClickListener {
            if (selectedProjectType != null && selectedBrand != null && selectedRegion != null) {
                binding.tvErrorProjectType.visibility = View.GONE
                binding.tvErrorRegion.visibility = View.GONE
                binding.tvErrorBrand.visibility = View.GONE
                Coroutines.main {
                    getAllProductNames(
                        selectedBrand!!.brandId,
                        selectedProjectType!!.projectTypeId,
                        selectedRegion!!.regionId
                    )
                }
            } else {
                if (selectedProjectType == null) {
                    binding.tvErrorProjectType.visibility = View.VISIBLE
                }
                if (selectedRegion == null) {
                    binding.tvErrorRegion.visibility = View.VISIBLE
                }
                if (selectedBrand == null) {
                    binding.tvErrorBrand.visibility = View.VISIBLE
                }
            }
//            bottomDlgRegion.show(parentFragmentManager, TAG)
        }
        binding.llTestSuite.setOnClickListener {
            if (selectedProductName != null) {
                binding.tvErrorProductName.visibility = View.GONE
                Coroutines.main {
                    getTestSuiteNameByProjectName(selectedProductName!!.projectName)
                }
            } else {
                binding.tvErrorProductName.visibility = View.VISIBLE
            }
        }
        binding.llPlatform.setOnClickListener {
            if (selectedProjectType != null) {
                binding.tvErrorProjectType.visibility = View.GONE
                Coroutines.main {
                    getAllPlatform(selectedProjectType!!.projectTypeId)
                }
            } else {
                binding.tvErrorProjectType.visibility = View.VISIBLE
            }
        }

        binding.llEnv.setOnClickListener {
            var list: ArrayList<String> = arrayListOf()
            list.add("ENV")
            list.add("STG")
            list.add("DEV")
            list.add("Prod")
            list.add("QA")
            envObservable.value = list
//            bottomDlgEnv.show(parentFragmentManager, TAG)
        }
        binding.llUsers.setOnClickListener {
            Coroutines.main {
                getAllUsers()
            }
//            bottomDlgAll.show(parentFragmentManager, TAG)
        }
        binding.llFrom.setOnClickListener {
            var calendarMax = Calendar.getInstance()
            bottomDlgFromDate = DlgFromDate(this, calendarMax, null)
            bottomDlgFromDate.show(parentFragmentManager, TAG)
//            bottomDlgFromDate.setMaxDate(calendar.time.time)
        }
        binding.llTo.setOnClickListener {
            if (calendarFrom != null) {
                binding.tvErrorFromDate.visibility = View.GONE
                var calendarMax = Calendar.getInstance()
                bottomDlgToDate = DlgToDate(this, calendarMax, calendarFrom)
                bottomDlgToDate.show(parentFragmentManager, TAG)
            } else {
                binding.tvErrorFromDate.visibility = View.VISIBLE
            }
//            bottomDlgFromDate.setMaxDate(calendar.time.time)
        }

        binding.btRun.setOnClickListener {
            doValidate()
//            Coroutines.main {
//                getDashboardCountsForTestExecutionTrendsRequest()
//            }
        }
    }

    // run button validate
    fun doValidate() {
        val project_type = binding.etProjectType.text.toString()
        val region = binding.etRegion.text.toString()
        val brand = binding.etBrand.text.toString()
        val product_name = binding.etProductName.text.toString()
        val test_suite = binding.etTestSuite.text.toString()
        val platform = binding.etPlatform.text.toString()
        val env = binding.etEnv.text.toString()
        val all = binding.etAll.text.toString()
        val fromDate = binding.etFromDate.text.toString()
        val toDate = binding.etToDate.text.toString()

        if (project_type.isEmpty() || project_type.isNullOrBlank()) {
            binding.tvErrorProjectType.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorProjectType.visibility = View.GONE
        }

        if (region.isEmpty() || region.isNullOrBlank()) {
            binding.tvErrorRegion.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorRegion.visibility = View.GONE
        }

        if (brand.isEmpty() || brand.isNullOrBlank()) {
            binding.tvErrorBrand.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorBrand.visibility = View.GONE
        }

        if (product_name.isEmpty() || product_name.isNullOrBlank()) {
            binding.tvErrorProductName.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorProductName.visibility = View.GONE
        }

        if (test_suite.isEmpty() || test_suite.isNullOrBlank()) {
            binding.tvErrorSuiteName.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorSuiteName.visibility = View.GONE
        }

        if (platform.isEmpty() || platform.isNullOrBlank()) {
            binding.tvErrorPlatform.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorPlatform.visibility = View.GONE
        }

        if (env.isEmpty() || env.isNullOrBlank()) {
            binding.tvErrorEnv.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorEnv.visibility = View.GONE
        }

        if (all.isEmpty() || all.isNullOrBlank()) {
            binding.tvErrorAll.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorAll.visibility = View.GONE
        }

        if (fromDate.isEmpty() || fromDate.isNullOrBlank()) {
            binding.tvErrorFromDate.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorFromDate.visibility = View.GONE
        }

        if (toDate.isEmpty() || toDate.isNullOrBlank()) {
            binding.tvErrorToDate.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorToDate.visibility = View.GONE
        }

        var getDashboardCountsForTestExecutionTrendsRequest =
            DashboardGraphs.GetDashboardCountsForTestExecutionTrendsRequest()
        getDashboardCountsForTestExecutionTrendsRequest.projectTypeId =
            selectedProjectType!!.projectTypeId
        getDashboardCountsForTestExecutionTrendsRequest.regionId = selectedRegion!!.regionId
        getDashboardCountsForTestExecutionTrendsRequest.brandId = "${selectedBrand!!.brandId}"
        getDashboardCountsForTestExecutionTrendsRequest.projectName =
            "${selectedProductName!!.projectName}"
        getDashboardCountsForTestExecutionTrendsRequest.testSuiteName =
            "${selectedTestSuite!!.testSuiteName}"
        getDashboardCountsForTestExecutionTrendsRequest.testSuiteId =
            selectedTestSuite!!.testSuiteId
        getDashboardCountsForTestExecutionTrendsRequest.profileId = 0
        getDashboardCountsForTestExecutionTrendsRequest.platformId =
            "${selectedPlatform!!.platformId}"
        getDashboardCountsForTestExecutionTrendsRequest.environment = selectedEnv!!
        getDashboardCountsForTestExecutionTrendsRequest.startDate =
            "${SimpleDateFormat("yyyy-MM-dd").format(calendarFrom!!.time.time)}"
        getDashboardCountsForTestExecutionTrendsRequest.endDate =
            "${SimpleDateFormat("yyyy-MM-dd").format(calendarTo!!.time.time)}"

//        CustomToast.showToast("Call Filter API")
        Coroutines.main {
            getDashboardCountsForTestExecutionTrendsRequest(
                getDashboardCountsForTestExecutionTrendsRequest
            )
        }
    }

    suspend fun getDashboardCountsForTestExecutionTrendsRequest(
        getDashboardCountsForTestExecutionTrendsRequest:
        DashboardGraphs.GetDashboardCountsForTestExecutionTrendsRequest
    ) {
        Log.d(TAG, "getDashboardCountsForTestExecutionTrendsRequest: API Called")
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        /*var getDashboardCountsForTestExecutionTrendsRequest =
            DashboardGraphs.GetDashboardCountsForTestExecutionTrendsRequest()
        getDashboardCountsForTestExecutionTrendsRequest.projectTypeId = 2
        getDashboardCountsForTestExecutionTrendsRequest.regionId = 1
        getDashboardCountsForTestExecutionTrendsRequest.brandId = "1"
        getDashboardCountsForTestExecutionTrendsRequest.projectName = "Minerva 7"
        getDashboardCountsForTestExecutionTrendsRequest.testSuiteName = "Reg_WP_Minerva7Single_Add_Verify_Delete_BakeFavoriteCycle"
        getDashboardCountsForTestExecutionTrendsRequest.testSuiteId = 46
        getDashboardCountsForTestExecutionTrendsRequest.profileId = 0
        getDashboardCountsForTestExecutionTrendsRequest.platformId = "1"
        getDashboardCountsForTestExecutionTrendsRequest.environment = "STG"
        getDashboardCountsForTestExecutionTrendsRequest.startDate = "2020-03-16"
        getDashboardCountsForTestExecutionTrendsRequest.endDate = "2020-03-20"
*/
        var gson = Gson()
        var js = gson.toJson(getDashboardCountsForTestExecutionTrendsRequest)

        Log.d(TAG, "getDashboardCountsForTestExecutionTrendsRequest: ${js}")
        val res = viewModel.getDashboardCountsForTestExecutionTrends(
            getDashboardCountsForTestExecutionTrendsRequest
        )
        if (res != null) {
            if (res.isSuccessful) {
                CustomDialoge.closeDialog(context as Activity?)
                getDashboardCountsForTestExecutionTrendsObservable.value =
                    res.body() as List<DashboardGraphs.GetDashboardCountsForTestExecutionTrendsResponse>
                Log.d(TAG, "getDashboardCountsForTestExecutionTrendsRequest: ${res.body()}")
            } else {
                CustomDialoge.closeDialog(context as Activity?)
                CustomToast.showToast(res.message())
                Log.d(
                    TAG,
                    "getDashboardCountsForTestExecutionTrendsRequest: Error : ${res.body()} "
                )
            }
        } else {
            CustomToast.showToast("Something went wrong...")
        }
    }
    //bottom dialoe interface ==============================================================================================================

    var selectedProjectType: ProjectType? = null
    var selectedRegion: Region? = null
    var selectedBrand: Brand? = null
    var selectedProductName: ProductName? = null
    var selectedTestSuite: TestSuit? = null
    var selectedPlatform: Platform? = null
    var selectedEnv: String? = null
    var selectedUser: User? = null

    override fun onProjectTypeSelected(type: Int) {
        selectedProjectType = projectTypesObservable.value!!.get(type)
        binding.etProjectType.setText(selectedProjectType!!.projectTypeName)
        bottomDlgProjectType.dismiss()
    }

    override fun onRegionSelected(type: Int) {
        selectedRegion = regionObservable.value!!.get(type)
        binding.etRegion.setText(selectedRegion!!.regionName)
        bottomDlgRegion.dismiss()
    }

    override fun onBrandSelected(type: Int) {
        selectedBrand = brandObservable.value!!.get(type)
        binding.etBrand.setText(selectedBrand!!.brandName)
        bottomDlgBrand.dismiss()
    }

    override fun onProductNameSelected(type: Int) {
        selectedProductName = productNameObservable.value!!.get(type)
        binding.etProductName.setText(selectedProductName!!.projectName)
        bottomDlgProductName.dismiss()
    }

    override fun onTestSuiteSelected(type: Int) {
        selectedTestSuite = testSuitObservable.value!!.get(type)
        binding.etTestSuite.setText(selectedTestSuite!!.testSuiteName)
        bottomDlgTestSuite.dismiss()
    }

    override fun onPlatformSelected(type: Int) {
        selectedPlatform = platformObservable.value!!.get(type)
        binding.etPlatform.setText(selectedPlatform!!.platformName)
        bottomDlgPlatform.dismiss()
    }

    override fun onENVSelected(type: Int) {
        selectedEnv = envObservable.value!!.get(type)
        binding.etEnv.setText(selectedEnv!!)
        bottomDlgEnv.dismiss()
    }

    override fun onAllSelected(type: Int) {
        selectedUser = userObservable.value!!.get(type)
        binding.etAll.setText(selectedUser!!.userName)
        bottomDlgAll.dismiss()
    }

    override fun onFromDateSelected(date: String, calendar: Calendar) {
        calendarFrom = calendar
        binding.etFromDate.setText("${date}")
    }

    override fun onToDateSelected(date: String, calendar: Calendar) {
        calendarTo = calendar
        binding.etToDate.setText("${date}")
    }

    var calendarFrom: Calendar? = null
    var calendarTo: Calendar? = null
}

