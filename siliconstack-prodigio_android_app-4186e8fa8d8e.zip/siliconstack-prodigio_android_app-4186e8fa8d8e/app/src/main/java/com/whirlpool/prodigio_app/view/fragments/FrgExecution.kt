package com.whirlpool.prodigio_app.view.fragments

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.github.mikephil.charting.animation.Easing
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.ColorTemplate
import com.whirlpool.prodigio_app.AppApplication
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.ExecutionDashboardCount
import com.whirlpool.prodigio_app.databinding.FrgExecutionBinding
import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.utils.CustomIntent
import com.whirlpool.prodigio_app.utils.CustomToast
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModel
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModelFactory
import org.kodein.di.Kodein
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance

import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.formatter.PercentFormatter
import com.github.mikephil.charting.utils.MPPointF
import com.whirlpool.prodigio_app.communication.Constant
import com.whirlpool.prodigio_app.communication.response.ExecutionInProgress
import com.whirlpool.prodigio_app.storage.UserData
import com.whirlpool.prodigio_app.utils.CustomDialoge
import com.whirlpool.prodigio_app.view.*
import com.whirlpool.prodigio_app.view.adapter.ExecutionInProgressAdapter
import com.whirlpool.prodigio_app.view.adapter.FrgExecutionInprogressDashAdapter

class FrgExecution() : Fragment(), View.OnClickListener, KodeinAware {

    private val TAG = FrgExecution::class.java.name

    override val kodein: Kodein by kodein(AppApplication.appContext)

    lateinit var viewModel: ExecutionViewModel


    lateinit var adapter: FrgExecutionInprogressDashAdapter

    var list = ArrayList<ExecutionInProgress>()
    lateinit var binding: FrgExecutionBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        val factory: ExecutionViewModelFactory by instance() // dependency injection
        viewModel = ViewModelProvider(this, factory).get(ExecutionViewModel::class.java)

        binding = DataBindingUtil.inflate(
            inflater, R.layout.frg_execution, container, false
        )
        val rootview = binding.root
        init()
        registerClicks()
        return rootview
    }

    fun init() {
        val layoutManager =
            LinearLayoutManager(context, RecyclerView.VERTICAL, false)
        adapter =
            FrgExecutionInprogressDashAdapter(
                requireContext()
            )
        binding.rvInprogress.layoutManager = layoutManager
        binding.rvInprogress.adapter = adapter
        binding.rvInprogress.adapter?.notifyDataSetChanged()

        binding.pieChartExecution.setUsePercentValues(true);
        binding.pieChartExecution.getDescription().setEnabled(false);
        binding.pieChartExecution.setExtraOffsets(5F, 5F, 5F, 5F);
        binding.pieChartExecution.setDragDecelerationFrictionCoef(0.95f);
        binding.pieChartExecution.setCenterTextTypeface(
            ResourcesCompat.getFont(
                requireContext(),
                R.font.open_sans_semibold
            )
        )
        binding.pieChartExecution.setCenterText(generateCenterSpannableText());
        binding.pieChartExecution.setDrawHoleEnabled(true);
        binding.pieChartExecution.setHoleColor(Color.WHITE);
        binding.pieChartExecution.setTransparentCircleColor(Color.WHITE);
        binding.pieChartExecution.setTransparentCircleAlpha(110);
        binding.pieChartExecution.setHoleRadius(50f);
        binding.pieChartExecution.setTransparentCircleRadius(53f);
        binding.pieChartExecution.setDrawCenterText(true);
        binding.pieChartExecution.setRotationAngle(0F);
        binding.pieChartExecution.setRotationEnabled(true);
        binding.pieChartExecution.setHighlightPerTapEnabled(true);
        binding.pieChartExecution.animateY(1400, Easing.EaseInOutQuad);
        var l = binding.pieChartExecution.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        l.setOrientation(Legend.LegendOrientation.VERTICAL);
        l.setDrawInside(false);
        l.setXEntrySpace(7f);
        l.setYEntrySpace(0f);
        l.setYOffset(0f)
        l.isEnabled = false
        // entry label styling


//                startTimmer()
    }

    fun startTimmer() {
        val timer = object : CountDownTimer(20000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                var diff = millisUntilFinished
                val secondsInMilli: Long = 1000
                val minutesInMilli = secondsInMilli * 60
                val hoursInMilli = minutesInMilli * 60
                val daysInMilli = hoursInMilli * 24

                val elapsedDays = diff / daysInMilli
                diff %= daysInMilli

                val elapsedHours = diff / hoursInMilli
                diff %= hoursInMilli

                val elapsedMinutes = diff / minutesInMilli
                diff %= minutesInMilli

                val elapsedSeconds = diff / secondsInMilli

                if (hoursInMilli > 1) {
                    binding.textViewHours1.text =
                        "$elapsedDays days $elapsedHours hs $elapsedMinutes min $elapsedSeconds sec"
                    binding.textViewHours1.text =
                        "$elapsedDays days $elapsedHours hs $elapsedMinutes min $elapsedSeconds sec"
                } else {
                    binding.textViewHours1.text = "0"
                    binding.textViewHours1.text = "$elapsedHours"
                }

//                binding.c = "$elapsedDays days $elapsedHours hs $elapsedMinutes min $elapsedSeconds sec"

            }

            override fun onFinish() {}
        }
        timer.start()
    }

    private fun generateCenterSpannableText(): SpannableString? {
        val s = SpannableString("All Jobs")
        s.setSpan(RelativeSizeSpan(1.7f), 0, s.length, 0)
        s.setSpan(StyleSpan(Typeface.NORMAL), 0, s.length, 0)
        s.setSpan(ForegroundColorSpan(Color.parseColor("#096DD9")), 0, s.length, 0)
//        s.setSpan(RelativeSizeSpan(.8f), 14, s.length - 15, 0)
//        s.setSpan(StyleSpan(Typeface.ITALIC), s.length - 14, s.length, 0)
//        s.setSpan(ForegroundColorSpan(ColorTemplate.getHoloBlue()), 0, s.length, 0)
        return s
    }


    fun setData(inProgressPercent: Float, schedulePercent: Float, completedPercent: Float) {

        var entries: ArrayList<PieEntry> = arrayListOf()
        var colors: ArrayList<Int> = arrayListOf()
        entries.add(PieEntry((inProgressPercent), 0))
        entries.add(PieEntry((schedulePercent), 1))
        entries.add(PieEntry((completedPercent), 2))


        colors.add(Color.parseColor("#95DE64"))
        colors.add(Color.parseColor("#FF9C6E"))
        colors.add(Color.parseColor("#BFBFBF"))


        var dataSet = PieDataSet(entries, "")
        dataSet.setDrawIcons(false)
        dataSet.sliceSpace = 3f
        dataSet.iconsOffset = MPPointF(0F, 40F)
        dataSet.selectionShift = 5f
        dataSet.setDrawValues(false)



        dataSet.setColors(colors);
        Log.d(TAG, "setData: entryCount :- ${dataSet.entryCount}")
        Log.d(TAG, "setData: axisDependency :- ${dataSet.axisDependency}")
        Log.d(TAG, "setData: colors :- ${dataSet.colors.size}")
        val data = PieData(dataSet)
        data.setValueFormatter(PercentFormatter())
        data.setValueTextSize(14f)
        data.setValueTextColor(Color.BLACK)
        binding.pieChartExecution.setData(data)
        binding.pieChartExecution.highlightValues(null);
        binding.pieChartExecution.invalidate();
    }

    fun registerClicks() {
        binding.cvRunJob.setOnClickListener(this)
        binding.cvInProress.setOnClickListener(this)
        binding.cvScheduled.setOnClickListener(this)
        binding.cvHistory.setOnClickListener(this)
        binding.llLogout.setOnClickListener {
            val userData = UserData.getInstance()
            userData?.clearData()
            CustomIntent.startActivity(requireActivity(), ScrLogin::class.java)
        }
    }

    override fun onResume() {
        super.onResume()
        callApi()
    }

    fun callApi() {
        getExecutionDashboardCount()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun getExecutionDashboardCount() {
        Coroutines.main {
            CustomDialoge.showDialog(context as Activity?, "Loading...")
            val res = viewModel.getExecutionDashbaordCount()
            Log.d(TAG, "getExecutionDashboardCount: res : $res")
            Log.d(TAG, "getExecutionDashboardCount: res : ${res.body()}")

            if (res.isSuccessful) {
                CustomDialoge.closeDialog(context as Activity?)
                val dashboardCount = res.body() as ExecutionDashboardCount
//                binding.tvAllJobsCount.text = dashboardCount.allJob.toString()
                binding.tvInProgressCount.text = dashboardCount.jobInProgress.toString()
                binding.tvInScheduledCount.text = dashboardCount.jobSchedule.toString()
                binding.tvHistoryCount.text = dashboardCount.jobCompleted.toString()

                adapter.setList(dashboardCount.executionHeadeList)
                Log.d(
                    TAG,
                    "getExecutionDashboardCount: TOTAL COUNTS - ${dashboardCount.executionHeadeList.size}"
                )
                /*var inProgressPercent: Double =
                    dashboardCount.jobInProgress.toDouble() / dashboardCount.allJob.toDouble() * 100
                var schedulePercent: Double =
                    dashboardCount.jobSchedule.toDouble() / dashboardCount.allJob.toDouble() * 100
                var completedPercent: Double =
                    dashboardCount.jobCompleted.toDouble() / dashboardCount.allJob.toLong() * 100

                Log.d(TAG, "getExecutionDashboardCount--: All Jobs -- ${dashboardCount.allJob}")
                Log.d(
                    TAG,
                    "getExecutionDashboardCount--: job InProgress -- ${dashboardCount.jobInProgress}"
                )
                Log.d(
                    TAG,
                    "getExecutionDashboardCount--: job Schedule -- ${dashboardCount.jobSchedule}"
                )
                Log.d(
                    TAG,
                    "getExecutionDashboardCount--: job Completed -- ${dashboardCount.jobCompleted}"
                )
                Log.d(
                    TAG,
                    "getExecutionDashboardCount--: inProgrss Percent -- ${inProgressPercent}"
                )
                Log.d(TAG, "getExecutionDashboardCount--: schedule Percent -- ${schedulePercent}")
                Log.d(TAG, "getExecutionDashboardCount--: completed Percent -- ${completedPercent}")
                setData(
                    inProgressPercent.toFloat(),
                    schedulePercent.toFloat(),
                    completedPercent.toFloat()
                )*/

            } else {
                CustomDialoge.closeDialog(context as Activity?)
                CustomToast.showToast(res.message())
                if (res.code() == Constant.RES_ERROR_CODE_FORBIDDEn) {
                    val userData = UserData.getInstance()
                    userData?.clearData()
                    CustomIntent.startActivity(requireActivity(), ScrLogin::class.java)
                }
            }
        }
    }


    override fun onClick(p0: View?) {
        when (p0?.id) {
            R.id.cv_run_job -> {
                CustomIntent.startActivity(
                    requireActivity(),
                    ScrRunJob::class.java,
                    false
                )
            }
            R.id.cv_in_proress -> {
                CustomIntent.startActivity(
                    requireActivity(),
                    ScrExecutionInProgress::class.java,
                    false
                )
            }
            R.id.cv_scheduled -> {
                ScrExecutionScheduled.data.value = true
                CustomIntent.startActivity(
                    requireActivity(),
                    ScrExecutionScheduled::class.java,
                    false
                )
            }
            R.id.cv_history -> {
                CustomIntent.startActivity(
                    requireActivity(),
                    ScrExecutionHistory::class.java,
                    false
                )
            }
        }
    }

    companion object {
        private const val TAG = "FrgExecution"
    }

}