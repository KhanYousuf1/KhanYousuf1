package com.whirlpool.prodigio_app.view.fragments

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.res.ResourcesCompat
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModelProvider
import com.github.mikephil.charting.animation.Easing
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.formatter.PercentFormatter
import com.github.mikephil.charting.utils.MPPointF
import com.google.gson.Gson
import com.whirlpool.prodigio_app.AppApplication
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.*
import com.whirlpool.prodigio_app.databinding.FrgTestSuiteExecutionStatusBinding
import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.utils.CustomDialoge
import com.whirlpool.prodigio_app.utils.CustomToast
import com.whirlpool.prodigio_app.view.dialoges.*
import com.whirlpool.prodigio_app.viewmodel.*
import org.kodein.di.Kodein
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class FrgTestSuiteExecutionStatus : Fragment(), KodeinAware,
    DlgDropDownProjectType.BottomSheetDlgProjectTypeListner,
    DlgDropDownBrand.BottomSheetDlgBrandListner,
    DlgDropDownRegion.BottomSheetDlgRegionListner,
    DlgFromDate.BottomSheetDlgFromDateListner,
    DlgToDate.BottomSheetDlgToDateListner,
    DlgDropDownPlatform.BottomSheetDlgPlatformListner,
    DlgDropDownENV.BottomSheetDlgENVListner,
    DlgDropDownProductName.BottomSheetDlgProductNameListner {


    override val kodein: Kodein by kodein(AppApplication.appContext)

    lateinit var viewModel: DashboardGraphViewModel
    lateinit var binding: FrgTestSuiteExecutionStatusBinding

    //bottomSheetDialoge
    lateinit var bottomDlgProjectType: DlgDropDownProjectType
    lateinit var bottomDlgBrand: DlgDropDownBrand
    lateinit var bottomDlgRegion: DlgDropDownRegion
    lateinit var bottomDlgPlatform: DlgDropDownPlatform
    lateinit var bottomDlgEnv: DlgDropDownENV
    lateinit var bottomDlgProductName: DlgDropDownProductName
    lateinit var bottomDlgFromDate: DlgFromDate
    lateinit var bottomDlgToDate: DlgToDate

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val factory: DashboardGraphViewModelFactory by instance()  // dependency injection
        viewModel =
            ViewModelProvider(this, factory).get(DashboardGraphViewModel::class.java)

        binding = DataBindingUtil.inflate(
            inflater, R.layout.frg_test_suite_execution_status, container, false
        )
        val rootview = binding.root
        init()
        registerClicks()
        return rootview
    }


    fun doValidate() {
        val project_type = binding.etProjectType.text.toString()
        val region = binding.etRegion.text.toString()
        val brand = binding.etBrand.text.toString()
        val product_name = binding.etProductName.text.toString()
        // val test_suite = binding.etTestSuite.text.toString()
        val platform = binding.etPlatform.text.toString()
        val env = binding.etEnv.text.toString()
        // val all = binding.etAll.text.toString()
        val fromDate = binding.etFromDate.text.toString()
        val toDate = binding.etToDate.text.toString()

        if (project_type.isEmpty() || project_type.isNullOrBlank()) {
            binding.tvErrorProjectType.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorProjectType.visibility = View.GONE
        }

        if (region.isEmpty() || region.isNullOrBlank()) {
            binding.tvErrorRegion.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorRegion.visibility = View.GONE
        }

        if (brand.isEmpty() || brand.isNullOrBlank()) {
            binding.tvErrorBrand.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorBrand.visibility = View.GONE
        }

        if (product_name.isEmpty() || product_name.isNullOrBlank()) {
            binding.tvErrorProductName.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorProductName.visibility = View.GONE
        }

        /*if (test_suite.isEmpty() || test_suite.isNullOrBlank()) {
            binding.tvErrorSuiteName.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorSuiteName.visibility = View.GONE
        }*/

        if (platform.isEmpty() || platform.isNullOrBlank()) {
            binding.tvErrorPlatform.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorPlatform.visibility = View.GONE
        }

        if (env.isEmpty() || env.isNullOrBlank()) {
            binding.tvErrorEnv.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorEnv.visibility = View.GONE
        }

        /*if (all.isEmpty() || all.isNullOrBlank()) {
            binding.tvErrorAll.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorAll.visibility = View.GONE
        }*/

        if (fromDate.isEmpty() || fromDate.isNullOrBlank()) {
            binding.tvErrorFromDate.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorFromDate.visibility = View.GONE
        }

        if (toDate.isEmpty() || toDate.isNullOrBlank()) {
            binding.tvErrorToDate.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorToDate.visibility = View.GONE
        }


//        CustomToast.showToast("Call Filter API")
        var project = DashboardGraphs.GetDashboardSuiteCountTrendRequest.Project()
        project.projectName = selectedProductName!!.projectName
        var list: ArrayList<String> =
            arrayListOf()
        list.add(selectedProductName!!.projectName)

        var getDashboardSuiteCountTrendRequest =
            DashboardGraphs.GetDashboardSuiteCountTrendRequest()
        getDashboardSuiteCountTrendRequest.projectTypeId = selectedProjectType!!.projectTypeId
        getDashboardSuiteCountTrendRequest.regionId = selectedRegion!!.regionId
        getDashboardSuiteCountTrendRequest.brandId = "${selectedBrand!!.brandId}"
        getDashboardSuiteCountTrendRequest.projectNames = list
        getDashboardSuiteCountTrendRequest.projectName = selectedProductName!!.projectName
        getDashboardSuiteCountTrendRequest.platformId = "${selectedPlatform!!.platformId}"
        getDashboardSuiteCountTrendRequest.environment = selectedEnv
        getDashboardSuiteCountTrendRequest.startDate =
            "${SimpleDateFormat("yyyy-MM-dd").format(calendarFrom!!.time.time)}"
        getDashboardSuiteCountTrendRequest.endDate =
            "${SimpleDateFormat("yyyy-MM-dd").format(calendarTo!!.time.time)}"

        Coroutines.main {
            getDashboardSuiteCountTrendRequest(getDashboardSuiteCountTrendRequest)
        }
    }

    fun init() {
        binding.pieChartExecution.visibility = View.GONE
        binding.linearLayoutGraphInfo.visibility = View.GONE
        binding.linearLayoutMapError.visibility = View.VISIBLE
        Coroutines.main {
            getAllProjects()
//            getAllUsers()
        }
        Observe()

        binding.pieChartExecution.setUsePercentValues(true);
        binding.pieChartExecution.getDescription().setEnabled(false);
        binding.pieChartExecution.setExtraOffsets(3F, 3F, 3F, 3F);
        binding.pieChartExecution.setDragDecelerationFrictionCoef(0.95f);
        binding.pieChartExecution.setCenterTextTypeface(
            ResourcesCompat.getFont(
                requireContext(),
                R.font.open_sans_semibold
            )
        )
        binding.pieChartExecution.setCenterText(generateCenterSpannableText());
        binding.pieChartExecution.setDrawHoleEnabled(true);
        binding.pieChartExecution.setHoleColor(Color.WHITE);
        binding.pieChartExecution.setTransparentCircleColor(Color.parseColor("#FAFAFA"));
        binding.pieChartExecution.setTransparentCircleAlpha(110);
        binding.pieChartExecution.setHoleRadius(60f);
        binding.pieChartExecution.setTransparentCircleRadius(65f);
        binding.pieChartExecution.setDrawCenterText(true);
        binding.pieChartExecution.setRotationAngle(0F);
        binding.pieChartExecution.setRotationEnabled(true);
        binding.pieChartExecution.setHighlightPerTapEnabled(true);
        binding.pieChartExecution.animateY(1400, Easing.EaseInOutQuad);
        var l = binding.pieChartExecution.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        l.setOrientation(Legend.LegendOrientation.VERTICAL);
        l.setDrawInside(false);
        l.setXEntrySpace(7f);
        l.setYEntrySpace(0f);
        l.setYOffset(0f)
        l.isEnabled = false
        // entry label styling


        binding.textViewPassedCount.setText("73.33%")
        binding.textViewFailedCount.setText("20%")
        binding.textViewUnknownCount.setText("6.67%")
        //setData(73.33F, 20F, 6.67F)

//                startTimmer()
        initBottomDialoge()
//        Observe()
    }


    fun initBottomDialoge() {
//        bottomDlgProjectType = DlgDropDownProjectType(null)
//        bottomDlgProjectType.mListner = this

    }

    private fun generateCenterSpannableText(): SpannableString? {
        val s = SpannableString("Execution Status")
        s.setSpan(RelativeSizeSpan(1.4f), 0, s.length, 0)
        s.setSpan(StyleSpan(Typeface.BOLD), 0, s.length, 0)
        s.setSpan(ForegroundColorSpan(Color.parseColor("#000000")), 0, s.length, 0)
//        s.setSpan(RelativeSizeSpan(.8f), 14, s.length - 15, 0)
//        s.setSpan(StyleSpan(Typeface.ITALIC), s.length - 14, s.length, 0)
//        s.setSpan(ForegroundColorSpan(ColorTemplate.getHoloBlue()), 0, s.length, 0)
        return s
    }


    fun setData(inProgressPercent: Float, schedulePercent: Float, completedPercent: Float) {

        binding.pieChartExecution.visibility = View.VISIBLE
        binding.linearLayoutGraphInfo.visibility = View.VISIBLE
        binding.linearLayoutMapError.visibility = View.GONE
        var entries: ArrayList<PieEntry> = arrayListOf()
        var colors: ArrayList<Int> = arrayListOf()
        entries.add(PieEntry((inProgressPercent), 0))
        entries.add(PieEntry((schedulePercent), 1))
        entries.add(PieEntry((completedPercent), 2))


        colors.add(Color.parseColor("#69C0FF")) // Daybreak Blue
        colors.add(Color.parseColor("#FFD666")) // Calendula Gold
        colors.add(Color.parseColor("#FF7875")) // Dust Red


        var dataSet = PieDataSet(entries, "")
        dataSet.setDrawIcons(false)
        dataSet.sliceSpace = 0f
        dataSet.iconsOffset = MPPointF(0F, 40F)
        dataSet.selectionShift = 5f
        dataSet.setDrawValues(false)



        dataSet.setColors(colors);
        Log.d(Companion.TAG, "setData: entryCount :- ${dataSet.entryCount}")
        Log.d(Companion.TAG, "setData: axisDependency :- ${dataSet.axisDependency}")
        Log.d(Companion.TAG, "setData: colors :- ${dataSet.colors.size}")
        val data = PieData(dataSet)
        data.setValueFormatter(PercentFormatter())
        data.setValueTextSize(14f)
        data.setValueTextColor(Color.BLACK)
        binding.pieChartExecution.setData(data)
        binding.pieChartExecution.highlightValues(null);
        binding.pieChartExecution.invalidate();
    }

    companion object {
        private const val TAG = "FrgTestSuiteExecutionSt"
    }

    //bottom dialoe interface ==============================================================================================================


    fun Observe() {

        projectTypesObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgProjectType = DlgDropDownProjectType(it, this)
                bottomDlgProjectType.mListner = this
            }
        })

        regionObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgRegion = DlgDropDownRegion()
                bottomDlgRegion.items = it
                bottomDlgRegion.mListner = this

                if (bottomDlgRegion != null && !bottomDlgRegion.isVisible) {
                    bottomDlgRegion.show(parentFragmentManager, TAG)
                }
            }
        })

        brandObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgBrand = DlgDropDownBrand()
                bottomDlgBrand.items = it
                bottomDlgBrand.mListner = this
                if (bottomDlgBrand != null && !bottomDlgBrand.isVisible) {
                    bottomDlgBrand.show(parentFragmentManager, TAG)
                }
            }
        })
        productNameObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgProductName = DlgDropDownProductName()
                bottomDlgProductName.items = it
                bottomDlgProductName.mListner = this
                if (bottomDlgProductName != null && !bottomDlgProductName.isVisible) {
                    bottomDlgProductName.show(parentFragmentManager, TAG)
                }
            }
        })
        /*testSuitObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgTestSuite = DlgDropDownTestSuite()
                bottomDlgTestSuite.items = it
                bottomDlgTestSuite.mListner = this
                if (bottomDlgTestSuite != null && !bottomDlgTestSuite.isVisible) {
                    bottomDlgTestSuite.show(parentFragmentManager, TAG)
                }
            }
        })*/
        platformObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgPlatform = DlgDropDownPlatform()
                bottomDlgPlatform.items = it
                bottomDlgPlatform.mListner = this
                if (bottomDlgPlatform != null && !bottomDlgPlatform.isVisible) {
                    bottomDlgPlatform.show(parentFragmentManager, TAG)
                }
            }
        })

        envObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgEnv = DlgDropDownENV()
                bottomDlgEnv.items = it
                bottomDlgEnv.mListner = this
                if (bottomDlgEnv != null && !bottomDlgEnv.isVisible) {
                    bottomDlgEnv.show(parentFragmentManager, TAG)
                }
            }
        })

        /* userObservable.observe(requireActivity(), {
             it?.let {
                 bottomDlgAll = DlgDropDownAll()
                 bottomDlgAll.items = it
                 bottomDlgAll.mListner = this
                 if (bottomDlgAll != null && !bottomDlgAll.isVisible) {
                     bottomDlgAll.show(parentFragmentManager, TAG)
                 }
             }
         })*/


        getDashboardSuiteCountTrendObservable.observe(requireActivity(), {
            it?.let {
                setData(it.passPercentage!!, it.failPercentage!!, it.notExecPercentage!!)
                binding.textViewPassedCount.setText("${it.passPercentage!!} %")
                binding.textViewFailedCount.setText("${it.failPercentage!!} %")
                binding.textViewUnknownCount.setText("${it.notExecPercentage!!} %")
            }
        })

        /*userObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgAll = DlgDropDownAll()
                bottomDlgAll.items = it
                bottomDlgAll.mListner = this
                if (bottomDlgAll!=null&& !bottomDlgAll.isVisible) {
                    bottomDlgAll.show(parentFragmentManager, TAG)
                }
            }
        })*/
    }

    var projectTypesObservable: MutableLiveData<ArrayList<ProjectType>> =
        MutableLiveData<ArrayList<ProjectType>>()
    var regionObservable: MutableLiveData<ArrayList<Region>> = MutableLiveData<ArrayList<Region>>()
    var brandObservable: MutableLiveData<ArrayList<Brand>> = MutableLiveData<ArrayList<Brand>>()
    var productNameObservable: MutableLiveData<ArrayList<ProductName>> =
        MutableLiveData<ArrayList<ProductName>>()
    var testSuitObservable: MutableLiveData<ArrayList<TestSuit>> =
        MutableLiveData<ArrayList<TestSuit>>()
    var platformObservable: MutableLiveData<ArrayList<Platform>> =
        MutableLiveData<ArrayList<Platform>>()
    var envObservable: MutableLiveData<ArrayList<String>> = MutableLiveData<ArrayList<String>>()
    var userObservable: MutableLiveData<ArrayList<User>> = MutableLiveData<ArrayList<User>>()
    var getDashboardSuiteCountTrendObservable: MutableLiveData<DashboardGraphs.GetDashboardSuiteCountTrendResponse> =
        MutableLiveData<DashboardGraphs.GetDashboardSuiteCountTrendResponse>()

    suspend fun getAllProjects() {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllProjectType()
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            projectTypesObservable.value = res.body() as ArrayList<ProjectType>
            Log.d(TAG, "getAllProjects: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllProjects: Error : ")
        }
    }


    suspend fun getAllRegionsByProject(projectTypeId: Int) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllRegionsByProject(projectTypeId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            regionObservable.value = res.body() as ArrayList<Region>
            Log.d(TAG, "getAllRegionsByProject: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllRegionsByProject: Error : ${res.body()} ")
        }
    }

    suspend fun getAllBrands(regionId: Int) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllBrands(regionId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            brandObservable.value = res.body() as ArrayList<Brand>
            Log.d(TAG, "getAllBrands: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllBrands: Error : ${res.body()} ")
        }
    }


    suspend fun getAllProductNames(
        brandId: Int,
        projectTypeId: Int,
        regionId: Int
    ) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllProductNames(brandId, projectTypeId, regionId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            productNameObservable.value = res.body() as ArrayList<ProductName>
            Log.d(TAG, "getAllProductNames: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllProductNames: Error : ${res.body()} ")
        }
    }


    suspend fun getTestSuiteNameByProjectName(projectName: String) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getTestSuiteNameByProjectName(projectName)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            testSuitObservable.value = res.body() as ArrayList<TestSuit>
            Log.d(TAG, "getTestSuiteNameByProjectName: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getTestSuiteNameByProjectName: Error : ${res.body()} ")
        }
    }

    suspend fun getAllPlatform(projectTypeId: Int) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllPlatform(projectTypeId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            platformObservable.value = res.body() as ArrayList<Platform>
            Log.d(TAG, "getAllPlatform: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllPlatform: Error : ${res.body()} ")
        }
    }

    suspend fun getAllUsers() {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllUsers()
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            userObservable.value = res.body() as ArrayList<User>
            Log.d(TAG, "getAllUsers: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllUsers: Error : ${res.body()} ")
        }
    }

    suspend fun getDashboardSuiteCountTrendRequest(getDashboardSuiteCountTrendRequest: DashboardGraphs.GetDashboardSuiteCountTrendRequest) {
        Log.d(TAG, "getDashboardSuiteCountTrendRequest: API Called")
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        var gson = Gson()
        var js = gson.toJson(getDashboardSuiteCountTrendRequest)

        Log.d(TAG, "getDashboardSuiteCountTrendRequest: ${js}")

        val res = viewModel.getDashboardSuiteCountTrendRequest(
            getDashboardSuiteCountTrendRequest
        )
        if (res != null) {
            if (res.isSuccessful) {
                CustomDialoge.closeDialog(context as Activity?)
                getDashboardSuiteCountTrendObservable.value =
                    res.body() as DashboardGraphs.GetDashboardSuiteCountTrendResponse

                Log.d(TAG, "getDashboardSuiteCountTrendRequest: ${res.body()}")
            } else {
                CustomDialoge.closeDialog(context as Activity?)
                CustomToast.showToast(res.message())
                Log.d(TAG, "getDashboardSuiteCountTrendRequest: Error : ${res.body()} ")
            }
        } else {
            CustomToast.showToast("Something went wrong...")
        }
    }


    fun registerClicks() {

        binding.llProjectType.setOnClickListener {
            if (this::bottomDlgProjectType.isInitialized) {
                if (bottomDlgProjectType != null) {
                    bottomDlgProjectType.show(parentFragmentManager, TAG)
                }
            }
        }
        binding.llRegion.setOnClickListener {
            if (selectedProjectType != null) {
                binding.tvErrorProjectType.visibility = View.GONE
                Coroutines.main {
                    getAllRegionsByProject(selectedProjectType!!.projectTypeId)
                }
            } else {
                binding.tvErrorProjectType.visibility = View.VISIBLE
            }
//            bottomDlgRegion.show(parentFragmentManager, TAG)
        }
        binding.cvBrand.setOnClickListener {
            if (selectedRegion != null) {
                binding.tvErrorRegion.visibility = View.GONE
                Coroutines.main {
                    getAllBrands(selectedRegion!!.regionId)
                }
            } else {
                binding.tvErrorRegion.visibility = View.VISIBLE
            }
//            bottomDlgBrand.show(parentFragmentManager, TAG)
        }
        binding.llProoductName.setOnClickListener {
            if (selectedProjectType != null && selectedBrand != null && selectedRegion != null) {
                binding.tvErrorProjectType.visibility = View.GONE
                binding.tvErrorRegion.visibility = View.GONE
                binding.tvErrorBrand.visibility = View.GONE
                Coroutines.main {
                    getAllProductNames(
                        selectedBrand!!.brandId,
                        selectedProjectType!!.projectTypeId,
                        selectedRegion!!.regionId
                    )
                }
            } else {
                if (selectedProjectType == null) {
                    binding.tvErrorProjectType.visibility = View.VISIBLE
                }
                if (selectedRegion == null) {
                    binding.tvErrorRegion.visibility = View.VISIBLE
                }
                if (selectedBrand == null) {
                    binding.tvErrorBrand.visibility = View.VISIBLE
                }
            }
//            bottomDlgRegion.show(parentFragmentManager, TAG)
        }

        binding.llPlatform.setOnClickListener {
            if (selectedProjectType != null) {
                binding.tvErrorProjectType.visibility = View.GONE
                Coroutines.main {
                    getAllPlatform(selectedProjectType!!.projectTypeId)
                }
            } else {
                binding.tvErrorProjectType.visibility = View.VISIBLE
            }
        }

        binding.llEnv.setOnClickListener {
            var list: ArrayList<String> = arrayListOf()
            list.add("ENV")
            list.add("STG")
            list.add("DEV")
            list.add("Prod")
            list.add("QA")
            envObservable.value = list
//            bottomDlgEnv.show(parentFragmentManager, TAG)
        }

        binding.llFrom.setOnClickListener {
            var calendarMax = Calendar.getInstance()
            bottomDlgFromDate = DlgFromDate(this, calendarMax, null)
            bottomDlgFromDate.show(parentFragmentManager, TAG)
//            bottomDlgFromDate.setMaxDate(calendar.time.time)
        }
        binding.llTo.setOnClickListener {
            if (calendarFrom != null) {
                binding.tvErrorFromDate.visibility = View.GONE
                var calendarMax = Calendar.getInstance()
                bottomDlgToDate = DlgToDate(this, calendarMax, calendarFrom)
                bottomDlgToDate.show(parentFragmentManager, TAG)
            } else {
                binding.tvErrorFromDate.visibility = View.VISIBLE
            }
//            bottomDlgFromDate.setMaxDate(calendar.time.time)
        }

        binding.btRun.setOnClickListener {
            doValidate()
            /*Coroutines.main {
                getDashboardSuiteCountTrendRequest()
            }*/
        }
    }


    //bottom dialoe interface ==============================================================================================================

    var selectedProjectType: ProjectType? = null
    var selectedRegion: Region? = null
    var selectedBrand: Brand? = null
    var selectedProductName: ProductName? = null
    var selectedTestSuite: TestSuit? = null
    var selectedPlatform: Platform? = null
    var selectedEnv: String? = null
    var selectedUser: User? = null

    override fun onProjectTypeSelected(type: Int) {
        selectedProjectType = projectTypesObservable.value!!.get(type)
        binding.etProjectType.setText(selectedProjectType!!.projectTypeName)
        bottomDlgProjectType.dismiss()
    }

    override fun onRegionSelected(type: Int) {
        selectedRegion = regionObservable.value!!.get(type)
        binding.etRegion.setText(selectedRegion!!.regionName)
        bottomDlgRegion.dismiss()
    }

    override fun onBrandSelected(type: Int) {
        selectedBrand = brandObservable.value!!.get(type)
        binding.etBrand.setText(selectedBrand!!.brandName)
        bottomDlgBrand.dismiss()
    }

    override fun onProductNameSelected(type: Int) {
        selectedProductName = productNameObservable.value!!.get(type)
        binding.etProductName.setText(selectedProductName!!.projectName)
        bottomDlgProductName.dismiss()
    }


    override fun onPlatformSelected(type: Int) {
        selectedPlatform = platformObservable.value!!.get(type)
        binding.etPlatform.setText(selectedPlatform!!.platformName)
        bottomDlgPlatform.dismiss()
    }

    override fun onENVSelected(type: Int) {
        selectedEnv = envObservable.value!!.get(type)
        binding.etEnv.setText(selectedEnv!!)
        bottomDlgEnv.dismiss()
    }


    override fun onFromDateSelected(date: String, calendar: Calendar) {
        calendarFrom = calendar
        binding.etFromDate.setText("${date}")
    }

    override fun onToDateSelected(date: String, calendar: Calendar) {
        calendarTo = calendar
        binding.etToDate.setText("${date}")
    }

    var calendarFrom: Calendar? = null
    var calendarTo: Calendar? = null


}