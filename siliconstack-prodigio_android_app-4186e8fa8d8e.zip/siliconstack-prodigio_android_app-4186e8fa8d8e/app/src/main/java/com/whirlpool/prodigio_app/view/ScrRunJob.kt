package com.whirlpool.prodigio_app.view

import android.content.Context
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.databinding.ActivityScrRunJobBinding
import com.whirlpool.prodigio_app.databinding.LayoutToolbarNewBinding
import com.whirlpool.prodigio_app.view.fragments.FrgDocument
import com.whirlpool.prodigio_app.view.fragments.FrgRunJobStep1
import com.whirlpool.prodigio_app.view.fragments.FrgRunJobStep3

class ScrRunJob : AppCompatActivity() {

    lateinit var binding: ActivityScrRunJobBinding
    lateinit var toolbarbinding: LayoutToolbarNewBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = resources.getColor(R.color.white)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            window.statusBarColor = Color.WHITE
        }

        binding = DataBindingUtil.setContentView(this, R.layout.activity_scr_run_job)
        setUpToolBar()
        initFirstDashBoard()
    }

    fun setUpToolBar() {
        //init toolbar
        toolbarbinding = binding.llToolBar
        toolbarbinding.llSearch.visibility = View.GONE
        toolbarbinding.tvToolBarHeader.text = "Execution"
        toolbarbinding.llBack.setOnClickListener { finish() }
        toolbarbinding.llSearch.setOnClickListener {
            toolbarbinding.llSearchContainer.visibility = View.VISIBLE
            toolbarbinding.llHeaderMain.visibility = View.GONE
        }
        toolbarbinding.llClose.setOnClickListener {
            if (toolbarbinding.etSearch.text.toString().isNullOrBlank()) {
                toolbarbinding.llSearchContainer.visibility = View.GONE
                toolbarbinding.llHeaderMain.visibility = View.VISIBLE
            } else {
                toolbarbinding.etSearch.text = null
            }
        }

        val in_: InputMethodManager =
            getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        in_.hideSoftInputFromWindow(toolbarbinding.etSearch.getWindowToken(), 0)

        /*toolbarbinding.etSearch.doAfterTextChanged {
            var text = it.toString()
            Log.d(TAG, "setUpToolBar: doAfterTextChanged : $text")
        }*/

        toolbarbinding.etSearch.setOnEditorActionListener(TextView.OnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                return@OnEditorActionListener true
            }
            false
        })
    }


    fun initFirstDashBoard() {
       /* supportFragmentManager.beginTransaction().replace(R.id.fl_container, FrgRunJobStep1())
            .commit()*/
        supportFragmentManager.beginTransaction().replace(R.id.fl_container, FrgRunJobStep3())
            .commit()
    }


}