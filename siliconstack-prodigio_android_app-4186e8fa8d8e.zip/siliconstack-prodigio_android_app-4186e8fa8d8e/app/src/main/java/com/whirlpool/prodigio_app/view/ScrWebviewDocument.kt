package com.whirlpool.prodigio_app.view

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import com.whirlpool.prodigio_app.databinding.ActivityScrWebviewDocumentBinding
import android.widget.Toast

import android.webkit.WebView

import android.webkit.WebViewClient

import android.os.Build

import android.webkit.WebSettings

import android.webkit.WebChromeClient

import android.annotation.SuppressLint
import android.graphics.Color
import android.util.Log
import android.view.View
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.Constant
import com.whirlpool.prodigio_app.utils.CustomDialoge
import com.whirlpool.prodigio_app.utils.CustomToast
import android.content.DialogInterface

import android.net.http.SslError

import android.webkit.SslErrorHandler


class ScrWebviewDocument : AppCompatActivity() {

    val TAG = ScrWebviewDocument::class.java.name

    lateinit var binding: ActivityScrWebviewDocumentBinding

    lateinit var url: String


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = resources.getColor(R.color.white)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            window.statusBarColor = Color.WHITE
        }

        binding = DataBindingUtil.setContentView(this, R.layout.activity_scr_webview_document)
        getIntentData()
    }

    fun getIntentData() {
        url = intent.getStringExtra("url")!!
        Log.d(TAG, "getIntentData: url : $url")
        launchWebView(url)
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun initWebView(url: String) {
        Log.d(TAG, "initWebView: url $url")
        binding.webview.settings.useWideViewPort = true
        binding.webview.settings.loadWithOverviewMode = true
        binding.webview.settings.javaScriptEnabled = true
        binding.webview.settings.javaScriptCanOpenWindowsAutomatically = true
        binding.webview.settings.domStorageEnabled = true
        binding.webview.settings.pluginState = WebSettings.PluginState.ON
        binding.webview.settings.loadWithOverviewMode = true
        binding.webview.webChromeClient = WebChromeClient()
        binding.webview.webViewClient = WebViewClient()
        binding.webview.settings.setRenderPriority(WebSettings.RenderPriority.HIGH)
        binding.webview.settings.cacheMode = WebSettings.LOAD_NO_CACHE
        if (Build.VERSION.SDK_INT >= 19) {
            binding.webview.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        } else {
            binding.webview.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        }
        CustomDialoge.showDialog(this, Constant.PROGRESS)
        binding.webview.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                Log.d("TAG", "shouldOverrideUrlLoading: url : $url")
                return false
            }

            override fun onPageFinished(view: WebView, url: String) {
                CustomDialoge.closeDialog(this@ScrWebviewDocument)
                Log.d("TAG", "onPageFinished: url : $url")
            }

            override fun onReceivedError(
                view: WebView,
                errorCode: Int,
                description: String,
                failingUrl: String
            ) {
                Log.d("TAG", "onReceivedError: $description")
                CustomToast.showToast("Error:$description")
            }
        }
        binding.webview.loadUrl("about:blank")
        binding.webview.loadUrl("https://drive.google.com/viewerng/viewer?embedded=true&url=$url")
        Log.d(TAG, "initWebView: loaded url : " + binding.webview.url)
    }


    @SuppressLint("SetJavaScriptEnabled")
    private fun launchWebView(URL: String) {
        binding.webview.setInitialScale(1)
        binding.webview.getSettings().setLoadWithOverviewMode(true)
        binding.webview.getSettings().setUseWideViewPort(true)
        binding.webview.getSettings().setJavaScriptEnabled(true)
        binding.webview.getSettings().setAllowFileAccess(true)
        binding.webview.getSettings().setAllowContentAccess(true)
        binding.webview.setScrollbarFadingEnabled(false)
        binding.webview.setWebChromeClient(object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {}
        })
        binding.webview.setWebViewClient(object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                Log.d(TAG, "shouldOverrideUrlLoading: url: $url")

                return false
            }

            //To Handle SSL Errors
            override fun onReceivedSslError(
                view: WebView,
                handler: SslErrorHandler,
                error: SslError
            ) {

            }
        })
        binding.webview.loadUrl(URL)
       // binding.webview.loadUrl("https://drive.google.com/file/d/1wsuiy7Ppeo6zHC-EJBEH_iJ5MpotLdJK/view?usp=sharing")
    }

    override fun onBackPressed() {
        if(binding.webview.canGoBack()){
            binding.webview.goBack()
        }else {
            super.onBackPressed()
        }
    }

}