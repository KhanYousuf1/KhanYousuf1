package com.whirlpool.prodigio_app.storage

import android.content.Context
import android.content.LocusId
import android.content.SharedPreferences
import com.whirlpool.prodigio_app.AppApplication

class UserData {


    private val TOKEN = "TOKEN"
    private val USER_ID_NAME = "USER_ID_NAME"
    private val USER_NAME = "USER_NAME"
    private val USERID = "USERID"
    private val ROLE_ID = "ROLE_ID"
    private val ROLE_NAME = "ROLE_NAME"
    private val REMEMBER_ME = "REMEMBER_ME"

    companion object {
        private var _instance: UserData? = null
        private var _sharedPreferences: SharedPreferences? = null
        private var _sharedPrefEditor: SharedPreferences.Editor? = null
        private val SHARED_PREFERENCE_NAME = "user_data"

        /**
         * This method is used to initialized [SharedPreferences] and
         * [Editor]
         */
        fun _initSharedPreferences() {
            _sharedPreferences = _getSharedPref()
            _sharedPrefEditor = _getSharedPrefEditor()
        }

        /**
         * Method to get the SharedPreferences.
         *
         * @return the [SharedPreferences] object.
         */
        private fun _getSharedPref(): SharedPreferences {
            if (_sharedPreferences == null) {
                _sharedPreferences = AppApplication.appContext.getSharedPreferences(
                    SHARED_PREFERENCE_NAME,
                    Context.MODE_PRIVATE
                )
            }
            return _sharedPreferences!!
        }

        /**
         * Method to get the [Editor] for writing values to [SharedPreferences].
         *
         * @return the [Editor] object.
         */
        private fun _getSharedPrefEditor(): SharedPreferences.Editor? {
            if (_sharedPrefEditor == null) {
                _sharedPrefEditor = _getSharedPref().edit()
            }
            return _sharedPrefEditor
        }

        fun getInstance(): UserData? {
            if (_instance == null) {
                _instance = UserData()
                _initSharedPreferences()
            }
            return _instance
        }
    }


    fun setTOKEN(token: String?) {
        _getSharedPrefEditor()!!.putString(TOKEN, token).commit()
    }

    fun getTOKEN(): String? {
        return _getSharedPref().getString(TOKEN, null)
    }

    fun setUserIdName(langType: String?) {
        _getSharedPrefEditor()!!.putString(USER_ID_NAME, langType).commit()
    }

    fun getUserIdName(): String? {
        return _getSharedPref().getString(USER_ID_NAME, null)
    }

    fun setUserName(userName: String) {
        _getSharedPrefEditor()!!.putString(USER_NAME, userName).commit()
    }

    fun getUserName(): String? {
        return _getSharedPref().getString(USER_NAME, null)
    }

    fun setUserId(userID: Int) {
        _getSharedPrefEditor()!!.putInt(USERID, userID).commit()
    }

    fun getUserId(): Int? {
        return _getSharedPref().getInt(USERID, 0)
    }


    fun setRoleId(roleId: Int) {
        _getSharedPrefEditor()!!.putInt(ROLE_ID, roleId).commit()
    }

    fun getRoleId(): Int {
        return _getSharedPref().getInt(ROLE_ID, 0)
    }

    fun setRoleName(userName: String) {
        _getSharedPrefEditor()!!.putString(ROLE_NAME, userName).commit()
    }

    fun getRoleName(): String? {
        return _getSharedPref().getString(ROLE_NAME, null)
    }

    fun setRememberMe(remember_me: Boolean) {
        _getSharedPrefEditor()!!.putBoolean(REMEMBER_ME, remember_me).commit()
    }

    fun isRememberMe(): Boolean {
        return _getSharedPref().getBoolean(REMEMBER_ME, false)
    }


    fun clearData() {
        _getSharedPrefEditor()?.clear();
        _getSharedPrefEditor()?.commit();
    }

}