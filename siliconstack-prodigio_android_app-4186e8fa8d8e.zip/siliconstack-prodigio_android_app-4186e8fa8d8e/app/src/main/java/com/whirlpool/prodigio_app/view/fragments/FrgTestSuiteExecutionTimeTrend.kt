package com.whirlpool.prodigio_app.view.fragments

import android.app.Activity
import android.graphics.Color
import android.graphics.DashPathEffect
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModelProvider
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.highlight.Highlight
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet
import com.github.mikephil.charting.listener.OnChartValueSelectedListener
import com.github.mikephil.charting.utils.Utils
import com.google.gson.Gson
import com.whirlpool.prodigio_app.AppApplication
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.*
import com.whirlpool.prodigio_app.databinding.FrgTestSuiteExecutionTimeTrendBinding
import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.utils.CustomDialoge
import com.whirlpool.prodigio_app.utils.CustomToast
import com.whirlpool.prodigio_app.view.custom.MyMarkerView
import com.whirlpool.prodigio_app.view.dialoges.*
import com.whirlpool.prodigio_app.viewmodel.DashboardGraphViewModel
import com.whirlpool.prodigio_app.viewmodel.DashboardGraphViewModelFactory
import com.whirlpool.prodigio_app.viewmodel.TestSuiteExecutionTimeTrendViewModel
import com.whirlpool.prodigio_app.viewmodel.TestSuiteExecutionTimeTrendViewModelFactory
import org.kodein.di.Kodein
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class FrgTestSuiteExecutionTimeTrend : Fragment(), KodeinAware,
    DlgDropDownProjectType.BottomSheetDlgProjectTypeListner,
    DlgDropDownRegion.BottomSheetDlgRegionListner,
    DlgDropDownBrand.BottomSheetDlgBrandListner,
    DlgDropDownProductName.BottomSheetDlgProductNameListner,
    DlgDropDownTestSuite.BottomSheetDlgTestSuiteListner,
    DlgDropDownPlatform.BottomSheetDlgPlatformListner,
    DlgDropDownENV.BottomSheetDlgENVListner,
    DlgFromDate.BottomSheetDlgFromDateListner,
    DlgToDate.BottomSheetDlgToDateListner,
    DlgDropDownAll.BottomSheetDlgAllListner,
    OnChartValueSelectedListener {


    override val kodein: Kodein by kodein(AppApplication.appContext)

    lateinit var viewModel: DashboardGraphViewModel
    lateinit var binding: FrgTestSuiteExecutionTimeTrendBinding

    //bottomSheetDialoge
    lateinit var bottomDlgProjectType: DlgDropDownProjectType
    lateinit var bottomDlgRegion: DlgDropDownRegion
    lateinit var bottomDlgBrand: DlgDropDownBrand
    lateinit var bottomDlgProductName: DlgDropDownProductName
    lateinit var bottomDlgTestSuite: DlgDropDownTestSuite
    lateinit var bottomDlgPlatform: DlgDropDownPlatform
    lateinit var bottomDlgEnv: DlgDropDownENV
    lateinit var bottomDlgAll: DlgDropDownAll
    lateinit var bottomDlgFromDate: DlgFromDate
    lateinit var bottomDlgToDate: DlgToDate

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val factory: DashboardGraphViewModelFactory by instance()  // dependency injection
        viewModel =
            ViewModelProvider(this, factory).get(DashboardGraphViewModel::class.java)

        binding = DataBindingUtil.inflate(
            inflater, R.layout.frg_test_suite_execution_time_trend, container, false
        )
        val rootview = binding.root
        init()
        registerClicks()
        return rootview
    }

    private fun init() {

        binding.lineChart.visibility = View.GONE
        binding.linearLayoutGraphInfo.visibility = View.GONE
        binding.linearLayoutMapError.visibility = View.VISIBLE
        Coroutines.main {

            getAllProjects()
//            getAllUsers()
        }
        Observe()

        binding.lineChart.setBackgroundColor(Color.parseColor("#FAFAFA"));
//         binding.lineChart.setOnChartGestureListener(this)
//         binding.lineChart.setOnChartValueSelectedListener(this)
        binding.lineChart.setDrawGridBackground(false)
        binding.lineChart.getDescription().setEnabled(false)
        binding.lineChart.setTouchEnabled(true)
        binding.lineChart.setDragEnabled(true)
        binding.lineChart.setScaleEnabled(false)
        binding.lineChart.setPinchZoom(false)
//        val mv = MyMarkerView(requireActivity(), R.layout.custom_marker_view)
//        mv.setChartView(binding.lineChart) // For bounds control
//        binding.lineChart.setMarker(mv) // Set the marker to the chart
        binding.lineChart.animateX(2500)
        binding.lineChart.getXAxis().setAxisMinimum(0F)
        binding.lineChart.getXAxis().setEnabled(false)
        binding.lineChart.getAxisLeft().setEnabled(true)
        binding.lineChart.getAxisRight().setEnabled(false)
        binding.lineChart.getAxisLeft().setTextColor(Color.parseColor("#000000"))
        binding.lineChart.getXAxis().setTextColor(Color.parseColor("#000000"))
        binding.lineChart.getLegend().setTextColor(Color.RED)
        binding.lineChart.legend.isEnabled = false
        binding.lineChart.setDrawBorders(false)

        // add data
//        setData(100, 60F)

        binding.lineChart.invalidate()
    }

    private fun setData(mChart: LineChart, list : ArrayList<DashboardGraphs.GetDashboardCountsForTestExecutionTimeTrendsResponse>) {
        if (list!=null){
            if (list.size!=0){
                binding.lineChart.visibility = View.VISIBLE
                binding.linearLayoutGraphInfo.visibility = View.VISIBLE
                binding.linearLayoutMapError.visibility = View.GONE
//                binding.det.visibility = View.GONE
            }else{
                return
            }
        }else{
            return
        }

        val values = ArrayList<Entry>()
        val values2 = ArrayList<Entry>()

        for (i in 0..list.size-1) {
            if (list.get(i).executionTime!!.toFloat() > 0) {
                values.add(Entry(i.toFloat(), (list.get(i).executionTime!!.toFloat())/60, null, null))
            }else{
                values.add(Entry(i.toFloat(), (list.get(i).executionTime!!.toFloat()), null, null))
            }

            if (list.get(i).meanExecutionTime!!.toFloat() > 0) {
                values2.add(Entry(i.toFloat(), (list.get(i).meanExecutionTime!!.toFloat())/60, null, null))
            }else{
                values2.add(Entry(i.toFloat(), (list.get(i).meanExecutionTime!!.toFloat()), null, null))
            }
        }
        val lineDataSet: LineDataSet
        val lineDataSet2: LineDataSet
        if (mChart.data != null && mChart.data.dataSetCount > 0) {
            lineDataSet = mChart.data.getDataSetByIndex(0) as LineDataSet
            lineDataSet2 = mChart.data.getDataSetByIndex(0) as LineDataSet
            lineDataSet.values = values
            lineDataSet2.values = values2
            mChart.data.notifyDataChanged()
            mChart.notifyDataSetChanged()
        } else {
            // create a dataset and give it a type
            lineDataSet = LineDataSet(
                values,
                "Execution Time : "
            )
            lineDataSet.setDrawIcons(false)
            lineDataSet.enableDashedLine(10f, 0f, 0f)
            lineDataSet.enableDashedHighlightLine(10f, 0f, 0f)
            lineDataSet.color = Color.parseColor("#52C41A")
            lineDataSet.setCircleColor(Color.parseColor("#52C41A"))
            lineDataSet.lineWidth = 2f
            lineDataSet.circleRadius = 3f
            lineDataSet.setDrawCircleHole(false)
            lineDataSet.valueTextSize = 0f
            lineDataSet.valueTextColor = Color.RED
            lineDataSet.setDrawFilled(true)
            lineDataSet.formLineWidth = 0f
            lineDataSet.formLineDashEffect = DashPathEffect(floatArrayOf(10f, 5f), 0f)
            lineDataSet.formSize = 15f
            if (Utils.getSDKInt() >= 18) {
                // fill drawable only supported on api level 18 and above
                val drawable =
                    ContextCompat.getDrawable(
                        requireContext(),
                        R.drawable.map_background_transparent
                    )
                lineDataSet.fillDrawable = drawable
            } else {
                lineDataSet.fillColor = Color.parseColor("#52C41A")
            }

            lineDataSet2 = LineDataSet(
                values2,
                "Mean Execution Time : "
            )
            lineDataSet2.setDrawIcons(false)
            lineDataSet2.enableDashedLine(10f, 0f, 0f)
            lineDataSet2.enableDashedHighlightLine(10f, 0f, 0f)
            lineDataSet2.color = Color.parseColor("#1890FF")
            lineDataSet2.setCircleColor(Color.parseColor("#1890FF"))
            lineDataSet2.lineWidth = 2f
            lineDataSet2.circleRadius = 3f
            lineDataSet2.setDrawCircleHole(false)
            lineDataSet2.valueTextSize = 0f
            lineDataSet2.valueTextColor = Color.RED
            lineDataSet2.setDrawFilled(true)
            lineDataSet2.formLineWidth = 0f
            lineDataSet2.formLineDashEffect = DashPathEffect(floatArrayOf(10f, 5f), 0f)
            lineDataSet2.formSize = 15f
            if (Utils.getSDKInt() >= 18) {
                // fill drawable only supported on api level 18 and above
                val drawable =
                    ContextCompat.getDrawable(
                        requireContext(),
                        R.drawable.map_background_transparent
                    )
                lineDataSet2.fillDrawable = drawable
            } else {
                lineDataSet2.fillColor = Color.parseColor("#1890FF")
            }


            val dataSets = ArrayList<ILineDataSet>()
            dataSets.add(lineDataSet) // add the datasets
            dataSets.add(lineDataSet2) // add the datasets

            // create a data object with the datasets
            val data = LineData(dataSets)

            // set data
            mChart.data = data
        }
    }

    fun Observe() {
        projectTypesObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgProjectType = DlgDropDownProjectType(it, this)
                bottomDlgProjectType.mListner = this
            }
        })

        regionObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgRegion = DlgDropDownRegion()
                bottomDlgRegion.items = it
                bottomDlgRegion.mListner = this

                if (bottomDlgRegion != null && !bottomDlgRegion.isVisible) {
                    bottomDlgRegion.show(parentFragmentManager, TAG)
                }
            }
        })

        brandObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgBrand = DlgDropDownBrand()
                bottomDlgBrand.items = it
                bottomDlgBrand.mListner = this
                if (bottomDlgBrand != null && !bottomDlgBrand.isVisible) {
                    bottomDlgBrand.show(parentFragmentManager, TAG)
                }
            }
        })
        productNameObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgProductName = DlgDropDownProductName()
                bottomDlgProductName.items = it
                bottomDlgProductName.mListner = this
                if (bottomDlgProductName != null && !bottomDlgProductName.isVisible) {
                    bottomDlgProductName.show(parentFragmentManager, TAG)
                }
            }
        })
        testSuitObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgTestSuite = DlgDropDownTestSuite()
                bottomDlgTestSuite.items = it
                bottomDlgTestSuite.mListner = this
                if (bottomDlgTestSuite != null && !bottomDlgTestSuite.isVisible) {
                    bottomDlgTestSuite.show(parentFragmentManager, TAG)
                }
            }
        })
        platformObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgPlatform = DlgDropDownPlatform()
                bottomDlgPlatform.items = it
                bottomDlgPlatform.mListner = this
                if (bottomDlgPlatform != null && !bottomDlgPlatform.isVisible) {
                    bottomDlgPlatform.show(parentFragmentManager, TAG)
                }
            }
        })

        envObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgEnv = DlgDropDownENV()
                bottomDlgEnv.items = it
                bottomDlgEnv.mListner = this
                if (bottomDlgEnv != null && !bottomDlgEnv.isVisible) {
                    bottomDlgEnv.show(parentFragmentManager, TAG)
                }
            }
        })

        userObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgAll = DlgDropDownAll()
                bottomDlgAll.items = it
                bottomDlgAll.mListner = this
                if (bottomDlgAll != null && !bottomDlgAll.isVisible) {
                    bottomDlgAll.show(parentFragmentManager, TAG)
                }
            }
        })

        getDashboardCountsForTestExecutionTimeTrendsResponseObservable.observe(requireActivity(), {
            it?.let {
               setData(binding.lineChart,it)
            }
        })
    }

    var projectTypesObservable: MutableLiveData<ArrayList<ProjectType>> =
        MutableLiveData<ArrayList<ProjectType>>()
    var regionObservable: MutableLiveData<ArrayList<Region>> = MutableLiveData<ArrayList<Region>>()
    var brandObservable: MutableLiveData<ArrayList<Brand>> = MutableLiveData<ArrayList<Brand>>()
    var productNameObservable: MutableLiveData<ArrayList<ProductName>> =
        MutableLiveData<ArrayList<ProductName>>()
    var testSuitObservable: MutableLiveData<ArrayList<TestSuit>> =
        MutableLiveData<ArrayList<TestSuit>>()
    var platformObservable: MutableLiveData<ArrayList<Platform>> =
        MutableLiveData<ArrayList<Platform>>()
    var envObservable: MutableLiveData<ArrayList<String>> = MutableLiveData<ArrayList<String>>()
    var userObservable: MutableLiveData<ArrayList<User>> = MutableLiveData<ArrayList<User>>()
    var getDashboardCountsForTestExecutionTimeTrendsResponseObservable: MutableLiveData<ArrayList<DashboardGraphs.GetDashboardCountsForTestExecutionTimeTrendsResponse>> = MutableLiveData<ArrayList<DashboardGraphs.GetDashboardCountsForTestExecutionTimeTrendsResponse>>()

    suspend fun getAllProjects() {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllProjectType()
        if (res != null) {
            if (res.isSuccessful) {
                CustomDialoge.closeDialog(context as Activity?)
                projectTypesObservable.value = res.body() as ArrayList<ProjectType>
                Log.d(Companion.TAG, "getAllProjects: ${res.body()!!.size}")
            } else {
                CustomDialoge.closeDialog(context as Activity?)
                CustomToast.showToast(res.message())
                Log.d(TAG, "getAllProjects: Error : ")
            }
        }
    }


    suspend fun getAllRegionsByProject(projectTypeId: Int) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllRegionsByProject(projectTypeId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            regionObservable.value = res.body() as ArrayList<Region>
            Log.d(Companion.TAG, "getAllRegionsByProject: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            CustomToast.showToast(res.message())
            Log.d(TAG, "getAllRegionsByProject: Error : ${res.body()} ")
        }
    }

    suspend fun getAllBrands(regionId: Int) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllBrands(regionId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            brandObservable.value = res.body() as ArrayList<Brand>
            Log.d(Companion.TAG, "getAllBrands: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            CustomToast.showToast(res.message())
            Log.d(TAG, "getAllBrands: Error : ${res.body()} ")
        }
    }


    suspend fun getAllProductNames(
        brandId: Int,
        projectTypeId: Int,
        regionId: Int
    ) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllProductNames(brandId, projectTypeId, regionId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            productNameObservable.value = res.body() as ArrayList<ProductName>
            Log.d(Companion.TAG, "getAllProductNames: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            CustomToast.showToast(res.message())
            Log.d(TAG, "getAllProductNames: Error : ${res.body()} ")
        }
    }


    suspend fun getTestSuiteNameByProjectName(projectName: String) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getTestSuiteNameByProjectName(projectName)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            testSuitObservable.value = res.body() as ArrayList<TestSuit>
            Log.d(Companion.TAG, "getTestSuiteNameByProjectName: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            CustomToast.showToast(res.message())
            Log.d(TAG, "getTestSuiteNameByProjectName: Error : ${res.body()} ")
        }
    }

    suspend fun getAllPlatform(projectTypeId: Int) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllPlatform(projectTypeId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            platformObservable.value = res.body() as ArrayList<Platform>
            Log.d(Companion.TAG, "getAllPlatform: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            CustomToast.showToast(res.message())
            Log.d(TAG, "getAllPlatform: Error : ${res.body()} ")
        }
    }

    suspend fun getAllUsers() {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllUsers()
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            userObservable.value = res.body() as ArrayList<User>
            Log.d(Companion.TAG, "getAllUsers: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            CustomToast.showToast(res.message())
            Log.d(TAG, "getAllUsers: Error : ${res.body()} ")
        }
    }


    suspend fun getDashboardCountsForTestExecutionTimeTrendsRequest(getDashboardCountsForTestExecutionTimeTrendsRequest: DashboardGraphs.GetDashboardCountsForTestExecutionTimeTrendsRequest) {
        Log.d(TAG, "getDashboardCountsForTestExecutionTimeTrendsRequest: API Called")
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        /*var getDashboardCountsForTestExecutionTimeTrendsRequest =
            DashboardGraphs.GetDashboardCountsForTestExecutionTimeTrendsRequest()
        getDashboardCountsForTestExecutionTimeTrendsRequest.projectTypeId = 2
        getDashboardCountsForTestExecutionTimeTrendsRequest.regionId = 1
        getDashboardCountsForTestExecutionTimeTrendsRequest.brandId = "3"
        getDashboardCountsForTestExecutionTimeTrendsRequest.projectName = "JA_Generic Test Suite"
        getDashboardCountsForTestExecutionTimeTrendsRequest.testSuiteName = "JA_SignUp_IOS"
        getDashboardCountsForTestExecutionTimeTrendsRequest.testSuiteId = 803
        getDashboardCountsForTestExecutionTimeTrendsRequest.profileId = 0
        getDashboardCountsForTestExecutionTimeTrendsRequest.platformId = "2"
        getDashboardCountsForTestExecutionTimeTrendsRequest.environment = "STG"
        getDashboardCountsForTestExecutionTimeTrendsRequest.startDate = "2020-12-08"
        getDashboardCountsForTestExecutionTimeTrendsRequest.endDate = "2021-01-03"
*/
        var gson = Gson()
        var js = gson.toJson(getDashboardCountsForTestExecutionTimeTrendsRequest)
        Log.d(TAG, "getDashboardCountsForTestExecutionTimeTrendsRequest: ${js}")

        val res = viewModel.getDashboardCountsForTestExecutionTimeTrends(
            getDashboardCountsForTestExecutionTimeTrendsRequest
        )
        if (res != null) {
            if (res.isSuccessful) {
                CustomDialoge.closeDialog(context as Activity?)
                getDashboardCountsForTestExecutionTimeTrendsResponseObservable.value = res.body() as ArrayList<DashboardGraphs.GetDashboardCountsForTestExecutionTimeTrendsResponse>
                Log.d(
                    Companion.TAG,
                    "getDashboardCountsForTestExecutionTimeTrendsRequest: ${res.body()}"
                )
            } else {
                CustomDialoge.closeDialog(context as Activity?)
                CustomToast.showToast(res.message())
                Log.d(
                    TAG,
                    "getDashboardCountsForTestExecutionTimeTrendsRequest: Error : ${res.body()} "
                )
            }
        } else {
            CustomToast.showToast("Something went wrong...")
        }
    }


    fun registerClicks() {

        binding.llProjectType.setOnClickListener {
            if (this::bottomDlgProjectType.isInitialized) {
                if (bottomDlgProjectType != null) {
                    bottomDlgProjectType.show(parentFragmentManager, TAG)
                }
            }
        }
        binding.llRegion.setOnClickListener {
            if (selectedProjectType != null) {
                binding.tvErrorProjectType.visibility = View.GONE
                Coroutines.main {
                    getAllRegionsByProject(selectedProjectType!!.projectTypeId)
                }
            } else {
                binding.tvErrorProjectType.visibility = View.VISIBLE
            }
//            bottomDlgRegion.show(parentFragmentManager, TAG)
        }
        binding.cvBrand.setOnClickListener {
            if (selectedRegion != null) {
                binding.tvErrorRegion.visibility = View.GONE
                Coroutines.main {
                    getAllBrands(selectedRegion!!.regionId)
                }
            } else {
                binding.tvErrorRegion.visibility = View.VISIBLE
            }
//            bottomDlgBrand.show(parentFragmentManager, TAG)
        }
        binding.llProoductName.setOnClickListener {
            if (selectedProjectType != null && selectedBrand != null && selectedRegion != null) {
                binding.tvErrorProjectType.visibility = View.GONE
                binding.tvErrorRegion.visibility = View.GONE
                binding.tvErrorBrand.visibility = View.GONE
                Coroutines.main {
                    getAllProductNames(
                        selectedBrand!!.brandId,
                        selectedProjectType!!.projectTypeId,
                        selectedRegion!!.regionId
                    )
                }
            } else {
                if (selectedProjectType == null) {
                    binding.tvErrorProjectType.visibility = View.VISIBLE
                }
                if (selectedRegion == null) {
                    binding.tvErrorRegion.visibility = View.VISIBLE
                }
                if (selectedBrand == null) {
                    binding.tvErrorBrand.visibility = View.VISIBLE
                }
            }
//            bottomDlgRegion.show(parentFragmentManager, TAG)
        }
        binding.llTestSuite.setOnClickListener {
            if (selectedProductName != null) {
                binding.tvErrorProductName.visibility = View.GONE
                Coroutines.main {
                    getTestSuiteNameByProjectName(selectedProductName!!.projectName)
                }
            } else {
                binding.tvErrorProductName.visibility = View.VISIBLE
            }
        }
        binding.llPlatform.setOnClickListener {
            if (selectedProjectType != null) {
                binding.tvErrorProjectType.visibility = View.GONE
                Coroutines.main {
                    getAllPlatform(selectedProjectType!!.projectTypeId)
                }
            } else {
                binding.tvErrorProjectType.visibility = View.VISIBLE
            }
        }

        binding.llEnv.setOnClickListener {
            var list: ArrayList<String> = arrayListOf()
            list.add("ENV")
            list.add("STG")
            list.add("DEV")
            list.add("Prod")
            list.add("QA")
            envObservable.value = list
//            bottomDlgEnv.show(parentFragmentManager, TAG)
        }
        binding.llUsers.setOnClickListener {
            Coroutines.main {
                getAllUsers()
            }
//            bottomDlgAll.show(parentFragmentManager, TAG)
        }
        binding.llFrom.setOnClickListener {
            var calendarMax = Calendar.getInstance()
            bottomDlgFromDate = DlgFromDate(this, calendarMax, null)
            bottomDlgFromDate.show(parentFragmentManager, TAG)
//            bottomDlgFromDate.setMaxDate(calendar.time.time)
        }
        binding.llTo.setOnClickListener {
            if (calendarFrom != null) {
                binding.tvErrorFromDate.visibility = View.GONE
                var calendarMax = Calendar.getInstance()
                bottomDlgToDate = DlgToDate(this, calendarMax, calendarFrom)
                bottomDlgToDate.show(parentFragmentManager, TAG)
            } else {
                binding.tvErrorFromDate.visibility = View.VISIBLE
            }
//            bottomDlgFromDate.setMaxDate(calendar.time.time)
        }

        binding.btRun.setOnClickListener {
            doValidate()
            /*Coroutines.main {
                getDashboardCountsForTestExecutionTimeTrendsRequest()
            }*/
        }
    }

    // run button validate
    fun doValidate() {
        val project_type = binding.etProjectType.text.toString()
        val region = binding.etRegion.text.toString()
        val brand = binding.etBrand.text.toString()
        val product_name = binding.etProductName.text.toString()
        val test_suite = binding.etTestSuite.text.toString()
        val platform = binding.etPlatform.text.toString()
        val env = binding.etEnv.text.toString()
        val all = binding.etAll.text.toString()
        val fromDate = binding.etFromDate.text.toString()
        val toDate = binding.etToDate.text.toString()

        if (project_type.isEmpty() || project_type.isNullOrBlank()) {
            binding.tvErrorProjectType.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorProjectType.visibility = View.GONE
        }

        if (region.isEmpty() || region.isNullOrBlank()) {
            binding.tvErrorRegion.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorRegion.visibility = View.GONE
        }

        if (brand.isEmpty() || brand.isNullOrBlank()) {
            binding.tvErrorBrand.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorBrand.visibility = View.GONE
        }

        if (product_name.isEmpty() || product_name.isNullOrBlank()) {
            binding.tvErrorProductName.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorProductName.visibility = View.GONE
        }

        if (test_suite.isEmpty() || test_suite.isNullOrBlank()) {
            binding.tvErrorSuiteName.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorSuiteName.visibility = View.GONE
        }

        if (platform.isEmpty() || platform.isNullOrBlank()) {
            binding.tvErrorPlatform.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorPlatform.visibility = View.GONE
        }

        if (env.isEmpty() || env.isNullOrBlank()) {
            binding.tvErrorEnv.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorEnv.visibility = View.GONE
        }

        if (all.isEmpty() || all.isNullOrBlank()) {
            binding.tvErrorAll.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorAll.visibility = View.GONE
        }

        if (fromDate.isEmpty() || fromDate.isNullOrBlank()) {
            binding.tvErrorFromDate.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorFromDate.visibility = View.GONE
        }

        if (toDate.isEmpty() || toDate.isNullOrBlank()) {
            binding.tvErrorToDate.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorToDate.visibility = View.GONE
        }

        var getDashboardCountsForTestExecutionTimeTrendsRequest =
            DashboardGraphs.GetDashboardCountsForTestExecutionTimeTrendsRequest()
        getDashboardCountsForTestExecutionTimeTrendsRequest.projectTypeId = selectedProjectType!!.projectTypeId
        getDashboardCountsForTestExecutionTimeTrendsRequest.regionId = selectedRegion!!.regionId
        getDashboardCountsForTestExecutionTimeTrendsRequest.brandId = "${selectedBrand!!.brandId}"
        getDashboardCountsForTestExecutionTimeTrendsRequest.projectName = "${selectedProductName!!.projectName}"
        getDashboardCountsForTestExecutionTimeTrendsRequest.testSuiteName = "${selectedTestSuite!!.testSuiteName}"
        getDashboardCountsForTestExecutionTimeTrendsRequest.testSuiteId = selectedTestSuite!!.testSuiteId
        getDashboardCountsForTestExecutionTimeTrendsRequest.profileId = selectedUser!!.profileId
        getDashboardCountsForTestExecutionTimeTrendsRequest.platformId = "${selectedPlatform!!.platformId}"
        getDashboardCountsForTestExecutionTimeTrendsRequest.environment = "${selectedEnv}"
        getDashboardCountsForTestExecutionTimeTrendsRequest.startDate =
        "${SimpleDateFormat("yyyy-MM-dd").format(calendarFrom!!.time.time)}"
        getDashboardCountsForTestExecutionTimeTrendsRequest.endDate =
            "${SimpleDateFormat("yyyy-MM-dd").format(calendarTo!!.time.time)}"


//        CustomToast.showToast("Call Filter API")
        Coroutines.main {
            getDashboardCountsForTestExecutionTimeTrendsRequest(getDashboardCountsForTestExecutionTimeTrendsRequest)
        }
    }
    //bottom dialoe interface ==============================================================================================================

    var selectedProjectType: ProjectType? = null
    var selectedRegion: Region? = null
    var selectedBrand: Brand? = null
    var selectedProductName: ProductName? = null
    var selectedTestSuite: TestSuit? = null
    var selectedPlatform: Platform? = null
    var selectedEnv: String? = null
    var selectedUser: User? = null

    override fun onProjectTypeSelected(type: Int) {
        selectedProjectType = projectTypesObservable.value!!.get(type)
        binding.etProjectType.setText(selectedProjectType!!.projectTypeName)
        bottomDlgProjectType.dismiss()
    }

    override fun onRegionSelected(type: Int) {
        selectedRegion = regionObservable.value!!.get(type)
        binding.etRegion.setText(selectedRegion!!.regionName)
        bottomDlgRegion.dismiss()
    }

    override fun onBrandSelected(type: Int) {
        selectedBrand = brandObservable.value!!.get(type)
        binding.etBrand.setText(selectedBrand!!.brandName)
        bottomDlgBrand.dismiss()
    }

    override fun onProductNameSelected(type: Int) {
        selectedProductName = productNameObservable.value!!.get(type)
        binding.etProductName.setText(selectedProductName!!.projectName)
        bottomDlgProductName.dismiss()
    }

    override fun onTestSuiteSelected(type: Int) {
        selectedTestSuite = testSuitObservable.value!!.get(type)
        binding.etTestSuite.setText(selectedTestSuite!!.testSuiteName)
        bottomDlgTestSuite.dismiss()
    }

    override fun onPlatformSelected(type: Int) {
        selectedPlatform = platformObservable.value!!.get(type)
        binding.etPlatform.setText(selectedPlatform!!.platformName)
        bottomDlgPlatform.dismiss()
    }

    override fun onENVSelected(type: Int) {
        selectedEnv = envObservable.value!!.get(type)
        binding.etEnv.setText(selectedEnv!!)
        bottomDlgEnv.dismiss()
    }

    override fun onAllSelected(type: Int) {
        selectedUser = userObservable.value!!.get(type)
        binding.etAll.setText(selectedUser!!.userName)
        bottomDlgAll.dismiss()
    }

    override fun onFromDateSelected(date: String, calendar: Calendar) {
        calendarFrom = calendar
        binding.etFromDate.setText("${date}")
    }

    override fun onToDateSelected(date: String, calendar: Calendar) {
        calendarTo = calendar
        binding.etToDate.setText("${date}")
    }

    var calendarFrom: Calendar? = null
    var calendarTo: Calendar? = null

    companion object {
        private const val TAG = "FrgTestSuiteExecutionTi"
    }

    override fun onValueSelected(e: Entry?, h: Highlight?) {

    }

    override fun onNothingSelected() {
        TODO("Not yet implemented")
    }
}
