package com.whirlpool.prodigio_app.viewmodel

import androidx.lifecycle.ViewModel
import com.whirlpool.prodigio_app.repository.Repository

class MonthlyExecutionStatusViewModel(
    val repository: Repository,
) : ViewModel() {

}