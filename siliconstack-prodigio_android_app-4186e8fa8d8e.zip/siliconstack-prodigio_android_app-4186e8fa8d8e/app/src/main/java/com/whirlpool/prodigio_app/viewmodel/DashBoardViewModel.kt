package com.whirlpool.prodigio_app.viewmodel

import androidx.lifecycle.ViewModel
import com.whirlpool.prodigio_app.communication.response.*
import com.whirlpool.prodigio_app.repository.Repository
import okhttp3.ResponseBody
import retrofit2.Response

class DashBoardViewModel(
    val repository: Repository,
) : ViewModel() {


    //get dash board project types
    suspend fun getDashboardCounts(
    ): Response<List<DashboarProjectType>> {
        return repository.getDashboardCounts()
    }


}