package com.whirlpool.prodigio_app.view.dialoges

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.deishelon.roundedbottomsheet.RoundedBottomSheetDialogFragment
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.databinding.DlgCalendarBinding
import java.text.SimpleDateFormat
import java.util.*

class DlgToDate(
    var mListner: BottomSheetDlgToDateListner,
    var calendarMax: Calendar? = null,
    var calendarMin: Calendar? = null
) : RoundedBottomSheetDialogFragment() {

    lateinit var binding: DlgCalendarBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding =
            DataBindingUtil.inflate(inflater, R.layout.dlg_calendar, container, false)
        val rootView = binding.root
        init()
        reisterClicks()
        return rootView
    }

    fun init() {
        if (calendarMax != null) {
            binding.calender.maxDate = calendarMax!!.time.time
        }
        if (calendarMin != null) {
            binding.calender.minDate = calendarMin!!.time.time
        }
        binding.calender.setOnDateChangeListener { view, year, month, dayOfMonth ->
            // Note that months are indexed from 0. So, 0 means January, 1 means february, 2 means march etc.
            val msg = "Selected date is " + dayOfMonth + "/" + (month + 1) + "/" + year
            Log.d(TAG, "init: Date - ${msg}")
//            mListner.onToDateSelected("" + dayOfMonth + "-" + (month + 1) + "-" + year)
            var calendarSelected = Calendar.getInstance()
            calendarSelected.set(Calendar.YEAR,year)
            calendarSelected.set(Calendar.MONTH,month)
            calendarSelected.set(Calendar.DAY_OF_MONTH,dayOfMonth)
            Log.d(TAG, "init: Date - ${msg}")
            Log.d(TAG, "init: Selected Date - ${SimpleDateFormat("dd-MM-yyyy").format(calendarSelected.time)}")
            mListner.onToDateSelected("${SimpleDateFormat("dd-MM-yyyy").format(calendarSelected.time)}",calendarSelected)
            dismiss()
        }

    }

    private fun reisterClicks() {

    }

    fun setMaxDate(maxDate: Long) {
        binding.calender.maxDate = maxDate
    }

    fun setMinDate(minDate: Long) {
        Handler(Looper.getMainLooper()).postDelayed({
            binding.calender.minDate = minDate
        }, 500)
    }

    interface BottomSheetDlgToDateListner {
        fun onToDateSelected(date: String,calendar: Calendar)
    }

    companion object {
        private const val TAG = "DlgToDate"
    }

}