package com.whirlpool.prodigio_app.communication.response

import com.google.gson.annotations.SerializedName

data class DashboardCountsForTestExecutionTimeTrends (
    @SerializedName("brandId")
    var brandId: Int?=null,
    @SerializedName("endDate")
    var endDate: String?=null,
    @SerializedName("environment")
    var environment: String?=null,
    @SerializedName("platformId")
    var platformId: Int?=null,
    @SerializedName("profileId")
    var profileId: Int?=null,
    @SerializedName("projectName")
    var projectName: String ,
    @SerializedName("projectTypeId")
    var projectTypeId: Int?=null,
    @SerializedName("regionId")
    var regionId: Int?=null,
    @SerializedName("startDate")
    var startDate: String?=null,
    @SerializedName("testSuiteId")
    var testSuiteId: Int?=null,
)
