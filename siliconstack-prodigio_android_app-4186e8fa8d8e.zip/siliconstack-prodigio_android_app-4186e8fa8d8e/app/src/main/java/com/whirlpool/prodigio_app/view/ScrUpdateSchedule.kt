package com.whirlpool.prodigio_app.view

import android.app.TimePickerDialog
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils.substring
import android.util.Log
import android.view.View
import android.widget.TimePicker
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.Constant
import com.whirlpool.prodigio_app.communication.response.OfRecordsSchedule
import com.whirlpool.prodigio_app.databinding.ActivityScrUpdateScheduleBinding
import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.utils.CustomDialoge
import com.whirlpool.prodigio_app.utils.CustomToast
import com.whirlpool.prodigio_app.utils.DateUtils
import com.whirlpool.prodigio_app.view.dialoges.DlgDropDownMonthAndWeek
import com.whirlpool.prodigio_app.view.dialoges.DlgDropDownRecurrence
import com.whirlpool.prodigio_app.view.dialoges.DlgFromDate
import com.whirlpool.prodigio_app.view.dialoges.DlgToDate
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModel
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModelFactory
import org.json.JSONObject
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance
import java.sql.Date
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap
import com.google.gson.Gson


class ScrUpdateSchedule : AppCompatActivity(), KodeinAware,
    DlgFromDate.BottomSheetDlgFromDateListner,
    DlgToDate.BottomSheetDlgToDateListner,
    DlgDropDownRecurrence.BottomSheetDlgRecurrenceListner,
    DlgDropDownMonthAndWeek.BottomSheetDlgMonthAndWeekListner {

    private val TAG = ScrExecutionScheduledSub::class.java.name

    override val kodein by kodein()

    lateinit var binding: ActivityScrUpdateScheduleBinding
    lateinit var viewModel: ExecutionViewModel
    lateinit var ofRecordsSchedule: OfRecordsSchedule

    // bottom dlg
    lateinit var bottomDlgFromDate: DlgFromDate
    lateinit var bottomDlgToDate: DlgToDate
    lateinit var bottomDlgRecurrence: DlgDropDownRecurrence
    lateinit var bottomDlgDropDownMonthAndWeek: DlgDropDownMonthAndWeek

    //dates flag
    var timeLine = false
    var endsIn = false

    //time picker
    var mTimePicker: TimePickerDialog? = null
    val mcurrentTime = Calendar.getInstance()
    val hour = mcurrentTime.get(Calendar.HOUR)
    val minute = mcurrentTime.get(Calendar.MINUTE)


    //week flag
    var sunday: Boolean = false
    var monday: Boolean = false
    var tuesday: Boolean = false
    var wednesday: Boolean = false
    var thursday: Boolean = false
    var friday: Boolean = false
    var saturday: Boolean = false

    //variables for api
    lateinit var parsed_startdate: String
    lateinit var parsed_endtdate: String
    lateinit var execuTime: String
    var frequency: Int = 0

    lateinit var daysOfWeek: ArrayList<String>

    //for bottom calendar
    var calendarToday = Calendar.getInstance()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = resources.getColor(R.color.white)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            window.statusBarColor = Color.WHITE
        }
        val factory: ExecutionViewModelFactory by instance() // dependency injection
        viewModel = ViewModelProvider(this, factory).get(ExecutionViewModel::class.java)
        binding =
            DataBindingUtil.setContentView(this, R.layout.activity_scr_update_schedule)

        getIntentData()
        initUI()
        setData()
        reisterClicks()
    }

    private fun initUI() {
        bottomDlgToDate = DlgToDate(this)
        bottomDlgRecurrence = DlgDropDownRecurrence(this)
        bottomDlgDropDownMonthAndWeek = DlgDropDownMonthAndWeek(this)

        daysOfWeek = ArrayList<String>()

        //time picker
        mTimePicker = TimePickerDialog(this, object : TimePickerDialog.OnTimeSetListener {
            override fun onTimeSet(view: TimePicker?, hourOfDay: Int, minute: Int) {
                var am_pm = ""

                val datetime = Calendar.getInstance()
                datetime[Calendar.HOUR_OF_DAY] = hourOfDay
                datetime[Calendar.MINUTE] = minute

                if (datetime[Calendar.AM_PM] === Calendar.AM) am_pm =
                    "AM" else if (datetime[Calendar.AM_PM] === Calendar.PM) am_pm = "PM"
                val strHrsToShow =
                    if (datetime[Calendar.HOUR] == 0) "12" else datetime[Calendar.HOUR].toString() + ""


                binding.etTimeLineTime.setText("$hourOfDay : $minute $am_pm")
                execuTime = "$hourOfDay:$minute"
                binding.tvErrorTimeLineTime.visibility = View.GONE
            }
        }, hour, minute, false)
    }

    fun setData() {

        execuTime = ofRecordsSchedule.time.substring(0, 5)
        Log.d(TAG, "setData: time : " + ofRecordsSchedule.time)
        Log.d(TAG, "setData: time parsed : " + execuTime)
        Log.d(TAG, "setData: startDate : " + ofRecordsSchedule.startDate)
        parsed_startdate = DateUtils.changeDateTimeToDate(ofRecordsSchedule.startDate).toString()
        Log.d(TAG, "setData: parsedStart date : " + parsed_startdate)
        binding.etTimeLineDate.setText(parsed_startdate)
        binding.etTimeLineTime.setText(execuTime)
        binding.etRepeatEvery.setText(ofRecordsSchedule.repeatSchedule.toString())
        if (ofRecordsSchedule.daysOfWeek.isNullOrBlank()) {
            binding.etMonth.setText("Months")
        } else {
            binding.etMonth.setText("Weeks")
        }

    }

    private fun reisterClicks() {
        binding.llBack.setOnClickListener { finish() }
        binding.cvTimeLineDate.setOnClickListener {
            bottomDlgFromDate = DlgFromDate(this)
            bottomDlgFromDate.setMinDate(calendarToday.time.time)
            bottomDlgFromDate.show(supportFragmentManager, TAG)

            timeLine = true
            endsIn = false
        }

        binding.cvRecurrence.setOnClickListener {
            bottomDlgRecurrence.show(supportFragmentManager, TAG)
        }

        binding.cvTimeLineTime.setOnClickListener { mTimePicker?.show() }

        binding.cvMonths.setOnClickListener {
            bottomDlgDropDownMonthAndWeek.show(supportFragmentManager, TAG)
        }

        binding.cvEndsOn.setOnClickListener {
            bottomDlgFromDate = DlgFromDate(this)
            bottomDlgFromDate.setMinDate(calendarToday.time.time)
            bottomDlgFromDate.show(supportFragmentManager, TAG)
            endsIn = true
            timeLine = false
        }

        //week click handle
        binding.cvSunday.setOnClickListener {
            sunday = !sunday
            if (sunday) {
                binding.cvSunday.setCardBackgroundColor(
                    ContextCompat.getColor(
                        this,
                        R.color.colorPrimary
                    )
                )
                daysOfWeek.add("Sunday")
            } else {
                binding.cvSunday.setCardBackgroundColor(
                    ContextCompat.getColor(
                        this,
                        R.color.grey5
                    )
                )
                daysOfWeek.remove("Sunday")
            }
            checkIfDaysSelected()
        }
        binding.cvMonday.setOnClickListener {
            monday = !monday
            if (monday) {
                binding.cvMonday.setCardBackgroundColor(
                    ContextCompat.getColor(
                        this,
                        R.color.colorPrimary
                    )
                )
                daysOfWeek.add("Monday")
            } else {
                binding.cvMonday.setCardBackgroundColor(
                    ContextCompat.getColor(
                        this,
                        R.color.grey5
                    )
                )
                daysOfWeek.remove("Monday")
            }
            checkIfDaysSelected()
        }
        binding.cvTuesday.setOnClickListener {
            tuesday = !tuesday
            if (tuesday) {
                binding.cvTuesday.setCardBackgroundColor(
                    ContextCompat.getColor(
                        this,
                        R.color.colorPrimary
                    )
                )
                daysOfWeek.add("Tuesday")
            } else {
                binding.cvTuesday.setCardBackgroundColor(
                    ContextCompat.getColor(
                        this,
                        R.color.grey5
                    )
                )
                daysOfWeek.remove("Tuesday")
            }
            checkIfDaysSelected()
        }
        binding.cvWednesday.setOnClickListener {
            wednesday = !wednesday
            if (wednesday) {
                binding.cvWednesday.setCardBackgroundColor(
                    ContextCompat.getColor(
                        this,
                        R.color.colorPrimary
                    )
                )
                daysOfWeek.add("Wednesday")
            } else {
                binding.cvWednesday.setCardBackgroundColor(
                    ContextCompat.getColor(
                        this,
                        R.color.grey5
                    )
                )
                daysOfWeek.remove("Wednesday")
            }
            checkIfDaysSelected()
        }
        binding.cvThursday.setOnClickListener {
            thursday = !thursday
            if (thursday) {
                binding.cvThursday.setCardBackgroundColor(
                    ContextCompat.getColor(
                        this,
                        R.color.colorPrimary
                    )
                )
                daysOfWeek.add("Thursday")
            } else {
                binding.cvThursday.setCardBackgroundColor(
                    ContextCompat.getColor(
                        this,
                        R.color.grey5
                    )
                )
                daysOfWeek.remove("Thursday")
            }
            checkIfDaysSelected()
        }
        binding.cvFriday.setOnClickListener {
            friday = !friday
            if (friday) {
                binding.cvFriday.setCardBackgroundColor(
                    ContextCompat.getColor(
                        this,
                        R.color.colorPrimary
                    )
                )
                daysOfWeek.add("Friday")
            } else {
                binding.cvFriday.setCardBackgroundColor(
                    ContextCompat.getColor(
                        this,
                        R.color.grey5
                    )
                )
                daysOfWeek.remove("Friday")
            }
            checkIfDaysSelected()
        }
        binding.cvSaturday.setOnClickListener {
            saturday = !saturday
            if (saturday) {
                binding.cvSaturday.setCardBackgroundColor(
                    ContextCompat.getColor(
                        this,
                        R.color.colorPrimary
                    )
                )
                daysOfWeek.add("Saturday")
            } else {
                binding.cvSaturday.setCardBackgroundColor(
                    ContextCompat.getColor(
                        this,
                        R.color.grey5
                    )
                )
                daysOfWeek.remove("Saturday")
            }
            checkIfDaysSelected()
        }

        binding.cvUpdate.setOnClickListener { doValidate() }
    }

    fun getIntentData() {
        val intent = intent.extras
        ofRecordsSchedule = intent?.getSerializable("OfRecordsSchedule") as OfRecordsSchedule
        Log.d(
            TAG,
            "getIntentData: exeHeaderId : ${ofRecordsSchedule.exeHeaderId} exeHistoryId : ${ofRecordsSchedule.exeHistoryId} "
        )
    }



    override fun onFromDateSelected(date: String,calendar: Calendar) {
        calendarFrom = calendar
//        binding.etFromDate.setText("${date}")
        if (timeLine) {
            parsed_startdate = date
            binding.etTimeLineDate.setText("${parsed_startdate}")
            binding.tvErrorTimeLineDate.visibility = View.GONE
            Log.d(TAG, "onFromDateSelected: after parse: $parsed_startdate")
        } else {
            parsed_endtdate = date
            binding.etEndsOn.setText("${parsed_endtdate}")
            binding.tvErrorEndsOn.visibility = View.GONE
            Log.d(TAG, "onFromDateSelected: after parse: $parsed_endtdate")
        }
    }

    override fun onToDateSelected(date: String,calendar: Calendar) {
        calendarTo = calendar
//        binding.etToDate.setText("${date}")
    }

    var calendarFrom: Calendar? = null
    var calendarTo: Calendar? = null

    override fun onRecurrenceSelected(value: String) {
        if (value.equals("Custom")) {
            binding.llCustom.visibility = View.VISIBLE
        } else {
            binding.llCustom.visibility = View.GONE
        }

        when (value) {
            "Does not repeat" -> {
                frequency = 0
            }
            "Daily" -> {
                frequency = 1
            }
            "Weekly Custom" -> {
                frequency = 2
            }
        }

        binding.etRecurrence.setText(value)
        binding.tvErrorRecurrence.visibility = View.GONE
        bottomDlgRecurrence.dismiss()
    }

    override fun onMonthAndWeekeSelected(value: String) {
        if (value.equals("Week")) {
            binding.llWeeks.visibility = View.VISIBLE
            frequency = 3
        } else {
            binding.llWeeks.visibility = View.GONE
            frequency = 4
        }
        binding.etMonth.setText("$value")
        binding.tvErrorRepeatEvery.visibility = View.GONE
        binding.tvErrorMonths.visibility = View.GONE

        bottomDlgDropDownMonthAndWeek.dismiss()
    }

    fun doValidate() {
        val isPause = binding.scPause.isChecked
        val timeline_date = binding.etTimeLineDate.text.toString()
        val timeline_time = binding.etTimeLineTime.text.toString()
        val recurrence = binding.etRecurrence.text.toString()
        val repear_count = binding.etRepeatEvery.text.toString()
        val repear_monthAndweek = binding.etMonth.text.toString()
        val endsOn = binding.etEndsOn.text.toString()


        if (timeline_date.isNullOrBlank()) {
            binding.tvErrorTimeLineDate.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorTimeLineDate.visibility = View.GONE
        }

        if (timeline_time.isNullOrBlank()) {
            binding.tvErrorTimeLineTime.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorTimeLineTime.visibility = View.GONE
        }

        if (recurrence.isNullOrBlank()) {
            binding.tvErrorRecurrence.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorRecurrence.visibility = View.GONE
        }

        if (binding.llCustom.visibility == View.VISIBLE) {
            if (repear_count.isNullOrBlank()) {
                binding.tvErrorRepeatEvery.visibility = View.VISIBLE
                return
            } else {
                binding.tvErrorRepeatEvery.visibility = View.GONE
            }

            if (repear_monthAndweek.isNullOrBlank()) {
                binding.tvErrorMonths.visibility = View.VISIBLE
                return
            } else {
                binding.tvErrorMonths.visibility = View.GONE
            }

            if (binding.llWeeks.visibility == View.VISIBLE) {
                if (sunday || monday || tuesday || wednesday || thursday || friday || saturday) {
                    binding.tvErrorWeek.visibility = View.GONE
                } else {
                    binding.tvErrorWeek.visibility = View.VISIBLE
                    return
                }
            }

            if (endsOn.isNullOrBlank()) {
                binding.tvErrorEndsOn.visibility = View.VISIBLE
                return
            } else {
                binding.tvErrorEndsOn.visibility = View.GONE
            }
        }

        val params: HashMap<String?, String?> = HashMap<String?, String?>()
        params.put("active", isPause.toString())
        params.put("startDate", DateUtils.changeDateToServerDate(parsed_startdate))
        if (binding.llCustom.visibility == View.VISIBLE) {
            params.put("endDate", DateUtils.changeDateToServerDate(parsed_endtdate))
        } else {
            params.put(
                "endDate",
                DateUtils.changeDateTimeToDateForServer(ofRecordsSchedule.endDate)
            )
        }
        params.put("executeTime", execuTime + ":Asia/Calcutta")
        params.put("frequency", frequency.toString())
        params.put("repeatSchedule", repear_count)
        params.put("exeHeaderId", "14045")
        params.put("userId", "162")
        if (daysOfWeek.size > 0) {
            params.put(
                "daysOfWeek",
                daysOfWeek.toString().replace("[", "").replace("]", "").lowercase()
            )
        } else {
            if (ofRecordsSchedule.daysOfWeek.isNullOrBlank()) {
                params.put("daysOfWeek", "")
            } else {
                params.put("daysOfWeek", ofRecordsSchedule.daysOfWeek)
            }
        }
        val gson = Gson()
        val body = gson.toJson(params)


        Log.d(TAG, "doValidate: params : ${body}")
        call_updateSchedule(params)

    }


    fun call_updateSchedule(params: HashMap<String?, String?>) {
        Coroutines.main {
            CustomDialoge.showDialog(this, Constant.PROGRESS)
            val res = viewModel.updateScheduledJOb(params)
            Log.d(TAG, "call_updateSchedule: res " + res)
            Log.d(TAG, "call_updateSchedule: res " + res.body().toString())
            CustomDialoge.closeDialog(this)
            if (res.isSuccessful) {
                val resObject = JSONObject(res.body().toString())
                val status = resObject.getInt("Status")
                if (status == 1) {
                    CustomToast.showToast("Schedule data updated.")
                    ScrExecutionScheduled.data.value = true
                    finish()
                } else {
                    CustomToast.showToast("Failed to update schedule data")
                }
            } else {
                CustomToast.showToast(res.message())
            }
        }
    }

    fun checkIfDaysSelected() {
        if (sunday || monday || tuesday || wednesday || thursday || friday || saturday) {
            binding.tvErrorWeek.visibility = View.GONE
        } else {
            binding.tvErrorWeek.visibility = View.VISIBLE
        }
    }

}