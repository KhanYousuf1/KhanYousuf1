package com.whirlpool.prodigio_app.view.dialoges

import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.deishelon.roundedbottomsheet.RoundedBottomSheetDialogFragment
import com.whirlpool.prodigio_app.AppApplication
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.ExtentReportList
import com.whirlpool.prodigio_app.communication.response.OfRecords
import com.whirlpool.prodigio_app.databinding.DlgExtentReportBinding
import com.whirlpool.prodigio_app.databinding.DlgLogoutBinding
import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.utils.CustomDialoge
import com.whirlpool.prodigio_app.utils.CustomToast
import com.whirlpool.prodigio_app.view.ScrDisplayAppiumLogFile
import com.whirlpool.prodigio_app.view.ScrDisplayExtentReport
import com.whirlpool.prodigio_app.view.adapter.ExecutionHistoryAdapter
import com.whirlpool.prodigio_app.view.adapter.ExtentReportsAdapter
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModel
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModelFactory
import io.reactivex.internal.operators.maybe.MaybeToPublisher.instance
import okhttp3.ResponseBody
import org.json.JSONException
import org.json.JSONObject

import org.kodein.di.Kodein
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance
import java.io.*


class DlgExtentReport() : RoundedBottomSheetDialogFragment(), KodeinAware,
    ExtentReportsAdapter.OnExtentReportItemClickListner {

    private val TAG = DlgExtentReport::class.java.name

    override val kodein: Kodein by kodein(AppApplication.appContext)
    lateinit var binding: DlgExtentReportBinding
    lateinit var viewModel: ExecutionViewModel

    lateinit var ofRecords: OfRecords
    lateinit var extentReportList: ExtentReportList


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val factory: ExecutionViewModelFactory by instance() // dependency injection
        viewModel = ViewModelProvider(this, factory).get(ExecutionViewModel::class.java)

        binding = DataBindingUtil.inflate(inflater, R.layout.dlg_extent_report, container, false)
        val rootView = binding.root

        reisterClicks()
        return rootView
    }

    fun setData(ofRecords: OfRecords) {
        this.ofRecords = ofRecords
        Handler(Looper.getMainLooper()).postDelayed({// display after 2 seconds otherwise binding exception will occur
            binding.tvExeName.text = ofRecords.jobName
            binding.tvJobStatus.text = ofRecords.jobStatus.toString()
            binding.tvStartTime.text = ofRecords.startTime
            binding.tvEndTime.text = ofRecords.endTime
            Coroutines.main {
                callAPi()
            }
        }, 500)
    }

    suspend fun callAPi() {
        val res = viewModel.getExtentReportList()
        Log.d(TAG, "callAPi: res : $res")
        Log.d(TAG, "callAPi: res : ${res.body()}")
        if (res.isSuccessful) {
            binding.rvReports.apply {
                layoutManager =
                    LinearLayoutManager(requireContext(), RecyclerView.VERTICAL, false)

                adapter =
                    ExtentReportsAdapter(
                        this@DlgExtentReport, res.body() as ArrayList<ExtentReportList>
                    )
                binding.rvReports.adapter = adapter
                binding.rvReports.adapter?.notifyDataSetChanged()
            }
        } else {
            CustomToast.showToast(res.message())
        }
    }

    private fun reisterClicks() {

        binding.ivDownloadAppiumLog.setOnClickListener {
            Coroutines.main {
                CustomDialoge.showDialog(requireActivity(), "Downloading...")
                val res =
                    viewModel.downloadAppiumLogFile(ofRecords.exeHeaderId, ofRecords.exeHistoryId)

                Log.d(TAG, "reisterClicks: download appium log : $res")
                Log.d(TAG, "reisterClicks: download appium log body : ${res.body()}")
                if (res.isSuccessful) {
                    ScrDisplayAppiumLogFile.data.value = res.body()
                    ScrDisplayAppiumLogFile.data_title.value = "Appium Log File"
                    CustomDialoge.closeDialog(requireActivity())
                    val intent = Intent(requireContext(), ScrDisplayAppiumLogFile::class.java)
                    startActivity(intent)
                } else {
                    CustomDialoge.closeDialog(requireActivity())
                    CustomToast.showToast(res.message())
                }

            }
        }


        binding.ivDownloadExecutionLog.setOnClickListener {
            Coroutines.main {
                Log.d(TAG, "reisterClicks: jenkins job id : " + ofRecords.jenkinsJobId.toString())
                try {
                    CustomDialoge.showDialog(requireActivity(), "Downloading...")
                    val params = HashMap<String?, String?>()
                    /*params.put("executionHeaderId", "4")
                    params.put("executionHistoryId", "4")
                    params.put("fileName", "min_72_New_User_Registration-data.xls")
                    params.put("datasetName", "New User Registration-data")
                    params.put("testSuiteId", "96")
                    val res = viewModel.downloadExecutionFiles(params)*/
                    //params.put("jenkinsJobId", ofRecords.jenkinsJobId.toString())
                    params.put("jenkinsJobId", "1544")
                    val res = viewModel.downloadExecutionLogFiles(params)
                    Log.d(TAG, "downloadExecution: res : $res")
                    Log.d(TAG, "downloadExecution: res body: ${res.body()}")
                    if (res.isSuccessful) {
                        try {
                            val respo = JSONObject(res.body().toString())

                            ScrDisplayAppiumLogFile.data.value = respo.getString("Message")
                            ScrDisplayAppiumLogFile.data_title.value = "Execution Log File"
                            CustomDialoge.closeDialog(requireActivity())
                            val intent =
                                Intent(requireContext(), ScrDisplayAppiumLogFile::class.java)
                            startActivity(intent)
                        } catch (e: JSONException) {
                            e.printStackTrace()
                            Log.d(TAG, "reisterClicks: JSONException : " + e.message)
                        }
                    } else {
                        CustomDialoge.closeDialog(requireActivity())
                        CustomToast.showToast(res.message())
                    }
                } catch (e: Exception){
                    e.printStackTrace()
                    CustomDialoge.closeDialog(requireActivity())
                    CustomToast.showToast("Jenkins Jod Id not found")
                }
            }
        }
    }


    override fun reportItemClicked(extentReportList: ExtentReportList) {
        this.extentReportList = extentReportList
        Coroutines.main {
            CustomDialoge.showDialog(requireActivity(), "Downloading...")
            val file_name =
                "https%3A%2F%2Fprodigio-images.s3.us-east-2.amazonaws.com%2Fserverless-extentReport%2FWindchill%2520part%2520creation_Add%2520Part%2520to%2520Windchill%253BGoogle%2520Chrome%253BJennAir-4_5.1-staging-release.apk%253B1_4_4_37.html"
            val res = viewModel.downloadExtendReportFile(file_name)
            CustomDialoge.closeDialog(requireActivity())
            Log.d(TAG, "reportItemClicked: res : $res")
            Log.d(TAG, "reportItemClicked: res body: ${res.body()}")
            if (res.isSuccessful) {
                ScrDisplayExtentReport.html_data.value = res.body()
                CustomDialoge.closeDialog(requireActivity())
                val intent = Intent(requireContext(), ScrDisplayExtentReport::class.java)
                startActivity(intent)
            } else {
                CustomToast.showToast(res.message())
            }
        }
    }

    fun saveFile(body: ResponseBody?, pathWhereYouWantToSaveFile: String): String {
        if (body == null)
            return ""
        var input: InputStream? = null
        try {
            input = body.byteStream()
            //val file = File(getCacheDir(), "cacheFileAppeal.srl")
            val fos = FileOutputStream(pathWhereYouWantToSaveFile)
            fos.use { output ->
                val buffer = ByteArray(4 * 1024) // or other buffer size
                var read: Int
                while (input.read(buffer).also { read = it } != -1) {
                    output.write(buffer, 0, read)
                }
                output.flush()
            }
            return pathWhereYouWantToSaveFile
        } catch (e: Exception) {
            Log.e("saveFile", e.toString())
        } finally {
            input?.close()
        }
        return ""
    }


}