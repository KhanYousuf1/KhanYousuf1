package com.whirlpool.prodigio_app.viewmodel

import androidx.lifecycle.ViewModel
import com.whirlpool.prodigio_app.communication.response.*
import com.whirlpool.prodigio_app.repository.Repository
import okhttp3.ResponseBody
import retrofit2.Response

class ExecutionViewModel(
    val repository: Repository,
) : ViewModel() {


    //api's
    suspend fun getExecutionHistory(
        pageNo: Int,
        searched_text: String
    ): Response<ExecutionHistory> {
        return repository.getExecutionHistory(pageNo, searched_text)
    }

    //delete Schedule jobs
    suspend fun deleteExecutionHistoryById(exeHistoryId: String): Response<String> {
        return repository.deleteExecutionHistoryById(exeHistoryId)
    }

    //Check for duplicate record for execution history name
    suspend fun checkForDuplicateForExecutionHistoryName(params: HashMap<String?, String?> = HashMap()): Response<String> {
        return repository.checkForDuplicateForExecutionHistoryName(params)
    }

    //Check for duplicate record for Run Job
    suspend fun checkForDuplicateForRunJob(params: HashMap<String?, String?> = HashMap()): Response<String> {
        return repository.checkForDuplicateForExecutionHistoryName(params)
    }

    //change execution history name
    suspend fun changeTestExecutionName(params: HashMap<String?, String?> = HashMap()): Response<String> {
        return repository.changeTestExecutionName(params)
    }

    //re-execute job from execution history
    suspend fun reExecuteJob(params: HashMap<String?, String?> = HashMap()): Response<String> {
        return repository.reExecuteJob(params)
    }

    suspend fun getExecutionHistorySub(
        exeHeaderId: String,
        exeHistoryId: String
    ): Response<List<ExecutionHistorySubItem>> {
        return repository.getExecutionHistorySub(exeHeaderId, exeHistoryId)
    }

    suspend fun getExecutionDashbaordCount(
    ): Response<ExecutionDashboardCount> {
        return repository.getExecutionDashboardCount()
    }

    suspend fun getExtentReportList(
    ): Response<List<ExtentReportList>> {
        return repository.getExtentReportList()
    }

    suspend fun downloadAppiumLogFile(
        exeHeaderId: Int, exeHistoryId: Int
    ): Response<String> {
        return repository.downloadAppiumLogFile(exeHeaderId, exeHistoryId)
    }

    suspend fun downloadExtendReportFile(
        file_name: String
    ): Response<String> {
        return repository.downloadExtendReportFile(file_name)
    }

    suspend fun downloadExecutionFiles(
        params: HashMap<String?, String?>
    ): Response<String> {
        return repository.downloadExecutionFiles(params)
    }

    suspend fun downloadExecutionLogFiles(
        params: HashMap<String?, String?>
    ): Response<String> {
        return repository.downloadExecutionLogFiles(params)
    }


    //get Schedule jobs
    suspend fun getScheduledJOb(pageNo: Int, searchBy: String): Response<ExecutionSchedule> {
        return repository.getExecutionSchedule(pageNo, searchBy)
    }

    //delete Schedule jobs
    suspend fun deleteScheduledJOb(exeHeaderId: Int): Response<String> {
        return repository.deleteExecutionSchedule(exeHeaderId)
    }

    //update schedule job
    suspend fun updateScheduledJOb(params: HashMap<String?, String?> = HashMap()): Response<String> {
        return repository.updateSchedule(params)
    }

    //execution inProgress
    suspend fun getRunningJobs(
    ): Response<List<ExecutionInProgress>> {
        return repository.getRunningJobs()
    }

    //getAll Document
    suspend fun getAllDocument(
    ): Response<List<Document>> {
        return repository.getAllDocument()
    }

    suspend fun stopJenkinJob(
        params: HashMap<String?, String?>
    ): Response<String> {
        return repository.stopJenkinJob(params)
    }

    suspend fun updatestoppedJenkinJob(
        params: HashMap<String?, String?>
    ): Response<String> {
        return repository.updatestoppedJenkinJob(params)
    }

    suspend fun getScheduleListDeatils(
        params: HashMap<String?, String?>
    ): Response<List<ScheduleDetails>> {
        return repository.getScheduleListDeatils(params)
    }

}