package com.whirlpool.prodigio_app.view.fragments

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModelProvider
import com.whirlpool.prodigio_app.AppApplication
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.*
import com.whirlpool.prodigio_app.databinding.FrgRunJobStep1Binding
import com.whirlpool.prodigio_app.databinding.FrgRunJobStep2Binding
import com.whirlpool.prodigio_app.databinding.LayoutRunJobCounterHeaderBinding
import com.whirlpool.prodigio_app.databinding.LayoutRunJobNextPreviousButtonsBinding
import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.utils.CustomDialoge
import com.whirlpool.prodigio_app.utils.CustomToast
import com.whirlpool.prodigio_app.view.dialoges.*
import com.whirlpool.prodigio_app.viewmodel.DashboardGraphViewModel
import com.whirlpool.prodigio_app.viewmodel.DashboardGraphViewModelFactory
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModel
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModelFactory
import org.kodein.di.Kodein
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance
import java.util.*
import kotlin.collections.ArrayList

class FrgRunJobStep2 : Fragment(), KodeinAware,
    DlgDropDownProjectType.BottomSheetDlgProjectTypeListner,
    DlgDropDownBrand.BottomSheetDlgBrandListner,
    DlgDropDownRegion.BottomSheetDlgRegionListner,
    DlgDropDownProductName.BottomSheetDlgProductNameListner,
    DlgDropDownPlatform.BottomSheetDlgPlatformListner,
    DlgDropDownENV.BottomSheetDlgENVListner{

    var projectTypesObservable: MutableLiveData<ArrayList<ProjectType>> =
        MutableLiveData<ArrayList<ProjectType>>()
    var regionObservable: MutableLiveData<ArrayList<Region>> = MutableLiveData<ArrayList<Region>>()
    var brandObservable: MutableLiveData<ArrayList<Brand>> = MutableLiveData<ArrayList<Brand>>()
    var productNameObservable: MutableLiveData<ArrayList<ProductName>> =
        MutableLiveData<ArrayList<ProductName>>()
    var testSuitObservable: MutableLiveData<ArrayList<TestSuit>> =
        MutableLiveData<ArrayList<TestSuit>>()
    var platformObservable: MutableLiveData<ArrayList<Platform>> =
        MutableLiveData<ArrayList<Platform>>()
    var envObservable: MutableLiveData<ArrayList<String>> = MutableLiveData<ArrayList<String>>()
    var userObservable: MutableLiveData<ArrayList<User>> = MutableLiveData<ArrayList<User>>()
    var getDashboardSuiteCountTrendObservable: MutableLiveData<DashboardGraphs.GetDashboardSuiteCountTrendResponse> =
        MutableLiveData<DashboardGraphs.GetDashboardSuiteCountTrendResponse>()

    //bottomSheetDialoge
    lateinit var bottomDlgProjectType: DlgDropDownProjectType
    lateinit var bottomDlgBrand: DlgDropDownBrand
    lateinit var bottomDlgRegion: DlgDropDownRegion
    lateinit var bottomDlgPlatform: DlgDropDownPlatform
    lateinit var bottomDlgEnv: DlgDropDownENV
    lateinit var bottomDlgProductName: DlgDropDownProductName
    lateinit var bottomDlgFromDate: DlgFromDate
    lateinit var bottomDlgToDate: DlgToDate



    private val TAG = FrgExecution::class.java.name

    override val kodein: Kodein by kodein(AppApplication.appContext)

    lateinit var viewModel: DashboardGraphViewModel


    lateinit var binding: FrgRunJobStep2Binding
    lateinit var counterHeaderBindig: LayoutRunJobCounterHeaderBinding
    lateinit var nextPreviuosButtonsBinding: LayoutRunJobNextPreviousButtonsBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        val factory: DashboardGraphViewModelFactory by instance()  // dependency injection
        viewModel =
            ViewModelProvider(this, factory).get(DashboardGraphViewModel::class.java)

        binding = DataBindingUtil.inflate(
            inflater, R.layout.frg_run_job_step_2, container, false
        )
        counterHeaderBindig = binding.llCounterHeader
        nextPreviuosButtonsBinding = binding.llRunJobsButtons
        val rootview = binding.root
        initUI()
        initCounterHeaderAndBottomButtoms()
        registerClicks()
        return rootview
    }


    fun initUI() {

    }


    fun initCounterHeaderAndBottomButtoms() {
        //counter header
        counterHeaderBindig.ivArrowLeft.setOnClickListener {
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.fl_container, FrgRunJobStep1())
                .commit()
        }
        counterHeaderBindig.ivArrowRight.setOnClickListener {
        }
        counterHeaderBindig.tvCounter.text = "2"
        counterHeaderBindig.tvHeader.text = "Select Test Suites"

        //bottom buttons
        nextPreviuosButtonsBinding.cvPrevious.setOnClickListener {
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.fl_container, FrgRunJobStep1())
                .commit()
        }
        nextPreviuosButtonsBinding.cvNext.setOnClickListener {
            doValidate()
        }

    }

    fun registerClicks() {

        binding.llProjectType.setOnClickListener {
            if (this::bottomDlgProjectType.isInitialized) {
                if (bottomDlgProjectType != null) {
                    bottomDlgProjectType.show(parentFragmentManager,
                        TAG)
                }
            }
        }
        binding.llRegion.setOnClickListener {
            if (selectedProjectType != null) {
                binding.tvErrorProjectType.visibility = View.GONE
                Coroutines.main {
                    getAllRegionsByProject(selectedProjectType!!.projectTypeId)
                }
            } else {
                binding.tvErrorProjectType.visibility = View.VISIBLE
            }
//            bottomDlgRegion.show(parentFragmentManager, TAG)
        }
        binding.cvBrand.setOnClickListener {
            if (selectedRegion != null) {
                binding.tvErrorRegion.visibility = View.GONE
                Coroutines.main {
                    getAllBrands(selectedRegion!!.regionId)
                }
            } else {
                binding.tvErrorRegion.visibility = View.VISIBLE
            }
//            bottomDlgBrand.show(parentFragmentManager, TAG)
        }
        binding.llProoductName.setOnClickListener {
            if (selectedProjectType != null && selectedBrand != null && selectedRegion != null) {
                binding.tvErrorProjectType.visibility = View.GONE
                binding.tvErrorRegion.visibility = View.GONE
                binding.tvErrorBrand.visibility = View.GONE
                Coroutines.main {
                    getAllProductNames(
                        selectedBrand!!.brandId,
                        selectedProjectType!!.projectTypeId,
                        selectedRegion!!.regionId
                    )
                }
            } else {
                if (selectedProjectType == null) {
                    binding.tvErrorProjectType.visibility = View.VISIBLE
                }
                if (selectedRegion == null) {
                    binding.tvErrorRegion.visibility = View.VISIBLE
                }
                if (selectedBrand == null) {
                    binding.tvErrorBrand.visibility = View.VISIBLE
                }
            }
//            bottomDlgRegion.show(parentFragmentManager, TAG)
        }

        binding.llPlatform.setOnClickListener {
            if (selectedProjectType != null) {
                binding.tvErrorProjectType.visibility = View.GONE
                Coroutines.main {
                    getAllPlatform(selectedProjectType!!.projectTypeId)
                }
            } else {
                binding.tvErrorProjectType.visibility = View.VISIBLE
            }
        }

        binding.llEnv.setOnClickListener {
            var list: ArrayList<String> = arrayListOf()
            list.add("ENV")
            list.add("STG")
            list.add("DEV")
            list.add("Prod")
            list.add("QA")
            envObservable.value = list
//            bottomDlgEnv.show(parentFragmentManager, TAG)
        }

      

      
    }

    override fun onResume() {
        super.onResume()
        Coroutines.main {
            getAllProjects()
        }
        Observe()
    }
    fun Observe() {

        projectTypesObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgProjectType = DlgDropDownProjectType(it, this)
                bottomDlgProjectType.mListner = this
            }
        })

        regionObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgRegion = DlgDropDownRegion()
                bottomDlgRegion.items = it
                bottomDlgRegion.mListner = this

                if (bottomDlgRegion != null && !bottomDlgRegion.isVisible) {
                    bottomDlgRegion.show(parentFragmentManager, TAG)
                }
            }
        })

        brandObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgBrand = DlgDropDownBrand()
                bottomDlgBrand.items = it
                bottomDlgBrand.mListner = this
                if (bottomDlgBrand != null && !bottomDlgBrand.isVisible) {
                    bottomDlgBrand.show(parentFragmentManager, TAG)
                }
            }
        })
        productNameObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgProductName = DlgDropDownProductName()
                bottomDlgProductName.items = it
                bottomDlgProductName.mListner = this
                if (bottomDlgProductName != null && !bottomDlgProductName.isVisible) {
                    bottomDlgProductName.show(parentFragmentManager,
                        TAG)
                }
            }
        })

        platformObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgPlatform = DlgDropDownPlatform()
                bottomDlgPlatform.items = it
                bottomDlgPlatform.mListner = this
                if (bottomDlgPlatform != null && !bottomDlgPlatform.isVisible) {
                    bottomDlgPlatform.show(parentFragmentManager, TAG)
                }
            }
        })

        envObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgEnv = DlgDropDownENV()
                bottomDlgEnv.items = it
                bottomDlgEnv.mListner = this
                if (bottomDlgEnv != null && !bottomDlgEnv.isVisible) {
                    bottomDlgEnv.show(parentFragmentManager, TAG)
                }
            }
        })




    }

    fun doValidate() {
        val project_type = binding.etProjectType.text.toString()
        val region = binding.etRegion.text.toString()
        val brand = binding.etBrand.text.toString()
        val product_name = binding.etProductName.text.toString()
        val platform = binding.etPlatform.text.toString()
        val env = binding.etEnv.text.toString()

        if (project_type.isEmpty() || project_type.isNullOrBlank()) {
            binding.tvErrorProjectType.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorProjectType.visibility = View.GONE
        }

        if (region.isEmpty() || region.isNullOrBlank()) {
            binding.tvErrorRegion.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorRegion.visibility = View.GONE
        }

        if (brand.isEmpty() || brand.isNullOrBlank()) {
            binding.tvErrorBrand.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorBrand.visibility = View.GONE
        }

        if (product_name.isEmpty() || product_name.isNullOrBlank()) {
            binding.tvErrorProductName.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorProductName.visibility = View.GONE
        }

        if (platform.isEmpty() || platform.isNullOrBlank()) {
            binding.tvErrorPlatform.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorPlatform.visibility = View.GONE
        }

        if (env.isEmpty() || env.isNullOrBlank()) {
            binding.tvErrorEnv.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorEnv.visibility = View.GONE
        }

        requireActivity().supportFragmentManager.beginTransaction()
            .replace(R.id.fl_container, FrgRunJobStep3())
            .commit()
    }

    //bottom dialoe interface ==============================================================================================================

    var selectedProjectType: ProjectType? = null
    var selectedRegion: Region? = null
    var selectedBrand: Brand? = null
    var selectedProductName: ProductName? = null
    var selectedTestSuite: TestSuit? = null
    var selectedPlatform: Platform? = null
    var selectedEnv: String? = null
    var selectedUser: User? = null

    override fun onProjectTypeSelected(type: Int) {
        selectedProjectType = projectTypesObservable.value!!.get(type)
        binding.etProjectType.setText(selectedProjectType!!.projectTypeName)
        bottomDlgProjectType.dismiss()
    }

    override fun onRegionSelected(type: Int) {
        selectedRegion = regionObservable.value!!.get(type)
        binding.etRegion.setText(selectedRegion!!.regionName)
        bottomDlgRegion.dismiss()
    }

    override fun onBrandSelected(type: Int) {
        selectedBrand = brandObservable.value!!.get(type)
        binding.etBrand.setText(selectedBrand!!.brandName)
        bottomDlgBrand.dismiss()
    }

    override fun onProductNameSelected(type: Int) {
        selectedProductName = productNameObservable.value!!.get(type)
        binding.etProductName.setText(selectedProductName!!.projectName)
        bottomDlgProductName.dismiss()
    }


    override fun onPlatformSelected(type: Int) {
        selectedPlatform = platformObservable.value!!.get(type)
        binding.etPlatform.setText(selectedPlatform!!.platformName)
        bottomDlgPlatform.dismiss()
    }

    override fun onENVSelected(type: Int) {
        selectedEnv = envObservable.value!!.get(type)
        binding.etEnv.setText(selectedEnv!!)
        bottomDlgEnv.dismiss()
    }


    suspend fun getAllProjects() {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllProjectType()
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            projectTypesObservable.value = res.body() as ArrayList<ProjectType>
            Log.d(TAG, "getAllProjects: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllProjects: Error : ")
        }
    }


    suspend fun getAllRegionsByProject(projectTypeId: Int) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllRegionsByProject(projectTypeId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            regionObservable.value = res.body() as ArrayList<Region>
            Log.d(TAG, "getAllRegionsByProject: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllRegionsByProject: Error : ${res.body()} ")
        }
    }

    suspend fun getAllBrands(regionId: Int) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllBrands(regionId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            brandObservable.value = res.body() as ArrayList<Brand>
            Log.d(TAG, "getAllBrands: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllBrands: Error : ${res.body()} ")
        }
    }


    suspend fun getAllProductNames(
        brandId: Int,
        projectTypeId: Int,
        regionId: Int,
    ) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllProductNames(brandId, projectTypeId, regionId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            productNameObservable.value = res.body() as ArrayList<ProductName>
            Log.d(TAG, "getAllProductNames: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllProductNames: Error : ${res.body()} ")
        }
    }


    suspend fun getTestSuiteNameByProjectName(projectName: String) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getTestSuiteNameByProjectName(projectName)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            testSuitObservable.value = res.body() as ArrayList<TestSuit>
            Log.d(TAG, "getTestSuiteNameByProjectName: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getTestSuiteNameByProjectName: Error : ${res.body()} ")
        }
    }

    suspend fun getAllPlatform(projectTypeId: Int) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllPlatform(projectTypeId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            platformObservable.value = res.body() as ArrayList<Platform>
            Log.d(TAG, "getAllPlatform: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllPlatform: Error : ${res.body()} ")
        }
    }

    suspend fun getAllUsers() {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllUsers()
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            userObservable.value = res.body() as ArrayList<User>
            Log.d(TAG, "getAllUsers: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllUsers: Error : ${res.body()} ")
        }
    }

}