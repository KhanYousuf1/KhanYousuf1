package com.whirlpool.prodigio_app.communication.response

data class ExtentReportList(
    val dbTimeZone: String,
    val executionDateTime: String,
    val executionStatus: Int,
    val failCount: Int,
    val hsSessionId: String,
    val passCount: Int,
    val paths: List<Path>,
    val testSuiteId: Int
)


data class Path(
    val name: String,
    val reportUrl: String
)