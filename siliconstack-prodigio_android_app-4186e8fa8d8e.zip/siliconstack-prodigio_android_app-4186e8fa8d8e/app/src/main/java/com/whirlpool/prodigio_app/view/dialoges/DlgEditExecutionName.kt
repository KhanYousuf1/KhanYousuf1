package com.whirlpool.prodigio_app.view.dialoges

import android.content.DialogInterface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.deishelon.roundedbottomsheet.RoundedBottomSheetDialogFragment
import com.whirlpool.prodigio_app.AppApplication
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.OfRecords
import com.whirlpool.prodigio_app.databinding.DlgEditExecutionNameBinding
import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.viewmodel.EditExecutionNameViewModel
import com.whirlpool.prodigio_app.viewmodel.EditExecutionNameViewModelFactory
import org.kodein.di.Kodein
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance

class DlgEditExecutionName() : RoundedBottomSheetDialogFragment(), View.OnClickListener,
    KodeinAware {


    lateinit var binding: DlgEditExecutionNameBinding
    lateinit var mListner: BottomSheetEditExecutionNameListener

    override val kodein: Kodein by kodein(AppApplication.appContext)

    lateinit var viewModel: EditExecutionNameViewModel

    lateinit var ofRecords: OfRecords

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val factory: EditExecutionNameViewModelFactory by instance() // dependency injection
        viewModel = ViewModelProvider(this, factory).get(EditExecutionNameViewModel::class.java)

        binding =
            DataBindingUtil.inflate(inflater, R.layout.dlg_edit_execution_name, container, false)
        val rootView = binding.root

        reisterClicks()
        return rootView
    }

    override fun onResume() {
        super.onResume()
        binding.etExeName.text.clear()
    }

    private fun reisterClicks() {
        binding.cvCancel.setOnClickListener(this)
        binding.cvUpdate.setOnClickListener(this)
    }

    fun setData(ofRecords: OfRecords) {
        this.ofRecords = ofRecords
        Handler(Looper.getMainLooper()).postDelayed({// display after 2 seconds otherwise binding exception will occur
            binding.tvCurrentExecutionName.text = ofRecords.jobName
        }, 500)
    }

    override fun onClick(p0: View?) {
        when (p0?.id) {
            R.id.cv_cancel -> {
                dismiss()
            }
            R.id.cv_update -> {
                val exeName = binding.etExeName.text.toString()
                if (!viewModel.validateExecutionName(exeName)) {
                    binding.cvExeName.setStrokeColor(
                        ContextCompat.getColor(
                            requireContext(),
                            R.color.red2
                        )
                    )
                    binding.tvError.visibility = View.VISIBLE
                    return
                } else {
                    binding.cvExeName.setStrokeColor(
                        ContextCompat.getColor(
                            requireContext(),
                            R.color.grey5
                        )
                    )
                    binding.tvError.visibility = View.GONE
                }

                mListner.onExecuteUpdateClicked(exeName)

            }
        }
    }


    interface BottomSheetEditExecutionNameListener {
        fun onExecuteUpdateClicked(new_execute_name: String)
    }

}