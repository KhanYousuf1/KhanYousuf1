package com.whirlpool.prodigio_app.view.adapter

import android.annotation.SuppressLint
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.Constant
import com.whirlpool.prodigio_app.communication.response.OfRecords
import com.whirlpool.prodigio_app.databinding.ItemExecutionHistoryBinding
import com.whirlpool.prodigio_app.databinding.ItemProgressBinding
import com.whirlpool.prodigio_app.view.ScrExecutionHistory
import com.whirlpool.prodigio_app.view.ScrExecutionHistorySub

class ExecutionHistorySearchAdapter(val context: ScrExecutionHistory) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val TAG = ExecutionHistorySubAdapter::class.java.name

    var items: ArrayList<OfRecords> = ArrayList<OfRecords>()
    var tempList: ArrayList<OfRecords> = ArrayList<OfRecords>()
    //listner
    lateinit var optionListner: ExecutionHistoryAdapter.onSwipeOptionClikedLister

    //item type
    private val ITEM: Int = 0
    private val LOADING = 1

    private var isLoadingAdded = false
    private val retryPageLoad = false

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        var viewHolder: RecyclerView.ViewHolder? = null
        optionListner = context
        when (viewType) {
            ITEM -> {
                val binding = DataBindingUtil.inflate<ItemExecutionHistoryBinding>(
                    LayoutInflater.from(parent.context), R.layout.item_execution_history,
                    parent, false
                )
                viewHolder = ItemHolder(binding)
            }
            LOADING -> {
                val binding = DataBindingUtil.inflate<ItemProgressBinding>(
                    LayoutInflater.from(parent.context), R.layout.item_progress,
                    parent, false
                )
                viewHolder = LoadingViewHolder(binding)
            }
        }
        return viewHolder!!
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val execution = items[position]
        when (getItemViewType(position)) {
            ITEM -> {
                val viewHolder = holder as ItemHolder
                viewHolder.binding.tvTextExeId.text =
                    execution.exeHistoryId.toString()
                viewHolder.binding.tvTextExeName.text = execution.jobName
                when (execution.jobStatus) {
                    Constant.JOB_STATUS_IDEAL -> {
                        viewHolder.binding.tvJobStatus.text = Constant.JOB_IDEAL
                    }
                    Constant.JOB_STATUS_INPROGRESS -> {
                        viewHolder.binding.tvJobStatus.text = Constant.JOB_INPROGRESS
                    }
                    Constant.JOB_STATUS_PASS -> {
                        viewHolder.binding.tvJobStatus.text = Constant.JOB_PASS
                    }
                    Constant.JOB_STATUS_FAIL -> {
                        viewHolder.binding.tvJobStatus.text = Constant.JOB_FAIL
                    }
                    Constant.JOB_STATUS_TERMINATED -> {
                        viewHolder.binding.tvJobStatus.text = Constant.JOB_TERMINATED
                    }
                }

                viewHolder.binding.cvMain.tag = execution
                viewHolder.binding.cvMain.setOnClickListener {
                    val execution1 = it.tag as OfRecords
                    Log.d(
                        TAG,
                        "onBindViewHolder: exeHeaderId : ${execution1.exeHeaderId} exeHistoryId : ${execution1.exeHistoryId}"
                    )
                    val intent = Intent(context, ScrExecutionHistorySub::class.java)
                    intent.putExtra("exeHeaderId", execution1.exeHeaderId.toString())
                    intent.putExtra("exeHistoryId", execution1.exeHistoryId.toString())
                    intent.putExtra("exeName", execution1.jobName)
                    context.startActivity(intent)
                    viewHolder.binding.es.resetStatus()
                }


                viewHolder.binding.rlReExecute.tag = execution
                viewHolder.binding.rlReExecute.setOnClickListener {
                    val execution1 = it.tag as OfRecords
                    optionListner.onOptionClicked(1, execution1, position)
                    viewHolder.binding.es.resetStatus()
                }

                viewHolder.binding.rlView.tag = execution
                viewHolder.binding.rlView.setOnClickListener {
                    val execution2 = it.tag as OfRecords
                    optionListner.onOptionClicked(2, execution2, position)
                    viewHolder.binding.es.resetStatus()
                }

                viewHolder.binding.rlEdit.tag = execution
                viewHolder.binding.rlEdit.setOnClickListener {
                    val execution3 = it.tag as OfRecords
                    optionListner.onOptionClicked(3, execution3, position)
                    viewHolder.binding.es.resetStatus()
                }

                viewHolder.binding.rlDelete.tag = execution
                viewHolder.binding.rlDelete.setOnClickListener {
                    val execution4 = it.tag as OfRecords
                    optionListner.onOptionClicked(4, execution4, position)
                    viewHolder.binding.es.resetStatus()
                }

            }
            LOADING -> {
                val loadingViewHolder = holder as LoadingViewHolder
                /* if (retryPageLoad) {
                     loadingViewHolder.mErrorLayout.setVisibility(View.VISIBLE)
                     loadingViewHolder.mProgressBar.setVisibility(View.GONE)
                     loadingViewHolder.mErrorTxt.setText(
                        // if (errorMsg != null) errorMsg else context.getString(R.string.error_msg_unknown)
                     ""
                     )
                 } else {*/
                loadingViewHolder.binding.loadmoreErrorlayout.setVisibility(View.GONE)
                loadingViewHolder.binding.loadmoreProgress.setVisibility(View.VISIBLE)
                //}
            }
        }
    }

        override fun getItemViewType(position: Int): Int {
            val i = if (position == items.size - 1 && isLoadingAdded) LOADING else ITEM
            return i
        }

    override fun getItemCount(): Int {
        return items.count()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun setList(item: ArrayList<OfRecords>) {
        items = item
        notifyDataSetChanged()
    }

    @JvmName("setTempList1")
    @SuppressLint("NotifyDataSetChanged")
    fun setTempList(item: ArrayList<OfRecords>) {
        tempList = item
        notifyDataSetChanged()
    }

    fun addLoadingFooter() {
        isLoadingAdded = true
        add(
            OfRecords(
                false,
                "",
                "",
                "",
                "",
                0,
                0,
                "",
                0,
                0,
                "",
                "",
                "",
                0,
                "",
                "",
                "",
                "",
                0,
                "",
                "",
                0,
                "",
                "",
                0
            )
        )
    }

    fun add(r: OfRecords?) {
        if (r != null) {
            items.add(r)
        }
        notifyItemInserted(items.size - 1)
    }


    @SuppressLint("NotifyDataSetChanged")
    fun addAll(item: ArrayList<OfRecords>) {
        for (result in item) {
            add(result)
        }
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun remove(position: Int) {
        items.removeAt(position)
        notifyDataSetChanged()
    }

    inner class ItemHolder(val binding: ItemExecutionHistoryBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }

    inner class LoadingViewHolder(val binding: ItemProgressBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }

    fun removeLoadingFooter() {
        isLoadingAdded = false
        val position: Int = items.size - 1
        val result = getItem(position)
        if (result != null) {
            items.removeAt(position)
            notifyItemRemoved(position)
        }
    }

    fun getItem(position: Int): OfRecords? {
        return items.get(position)
    }



}