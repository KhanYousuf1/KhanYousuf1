package com.whirlpool.prodigio_app.view.adapter

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.ExecutionInProgress
import com.whirlpool.prodigio_app.databinding.ItemExecutionInProgressBinding
import com.whirlpool.prodigio_app.utils.CustomIntent
import com.whirlpool.prodigio_app.view.ScrExecutionInProgress
import com.whirlpool.prodigio_app.view.ScrExecutionInProgressSub
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.card.MaterialCardView
import com.whirlpool.prodigio_app.communication.response.Document
import com.whirlpool.prodigio_app.communication.response.ScheduleDetails
import com.whirlpool.prodigio_app.databinding.ItemInprogressScheduleDetailsBinding


class ExecutionInProgressScheduleDetailsAdapter(var context: ScrExecutionInProgressSub) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var items: ArrayList<ScheduleDetails> = ArrayList<ScheduleDetails>()


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = DataBindingUtil.inflate<ItemInprogressScheduleDetailsBinding>(
            LayoutInflater.from(parent.context), R.layout.item_inprogress_schedule_details,
            parent, false
        )
        return ItemHolder(binding)
    }

    fun setList(items: ArrayList<ScheduleDetails>) {
        this.items = items
        notifyDataSetChanged()
    }

    fun filteredList(filteredList: ArrayList<ScheduleDetails>) {
        items = filteredList
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val execution = items[position]
        val viewHolder = holder as ExecutionInProgressScheduleDetailsAdapter.ItemHolder
        viewHolder.binding.tvTestSuiteName.text = execution.testSuiteName


        val devicesAdapter = ExecutionInProgressScheduleDetailsDevicesAdapter(context)
        viewHolder.binding.rvDevice.setLayoutManager(
            LinearLayoutManager(
                context,
                LinearLayoutManager.VERTICAL,
                false
            )
        )
        viewHolder.binding.rvDevice.adapter = devicesAdapter
        devicesAdapter.setList(execution.devices)
        devicesAdapter.notifyDataSetChanged()


    }


    override fun getItemCount(): Int {
        return items.count()
    }

    inner class ItemHolder(val binding: ItemInprogressScheduleDetailsBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }

}