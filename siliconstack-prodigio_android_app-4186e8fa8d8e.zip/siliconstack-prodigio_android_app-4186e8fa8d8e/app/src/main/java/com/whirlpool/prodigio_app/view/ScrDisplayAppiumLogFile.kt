package com.whirlpool.prodigio_app.view

import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.databinding.ActivityScrDisplayAppiumLogFileBinding
import android.text.Spannable

import android.text.style.ForegroundColorSpan

import android.text.SpannableString
import android.view.View


class ScrDisplayAppiumLogFile : AppCompatActivity() {

    companion object {
        var data = MutableLiveData<String>()
        var data_title = MutableLiveData<String>()

    }

    lateinit var binding: ActivityScrDisplayAppiumLogFileBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = resources.getColor(R.color.white)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            window.statusBarColor = Color.WHITE
        }
        binding =
            DataBindingUtil.setContentView(this, R.layout.activity_scr_display_appium_log_file)
        loadData()
        registerClicks()
    }

    private fun registerClicks() {
        binding.llBack.setOnClickListener { finish() }

    }


    private fun loadData() {
        data.observe(this, Observer { binding.tvData.text = it.toString() })
        data_title.observe(this, Observer { binding.tvToolBarOther.text = it.toString() })

    }

}