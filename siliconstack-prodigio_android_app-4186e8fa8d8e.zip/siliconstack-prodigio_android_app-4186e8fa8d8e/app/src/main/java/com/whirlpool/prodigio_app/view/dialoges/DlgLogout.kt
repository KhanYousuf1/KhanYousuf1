package com.whirlpool.prodigio_app.view.dialoges

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.deishelon.roundedbottomsheet.RoundedBottomSheetDialogFragment
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.databinding.DlgLogoutBinding
import java.lang.ClassCastException

class DlgLogout() : RoundedBottomSheetDialogFragment(), View.OnClickListener {

    lateinit var binding: DlgLogoutBinding
    lateinit var mListner: BottomSheetLogoutListener

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.dlg_logout, container, false)
        val rootView = binding.root
        reisterClicks()
        return rootView
    }

    private fun reisterClicks() {
        binding.cvNo.setOnClickListener(this)
        binding.cvYes.setOnClickListener(this)
        binding.ivClose.setOnClickListener(this)
    }

    override fun onClick(p0: View?) {
        when (p0?.id) {
            R.id.cv_no -> {
                mListner.onButtonClicked(0)
            }
            R.id.cv_yes -> {
                mListner.onButtonClicked(2)
            }
            R.id.iv_close -> {
                dismiss()
            }
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        try {
            mListner = context as BottomSheetLogoutListener

        } catch (e: ClassCastException) {
            throw ClassCastException(
                context.toString()
                        + " must implement BottomSheetListener"
            )
        }
    }

    interface BottomSheetLogoutListener {
        fun onButtonClicked(type: Int)
    }


}