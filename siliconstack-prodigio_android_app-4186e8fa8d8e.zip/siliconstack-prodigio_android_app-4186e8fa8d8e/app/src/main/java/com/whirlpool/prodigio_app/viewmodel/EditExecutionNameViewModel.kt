package com.whirlpool.prodigio_app.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import com.whirlpool.prodigio_app.communication.response.ExecutionDashboardCount
import com.whirlpool.prodigio_app.communication.response.ExecutionHistory
import com.whirlpool.prodigio_app.communication.response.ExecutionHistorySubItem
import com.whirlpool.prodigio_app.repository.Repository
import com.whirlpool.prodigio_app.utils.CustomToast
import retrofit2.Response

class EditExecutionNameViewModel(
    val repository: Repository,
) : ViewModel() {

    private val TAG = EditExecutionNameViewModel::class.java.name


    fun validateExecutionName(exeName: String): Boolean {
        if (exeName.isNullOrBlank() || exeName.isEmpty()) {
            return false
        }
        return true
    }


    fun call_editExeName() {
        Log.d(TAG, "call_editExeName: called")
    }
}