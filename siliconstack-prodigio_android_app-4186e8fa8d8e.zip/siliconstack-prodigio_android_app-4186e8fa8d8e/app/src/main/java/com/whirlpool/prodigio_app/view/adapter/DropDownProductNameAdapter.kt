package com.whirlpool.prodigio_app.view.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.ProductName
import com.whirlpool.prodigio_app.communication.response.ProjectType
import com.whirlpool.prodigio_app.databinding.ItemDropDownOptionsBinding
import com.whirlpool.prodigio_app.view.dialoges.DlgDropDownProductName
import com.whirlpool.prodigio_app.view.dialoges.DlgDropDownProjectType

class DropDownProductNameAdapter(
    var items: ArrayList<ProductName>,
    var mListner: DlgDropDownProductName.BottomSheetDlgProductNameListner
) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TAG = "DropDownProductNameAdapter"
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = DataBindingUtil.inflate<ItemDropDownOptionsBinding>(
            LayoutInflater.from(parent.context), R.layout.item_drop_down_options,
            parent, false
        )
        return ItemHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val viewHolder = holder as ItemHolder
        var item = items.get(position)
        viewHolder.binding.txtProjectType.setText("${item.projectName}")
        viewHolder.binding.llMain.setOnClickListener() {
            Log.d(TAG, "onBindViewHolder: Clicked")
            mListner.onProductNameSelected(position)
        }

    }


    override fun getItemCount(): Int {
        return items.count()
    }

    inner class ItemHolder(val binding: ItemDropDownOptionsBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }
}

