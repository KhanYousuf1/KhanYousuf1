package com.whirlpool.prodigio_app.view.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.view.ScrExecutionInProgressSub
import androidx.recyclerview.widget.LinearLayoutManager
import com.whirlpool.prodigio_app.communication.response.Device
import com.whirlpool.prodigio_app.databinding.ItemInprogressScheduleDetailsDevicesBinding


class ExecutionInProgressScheduleDetailsDevicesAdapter(var context: ScrExecutionInProgressSub) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var items: ArrayList<Device> = ArrayList<Device>()


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = DataBindingUtil.inflate<ItemInprogressScheduleDetailsDevicesBinding>(
            LayoutInflater.from(parent.context), R.layout.item_inprogress_schedule_details_devices,
            parent, false
        )
        return ItemHolder(binding)
    }

    fun setList(items: ArrayList<Device>) {
        this.items = items
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val execution = items[position]
        val viewHolder = holder as ExecutionInProgressScheduleDetailsDevicesAdapter.ItemHolder
        viewHolder.binding.tvTemplateName.text = execution.templateName


        val casesAdapter = ExecutionInProgressScheduleDetailsDevicesCasesAdapter(context)
        viewHolder.binding.rvCases.setLayoutManager(
            LinearLayoutManager(
                context,
                LinearLayoutManager.VERTICAL,
                false
            )
        )
        viewHolder.binding.rvCases.adapter = casesAdapter
        casesAdapter.setList(execution.cases)
        casesAdapter.notifyDataSetChanged()
    }


    override fun getItemCount(): Int {
        return items.count()
    }

    inner class ItemHolder(val binding: ItemInprogressScheduleDetailsDevicesBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }

}