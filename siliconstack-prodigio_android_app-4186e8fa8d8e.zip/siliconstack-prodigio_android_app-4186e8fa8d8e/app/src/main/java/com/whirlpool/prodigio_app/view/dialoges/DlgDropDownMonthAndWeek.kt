package com.whirlpool.prodigio_app.view.dialoges

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.deishelon.roundedbottomsheet.RoundedBottomSheetDialogFragment
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.ProjectType
import com.whirlpool.prodigio_app.databinding.DlgDeleteAllRecordBinding
import com.whirlpool.prodigio_app.databinding.DlgDropDownProjectTypeBinding
import com.whirlpool.prodigio_app.databinding.DlgLogoutBinding
import com.whirlpool.prodigio_app.view.adapter.DocumentAdapter
import com.whirlpool.prodigio_app.view.adapter.DropDownMonthAndWeekAdapter
import com.whirlpool.prodigio_app.view.adapter.DropDownProjectTypeAdapter
import com.whirlpool.prodigio_app.view.adapter.DropDownRecurrenceAdapter
import java.lang.ClassCastException

class DlgDropDownMonthAndWeek(var mListner: BottomSheetDlgMonthAndWeekListner) :
    RoundedBottomSheetDialogFragment() {

    lateinit var binding: DlgDropDownProjectTypeBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding =
            DataBindingUtil.inflate(inflater, R.layout.dlg_drop_down_project_type, container, false)
        val rootView = binding.root
        init()
        reisterClicks()
        return rootView
    }

    fun init() {
        binding.tvHeader.text = "Month & Week"
        binding.rvOptions.apply {
            layoutManager =
                LinearLayoutManager(requireContext(), RecyclerView.VERTICAL, false)

            /* var arr: ArrayList<String> = ArrayList()
             for (i in 0..30) {
                 arr.add("$i")
             }*/
            var list: ArrayList<String> = ArrayList<String>()
            list.add("Month")
            list.add("Week")
            adapter = DropDownMonthAndWeekAdapter(list, mListner)
            binding.rvOptions.adapter = adapter
            binding.rvOptions.adapter?.notifyDataSetChanged()
        }
    }

    private fun reisterClicks() {
        binding.ivSearch.setOnClickListener {
            dismiss()
        }

    }


    interface BottomSheetDlgMonthAndWeekListner {
        fun onMonthAndWeekeSelected(value: String)
    }


}