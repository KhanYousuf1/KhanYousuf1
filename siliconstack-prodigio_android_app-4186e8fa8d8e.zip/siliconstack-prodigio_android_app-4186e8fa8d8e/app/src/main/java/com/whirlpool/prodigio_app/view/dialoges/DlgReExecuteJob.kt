package com.whirlpool.prodigio_app.view.dialoges

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.deishelon.roundedbottomsheet.RoundedBottomSheetDialogFragment
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.databinding.DlgLogoutBinding
import com.whirlpool.prodigio_app.databinding.DlgReExecuteJobBinding
import java.lang.ClassCastException

class DlgReExecuteJob() : RoundedBottomSheetDialogFragment(), View.OnClickListener {

    lateinit var binding: DlgReExecuteJobBinding
    lateinit var mListner: BottomSheetReExecuteListener

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.dlg_re_execute_job, container, false)
        val rootView = binding.root
        reisterClicks()
        return rootView
    }

    private fun reisterClicks() {
        binding.cvCancel.setOnClickListener(this)
        binding.cvExecute.setOnClickListener(this)
        binding.ivClose.setOnClickListener(this)
    }

    override fun onClick(p0: View?) {
        when (p0?.id) {
            R.id.cv_cancel -> {
               dismiss()
            }
            R.id.cv_execute -> {
                mListner.onReExecuteButtonClicked(1)
            }
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        try {
            mListner = context as BottomSheetReExecuteListener

        } catch (e: ClassCastException) {
            throw ClassCastException(
                context.toString()
                        + " must implement BottomSheetListener"
            )
        }
    }


    interface BottomSheetReExecuteListener {
        fun onReExecuteButtonClicked(type: Int)
    }


}