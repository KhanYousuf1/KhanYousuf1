package com.whirlpool.prodigio_app.view

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import androidx.databinding.DataBindingUtil.setContentView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.databinding.ActivityHomeDashboardBinding
import com.whirlpool.prodigio_app.view.adapter.FragmentPageAdapter
import com.whirlpool.prodigio_app.view.fragments.*
import androidx.viewpager2.widget.ViewPager2
import androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback
import com.whirlpool.prodigio_app.databinding.LayoutToolbarBinding


class HomeDashboardActivity :  FragmentActivity() {

    var binding: ActivityHomeDashboardBinding? = null
    lateinit var textViewTitle : TextView
    lateinit var imageViewBack : ImageView
    var position : Int = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = resources.getColor(R.color.white)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            window.statusBarColor = Color.WHITE
        }
        binding = setContentView(this, R.layout.activity_home_dashboard)
        textViewTitle = findViewById(R.id.tv_tool_bar_title)
        imageViewBack = findViewById(R.id.imageViewBack)
        var list : ArrayList<Fragment> = arrayListOf()
        position = intent.getIntExtra("POSITION",0)
        list.add(FrgTestSuiteExecutionTrend())
        list.add(FrgTestSuiteExecutionStatus())
        list.add(FrgTestSuitePass())
        list.add(FrgTestSuiteExecutionTimeTrend())
        list.add(FrgMonthlyExecutionStatus())
        list.add(FrgProjectExecutionTimeStatus())
        when (position) {
            0 -> {
                textViewTitle.setText("Test Suite Execution Trend")
                /*list.add(FrgTestSuiteExecutionTrend())
                list.add(FrgTestSuiteExecutionStatus())
                list.add(FrgTestSuitePass())
                list.add(FrgTestSuiteExecutionTimeTrend())
                list.add(FrgMonthlyExecutionStatus())
                list.add(FrgProjectExecutionTimeStatus())*/
            }
            1 -> {
                textViewTitle.setText("Test Suite Execution Status")
                /*list.add(FrgTestSuiteExecutionStatus())
                list.add(FrgTestSuiteExecutionTrend())
                list.add(FrgTestSuitePass())
                list.add(FrgTestSuiteExecutionTimeTrend())
                list.add(FrgMonthlyExecutionStatus())
                list.add(FrgProjectExecutionTimeStatus())*/
            }
            2 -> {
                textViewTitle.setText("Test Suite Pass %")
                /*list.add(FrgTestSuitePass())
                list.add(FrgTestSuiteExecutionTrend())
                list.add(FrgTestSuiteExecutionStatus())
                list.add(FrgTestSuiteExecutionTimeTrend())
                list.add(FrgMonthlyExecutionStatus())
                list.add(FrgProjectExecutionTimeStatus())*/
            }
            3 -> {
                textViewTitle.setText("Test Suite Execution Time Trend")
                /*list.add(FrgTestSuiteExecutionTimeTrend())
                list.add(FrgTestSuiteExecutionTrend())
                list.add(FrgTestSuiteExecutionStatus())
                list.add(FrgTestSuitePass())
                list.add(FrgMonthlyExecutionStatus())
                list.add(FrgProjectExecutionTimeStatus())*/
            }
            4 -> {
                textViewTitle.setText("Monthly Execution Status")
                /*list.add(FrgMonthlyExecutionStatus())
                list.add(FrgTestSuiteExecutionTrend())
                list.add(FrgTestSuiteExecutionStatus())
                list.add(FrgTestSuitePass())
                list.add(FrgTestSuiteExecutionTimeTrend())
                list.add(FrgProjectExecutionTimeStatus())*/
            }
            else -> {
                textViewTitle.setText("Project Execution Time Status")
                /*list.add(FrgProjectExecutionTimeStatus())
                list.add(FrgTestSuiteExecutionTrend())
                list.add(FrgTestSuiteExecutionStatus())
                list.add(FrgTestSuitePass())
                list.add(FrgTestSuiteExecutionTimeTrend())
                list.add(FrgMonthlyExecutionStatus())*/
            }
        }

        val pagerAdapter = FragmentPageAdapter(this,list)
        binding!!.pager.adapter = pagerAdapter
        binding!!.pager.setCurrentItem(position)
        Log.d(Companion.TAG, "onCreate: POSITION - ${position}")
        binding!!.pager.registerOnPageChangeCallback(object : OnPageChangeCallback() {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels)
            }

            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                when (position) {
                    0 -> {
                        textViewTitle.setText("Test Suite Execution Trend")
                    }
                    1 -> {
                        textViewTitle.setText("Test Suite Execution Status")
                    }
                    2 -> {
                        textViewTitle.setText("Test Suite Pass %")
                    }
                    3 -> {
                        textViewTitle.setText("Test Suite Execution Time Trend")
                    }
                    4 -> {
                        textViewTitle.setText("Monthly Execution Status")
                    }
                    else -> {
                        textViewTitle.setText("Project Execution Time Status")
                    }
                }
                Log.d("Selected_Page", position.toString())
            }

            override fun onPageScrollStateChanged(state: Int) {
                super.onPageScrollStateChanged(state)
            }
        })

        imageViewBack.setOnClickListener(){
            finish()
        }
    }

    companion object {
        private const val TAG = "HomeDashboardActivity"
    }
}
