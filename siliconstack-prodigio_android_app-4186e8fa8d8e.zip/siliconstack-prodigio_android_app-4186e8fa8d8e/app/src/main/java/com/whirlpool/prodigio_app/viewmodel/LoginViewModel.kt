package com.whirlpool.prodigio_app.viewmodel

import androidx.lifecycle.ViewModel
import com.whirlpool.prodigio_app.communication.response.Login
import com.whirlpool.prodigio_app.repository.Repository
import com.whirlpool.prodigio_app.utils.CustomToast.Companion.showToast
import retrofit2.Response

class LoginViewModel(
    val repository: Repository,
) : ViewModel() {

    fun validate(username: String, password: String): Boolean {
        if (username.isNullOrBlank() || username.isEmpty()) {
            showToast("Enter Username")
            return false
        }
        if (password.isNullOrBlank() || password.isEmpty()) {
            showToast("Enter Password")
            return false
        }
        return true
    }

    suspend fun login(params: HashMap<String?, String?>): Response<Login> {
        return repository.login(params)
    }
}