package com.whirlpool.prodigio_app.communication.response

data class Document(
    val createdOn: String,
    val deleted: Boolean,
    val documentId: Int,
    val documentLink: String,
    val documentName: String,
    val modifiedOn: String,
    val userId: Int
)