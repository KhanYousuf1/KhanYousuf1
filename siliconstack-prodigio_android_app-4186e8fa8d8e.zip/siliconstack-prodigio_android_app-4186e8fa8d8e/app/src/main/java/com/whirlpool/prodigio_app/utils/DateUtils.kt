package com.whirlpool.prodigio_app.utils

import android.annotation.SuppressLint
import android.util.Log
import java.text.DateFormat
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class DateUtils {

    companion object {

        var date: Date? = null
        var simpleDateFormat: SimpleDateFormat? = null

        val date2 = "dd-M-yyyy"

        // private static String date1="yyyy/M/d";
        var date1 = "d/M/yyyy"
        var onlineDate = "yyyy-MM-dd HH:m"

        fun getMillis(eventdate: String?): Long {
            try {
                simpleDateFormat = SimpleDateFormat(date1)
                date = simpleDateFormat!!.parse(eventdate)
            } catch (e: ParseException) {
                e.printStackTrace()
            }
            return date!!.time
        }

        fun getMillisOnlineTime(eventdate: String?): Long {
            try {
                simpleDateFormat = SimpleDateFormat(date1)
                date = simpleDateFormat!!.parse(eventdate)
            } catch (e: ParseException) {
                e.printStackTrace()
            }
            return date!!.time
        }


        fun convertStringToDate(_date: String?): Date? {
            try {
                simpleDateFormat = SimpleDateFormat(date1)
                date = simpleDateFormat!!.parse(_date)
            } catch (e: ParseException) {
                e.printStackTrace()
            }
            return date
        }

        fun getDate(milliSeconds: Long, dateFormat: String?): String? {
            // Create a DateFormatter object for displaying date in specified format.
            val formatter = SimpleDateFormat(dateFormat)

            // Create a calendar object that will convert the date and time value in milliseconds to date.
            val calendar = Calendar.getInstance()
            calendar.timeInMillis = milliSeconds
            return formatter.format(calendar.time)
        }


        fun getDeviceDateTime(): String? {
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
            return sdf.format(Date().timezoneOffset)
        }

        fun getTimeInMillis(time: String?): Long {
            val sdf = SimpleDateFormat("HH:mm:ss")
            sdf.timeZone = TimeZone.getTimeZone("UTC")
            var timeinmillis: Long = 0
            try {
                val date = sdf.parse(time)
                Log.d("TAG", "getTimeInMillis: timein millis : " + date.time)
                timeinmillis = date.time
            } catch (e: ParseException) {
                e.printStackTrace()
            }
            return timeinmillis
        }

        fun getDateInMillis(time: String?): Long {
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
            sdf.timeZone = TimeZone.getTimeZone("UTC")
            var timeinmillis: Long = 0
            try {
                val date = sdf.parse(time)
                Log.d("TAG", "getTimeInMillis: timein millis : " + date.time)
                timeinmillis = date.time
            } catch (e: ParseException) {
                e.printStackTrace()
                Log.d("TAG", "getDateInMillis: " + e.message)
            }
            return timeinmillis
        }

        @SuppressLint("SimpleDateFormat")
        fun getDeviceTime(): String? {
            //date output format
            val dateFormat: DateFormat = SimpleDateFormat("HH:mm:ss")
            val cal = Calendar.getInstance()
            return dateFormat.format(cal.time)
        }

        @SuppressLint("SimpleDateFormat")
        fun getDate(time: String?): String? {
            val inputPattern = "yyyy-MM-dd HH:mm:ss"
            val outputPattern = date2
            val inputFormat = SimpleDateFormat(inputPattern)
            val outputFormat = SimpleDateFormat(outputPattern)
            var date: Date? = null
            var str: String? = null
            try {
                date = inputFormat.parse(time)
                str = outputFormat.format(date)
            } catch (e: ParseException) {
                e.printStackTrace()
            }
            return str
        }

        @SuppressLint("SimpleDateFormat")
        fun getConversionTime(time: String?): String? {
            val inputPattern = "yyyy-MM-dd HH:mm:ss"
            val outputPattern = "d MMM yyyy h:mm"
            val inputFormat = SimpleDateFormat(inputPattern)
            val outputFormat = SimpleDateFormat(outputPattern)
            var date: Date? = null
            var str: String? = null
            try {
                date = inputFormat.parse(time)
                str = outputFormat.format(date)
            } catch (e: ParseException) {
                e.printStackTrace()
            }
            return str
        }

        @SuppressLint("SimpleDateFormat")
        fun getTimeInHHMMSS(time: String?): String? {
            val inputPattern = "yyyy-MM-dd HH:mm:ss"
            val outputPattern = "HH:mm:ss"
            val inputFormat = SimpleDateFormat(inputPattern)
            val outputFormat = SimpleDateFormat(outputPattern)
            var date: Date? = null
            var str: String? = null
            try {
                date = inputFormat.parse(time)
                str = outputFormat.format(date)
            } catch (e: ParseException) {
                e.printStackTrace()
            }
            return str
        }

        @SuppressLint("SimpleDateFormat")
        fun changeDate(time: String?): String? {
            val inputPattern = "yyyy-MM-dd"
            val outputPattern = "dd-MM-yyyy"
            val inputFormat = SimpleDateFormat(inputPattern)
            val outputFormat = SimpleDateFormat(outputPattern)
            var date: Date? = null
            var str: String? = null
            try {
                date = inputFormat.parse(time)
                str = outputFormat.format(date)
            } catch (e: ParseException) {
                e.printStackTrace()
            }
            return str
        }

        @SuppressLint("SimpleDateFormat")
        fun reversechangeDate(time: String): String {
            val inputPattern = "dd-MM-yyyy"
            val outputPattern = "yyyy-MM-dd"
            val inputFormat = SimpleDateFormat(inputPattern)
            val outputFormat = SimpleDateFormat(outputPattern)
            var date: Date? = null
            var str: String? = null
            try {
                date = inputFormat.parse(time)
                str = outputFormat.format(date)
            } catch (e: ParseException) {
                e.printStackTrace()
            }
            return str!!
        }

        @SuppressLint("SimpleDateFormat")
        fun changeDateTimeToDate(time: String?): String? {
            val inputPattern = "yyyy-MM-dd HH:mm:ss"
            val outputPattern = "dd-MM-yyyy"
            val inputFormat = SimpleDateFormat(inputPattern)
            val outputFormat = SimpleDateFormat(outputPattern)
            var date: Date? = null
            var str: String? = null
            try {
                date = inputFormat.parse(time)
                str = outputFormat.format(date)
            } catch (e: ParseException) {
                e.printStackTrace()
            }
            return str
        }

        @SuppressLint("SimpleDateFormat")
        fun changeDateTimeToDateForServer(time: String?): String? {
            val inputPattern = "yyyy-MM-dd HH:mm:ss"
            val outputPattern = "yyyy-MM-dd"
            val inputFormat = SimpleDateFormat(inputPattern)
            val outputFormat = SimpleDateFormat(outputPattern)
            var date: Date? = null
            var str: String? = null
            try {
                date = inputFormat.parse(time)
                str = outputFormat.format(date)
            } catch (e: ParseException) {
                e.printStackTrace()
            }
            return str
        }

        @SuppressLint("SimpleDateFormat")
        fun changeDateToServerDate(time: String?): String? {
            val inputPattern = "dd-MM-yyyy"
            val outputPattern = "yyyy-MM-dd"
            val inputFormat = SimpleDateFormat(inputPattern)
            val outputFormat = SimpleDateFormat(outputPattern)
            var date: Date? = null
            var str: String? = null
            try {
                date = inputFormat.parse(time)
                str = outputFormat.format(date)
            } catch (e: ParseException) {
                e.printStackTrace()
            }
            return str
        }
    }
}