package com.whirlpool.prodigio_app.communication

class Constant {

    companion object {

        val PROGRESS: String = "Please wait..."
        val WENT_WRONG: String = "Oop's something went wrong"
        val SEARCHING: String = "Searching"


        // for bottom menu
        const val HOME = 1
        const val EXECUTION = 2
        const val DOCUMET = 3
        const val RUN_JOB = 4
        const val DISABLE_ALL = 5

        //job status
        const val JOB_STATUS_IDEAL = 0
        const val JOB_STATUS_INPROGRESS = 1
        const val JOB_STATUS_PASS = 2
        const val JOB_STATUS_FAIL = 3
        const val JOB_STATUS_TERMINATED = 4

        // job status text
        const val JOB_IDEAL = "Ideal"
        const val JOB_INPROGRESS = "Inprogress"
        const val JOB_PASS = "Completed"
        const val JOB_FAIL = "Fail"
        const val JOB_TERMINATED = "Terminated"

        //project types
        const val MOBILE = "Mobile"
        const val WEB = "Web"
        const val API = "Api"

        //Response error code
        const val RES_ERROR_CODE_FORBIDDEn = 403




    }
}