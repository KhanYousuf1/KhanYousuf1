package com.whirlpool.prodigio_app.view.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.databinding.FrgHomeBinding
import com.whirlpool.prodigio_app.storage.UserData
import com.whirlpool.prodigio_app.utils.CustomIntent
import com.whirlpool.prodigio_app.view.ScrDashboardProjectType
import com.whirlpool.prodigio_app.view.HomeDashboardActivity
import com.whirlpool.prodigio_app.view.ScrLogin

class FrgHome : Fragment() {


    lateinit var binding: FrgHomeBinding



    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //  val factory: HomeViewModelFactory by instance() // dependency injection
        // viewModel = ViewModelProvider(this, factory).get(HomeViewModel::class.java)

        binding = DataBindingUtil.inflate(
            inflater, R.layout.frg_home, container, false
        )
        val rootview = binding.root
        initUI()
        registerClicks()
        return rootview
    }

    fun initUI() {


    }

    fun registerClicks() {
        var bundle = Bundle()
        binding.cvSuiteTrend.setOnClickListener() {
            bundle.putInt("POSITION", 0)
            CustomIntent.startActivity(
                requireActivity(),
                HomeDashboardActivity::class.java,
                false,
                bundle
            )
        }
        binding.cvSuiteStatus.setOnClickListener() {
            bundle.putInt("POSITION", 1)
            CustomIntent.startActivity(
                requireActivity(),
                HomeDashboardActivity::class.java,
                false,
                bundle
            )
        }
        binding.cvSuitePass.setOnClickListener() {
            bundle.putInt("POSITION", 2)
            CustomIntent.startActivity(
                requireActivity(),
                HomeDashboardActivity::class.java,
                false,
                bundle
            )
        }
        binding.cvSuiteTimeTrend.setOnClickListener() {
            bundle.putInt("POSITION", 3)
            CustomIntent.startActivity(
                requireActivity(),
                HomeDashboardActivity::class.java,
                false,
                bundle
            )
        }
        binding.cvSuiteMonthlyExe.setOnClickListener() {
            bundle.putInt("POSITION", 4)
            CustomIntent.startActivity(
                requireActivity(),
                HomeDashboardActivity::class.java,
                false,
                bundle
            )
        }
        binding.cvSuiteProjectExe.setOnClickListener() {
            bundle.putInt("POSITION", 5)
            CustomIntent.startActivity(
                requireActivity(),
                HomeDashboardActivity::class.java,
                false,
                bundle
            )
        }

        binding.cvMobile.setOnClickListener() {
            bundle.putString("FROM", "Mobile")
            CustomIntent.startActivity(
                requireActivity(),
                ScrDashboardProjectType::class.java,
                false,
                bundle
            )
        }

        binding.cvWeb.setOnClickListener() {
            bundle.putString("FROM", "Web")
            CustomIntent.startActivity(
                requireActivity(),
                ScrDashboardProjectType::class.java,
                false,
                bundle
            )
        }

        binding.cvApi.setOnClickListener() {
            bundle.putString("FROM", "Api")
            CustomIntent.startActivity(
                requireActivity(),
                ScrDashboardProjectType::class.java,
                false,
                bundle
            )
        }

        binding.llLogout.setOnClickListener {
            val userData = UserData.getInstance()
            userData?.clearData()
            CustomIntent.startActivity(requireActivity(), ScrLogin::class.java)
        }
    }
}