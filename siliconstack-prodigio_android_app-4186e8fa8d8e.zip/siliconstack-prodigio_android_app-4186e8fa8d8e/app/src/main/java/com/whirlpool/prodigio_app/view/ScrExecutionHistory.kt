package com.whirlpool.prodigio_app.view

import android.content.Context
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.R.color.execution_all_jobs
import com.whirlpool.prodigio_app.communication.Constant
import com.whirlpool.prodigio_app.communication.response.OfRecords
import com.whirlpool.prodigio_app.databinding.ActivityScrExecutionHistoryBinding
import com.whirlpool.prodigio_app.databinding.LayoutNoDataBinding
import com.whirlpool.prodigio_app.databinding.LayoutToolbarNewBinding
import com.whirlpool.prodigio_app.pagination.PaginationScrollListener
import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.utils.CustomDialoge
import com.whirlpool.prodigio_app.utils.CustomToast
import com.whirlpool.prodigio_app.view.adapter.ExecutionHistoryAdapter
import com.whirlpool.prodigio_app.view.dialoges.DlgDeleteJob
import com.whirlpool.prodigio_app.view.dialoges.DlgEditExecutionName
import com.whirlpool.prodigio_app.view.dialoges.DlgExtentReport
import com.whirlpool.prodigio_app.view.dialoges.DlgReExecuteJob
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModel
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModelFactory
import org.json.JSONException
import org.json.JSONObject
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance
import android.view.inputmethod.EditorInfo

import android.widget.TextView
import android.widget.TextView.OnEditorActionListener
import com.whirlpool.prodigio_app.view.adapter.ExecutionHistorySearchAdapter


class ScrExecutionHistory : AppCompatActivity(), KodeinAware,
    SwipeRefreshLayout.OnRefreshListener, ExecutionHistoryAdapter.onSwipeOptionClikedLister,
    DlgReExecuteJob.BottomSheetReExecuteListener, DlgDeleteJob.BottomSheetDeleteListener,
    DlgEditExecutionName.BottomSheetEditExecutionNameListener {

    private val TAG = ScrExecutionHistory::class.java.name

    override val kodein by kodein()

    lateinit var binding: ActivityScrExecutionHistoryBinding
    lateinit var toolbarbinding: LayoutToolbarNewBinding
    lateinit var noDataBindin: LayoutNoDataBinding
    lateinit var viewModel: ExecutionViewModel

    lateinit var adapter: ExecutionHistoryAdapter

    lateinit var ofRecord: OfRecords
    var itemPos = 0;

    //bottom dialogs
    lateinit var bottomSheetReExecute: DlgReExecuteJob
    lateinit var bottomSheetExtentReport: DlgExtentReport
    lateinit var bottomSheetEditExecutionName: DlgEditExecutionName
    lateinit var bottomSheetDeleteJob: DlgDeleteJob

    //pagination setup
    private val PAGE_START = 1

    private var isLoading = false
    private var isLastPage = false
    private val TOTAL_PAGES = 5
    private var currentPage = PAGE_START

    var searched_text: String = ""

    lateinit var searchAdapter: ExecutionHistorySearchAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = resources.getColor(R.color.white)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            window.statusBarColor = Color.WHITE
        }

        val factory: ExecutionViewModelFactory by instance() // dependency injection
        viewModel = ViewModelProvider(this, factory).get(ExecutionViewModel::class.java)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_scr_execution_history)

        initUI()
        registerClicks()
        setUpToolBar()
        callApi()
    }

    fun initUI() {
        //bottom dialogs
        bottomSheetReExecute = DlgReExecuteJob()
        bottomSheetExtentReport = DlgExtentReport()
        bottomSheetEditExecutionName = DlgEditExecutionName()
        bottomSheetEditExecutionName.mListner = this
        bottomSheetDeleteJob = DlgDeleteJob()

        //inti no data layout
        noDataBindin = binding.llNoData

        binding.swipeRefreshLayout.setOnRefreshListener(this)
        binding.swipeRefreshLayout.setColorSchemeColors(
            ContextCompat.getColor(this, execution_all_jobs),
            ContextCompat.getColor(this, R.color.execution_history),
            ContextCompat.getColor(this, R.color.execution_in_progress),
            ContextCompat.getColor(this, R.color.execution_scheduled)
        )
        //init recyclerview
        val layoutManager =
            LinearLayoutManager(this@ScrExecutionHistory, RecyclerView.VERTICAL, false)
        adapter =
            ExecutionHistoryAdapter(
                this@ScrExecutionHistory
            )
        searchAdapter = ExecutionHistorySearchAdapter(this)
        binding.rvHistory.layoutManager = layoutManager
        binding.rvHistory.adapter = adapter
        binding.rvHistory.adapter?.notifyDataSetChanged()
        binding.rvHistory.addOnScrollListener(object :
            PaginationScrollListener(layoutManager) {
            override fun loadMoreItems() {
                isLoading = true
                currentPage += 1
                Log.d(TAG, "loadMoreItems: isLoading : $isLoading  current page: $currentPage")
                getExecutionHistoryNextPage(currentPage)
            }

            override fun getTotalPageCount(): Int {
                return TOTAL_PAGES
            }

            override fun isLastPage(): Boolean {
                return isLastPage
            }

            override fun isLoading(): Boolean {
                return isLoading
            }

        })
    }


    override fun onResume() {
        super.onResume()
    }

    fun callApi() {
        getExecutionHistoryFirstPage()
    }

    fun getExecutionHistoryFirstPage() {
        binding.swipeRefreshLayout.isRefreshing = true
        Coroutines.main {
            val res = viewModel.getExecutionHistory(PAGE_START, searched_text)
            Log.d(TAG, "getExecutionHistoryFirstPage: respo : " + res)
            Log.d(TAG, "getExecutionHistoryFirstPage: respo : " + res.body()?.listOfRecords)
            binding.swipeRefreshLayout.isRefreshing = false
            if (res.isSuccessful) {
                val list: ArrayList<OfRecords> = res.body()?.listOfRecords as ArrayList<OfRecords>
                adapter.setList(list)
                if (currentPage <= TOTAL_PAGES) adapter.addLoadingFooter() else isLastPage =
                    true
            } else {
                CustomToast.showToast(res.message())
            }
            showEmptyLayout()
        }
    }

    fun getExecutionHistoryNextPage(pageNo: Int) {
        Coroutines.main {
            val res = viewModel.getExecutionHistory(pageNo, searched_text)
            Log.d(TAG, "getExecutionHistoryNextPage: respo : " + res)
            Log.d(TAG, "getExecutionHistoryNextPage: respo : " + res.body()?.listOfRecords)
            if (res.isSuccessful) {
                adapter.removeLoadingFooter()
                isLoading = false
                val list: ArrayList<OfRecords> =
                    res.body()?.listOfRecords as ArrayList<OfRecords>
                adapter.addAll(list)
                if (currentPage != TOTAL_PAGES) adapter.addLoadingFooter() else isLastPage = true
            } else {
                CustomToast.showToast(res.message())
            }
            showEmptyLayout()
        }
    }

    fun showEmptyLayout() {
        Log.d(TAG, "showEmptyLayout: itemCount : " + adapter.itemCount)
        if (adapter.itemCount == 0) {
            binding.llMain.visibility = View.GONE
            noDataBindin.llNoData.visibility = View.VISIBLE
        } else {
            binding.llMain.visibility = View.VISIBLE
            noDataBindin.llNoData.visibility = View.GONE
        }
    }

    fun setUpToolBar() {
        //init toolbar
        toolbarbinding = binding.llToolBar

        toolbarbinding.llBack.setOnClickListener { finish() }
        toolbarbinding.llSearch.setOnClickListener {
            toolbarbinding.llSearchContainer.visibility = View.VISIBLE
            toolbarbinding.llHeaderMain.visibility = View.GONE
        }
        toolbarbinding.llClose.setOnClickListener {
            if (toolbarbinding.etSearch.text.toString().isNullOrBlank()) {
                toolbarbinding.llSearchContainer.visibility = View.GONE
                toolbarbinding.llHeaderMain.visibility = View.VISIBLE
                searched_text = ""
            } else {
                toolbarbinding.etSearch.text = null
                binding.rvHistory.adapter = adapter
            }
        }

        val in_: InputMethodManager =
            getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        in_.hideSoftInputFromWindow(toolbarbinding.etSearch.getWindowToken(), 0)

        /*toolbarbinding.etSearch.doAfterTextChanged {
            var text = it.toString()
            Log.d(TAG, "setUpToolBar: doAfterTextChanged : $text")
        }*/

        toolbarbinding.etSearch.setOnEditorActionListener(OnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                getExecutionHistoryBySearchValue(toolbarbinding.etSearch.text.toString())
                return@OnEditorActionListener true
            }
            false
        })
    }

    fun registerClicks() {

    }


    override fun onRefresh() {
        getExecutionHistoryFirstPage()
    }

    override fun onOptionClicked(type: Int, ofRecord: OfRecords, position: Int) {
        Log.d(TAG, "onOptionClicked: type : $type exeHeaderId: ${ofRecord.exeHeaderId}")
        this.ofRecord = ofRecord
        itemPos = position
        when (type) {
            1 -> {
                bottomSheetReExecute.show(supportFragmentManager, TAG)
            }
            2 -> {
                bottomSheetExtentReport.show(supportFragmentManager, TAG)
                bottomSheetExtentReport.setData(ofRecord)
            }
            3 -> {
                bottomSheetEditExecutionName.show(supportFragmentManager, TAG)
                bottomSheetEditExecutionName.setData(ofRecord)
            }
            4 -> {
                bottomSheetDeleteJob.show(supportFragmentManager, TAG)
            }
        }
    }

    //bottom Dialogs
    override fun onReExecuteButtonClicked(type: Int) {
        if (type == 1) {
            reExecuteJob()
        }
    }

    override fun onDeleteJobButtonClicked(type: Int) {
        if (type == 1) {
            Log.d(TAG, "onDeleteJobButtonClicked: Job Deleted")
            deleteExecutionHistoryById();
        }
    }

    fun deleteExecutionHistoryById() {
        CustomDialoge.showDialog(this, Constant.PROGRESS)
        Coroutines.main {
            val res = viewModel.deleteExecutionHistoryById(ofRecord.exeHistoryId.toString())
            Log.d(TAG, "deleteExecutionHistoryById: respo : " + res)
            Log.d(TAG, "deleteExecutionHistoryById: respo : " + res.body())
            CustomDialoge.closeDialog(this)
            if (res.isSuccessful) {
                adapter.remove(itemPos)
                bottomSheetDeleteJob.dismiss()
                CustomToast.showToast("Job Deleted")
            } else {
                CustomToast.showToast(res.message())
            }
            showEmptyLayout()
        }
    }

    override fun onExecuteUpdateClicked(new_execute_name: String) {
        Log.d(TAG, "onExecuteUpdateClicked: new execution name : $new_execute_name")
        checkForDuplicateForExecutionHistoryName(new_execute_name)
    }


    fun checkForDuplicateForExecutionHistoryName(new_execute_name: String) {
        CustomDialoge.showDialog(this, Constant.PROGRESS)
        Coroutines.main {
            val params: HashMap<String?, String?> = HashMap()
            params.put("resource", new_execute_name)
            params.put("id", "0")
            params.put("type", "")
            params.put("optionalId", "")
            val res =
                viewModel.checkForDuplicateForExecutionHistoryName(params)
            Log.d(TAG, "checkForDuplicateForExecutionHistoryName: respo : " + res)
            Log.d(TAG, "checkForDuplicateForExecutionHistoryName: respo : " + res.body())
            CustomDialoge.closeDialog(this)
            if (res.isSuccessful) {
                if (res.body().equals("false")) {
                    changeTestExecutionName(new_execute_name)
                } else {
                    CustomToast.showToast("This name is already exist")
                }
            } else {
                CustomToast.showToast(res.message())
            }
        }
    }


    fun changeTestExecutionName(new_execute_name: String) {
        CustomDialoge.showDialog(this, Constant.PROGRESS)
        Coroutines.main {
            val params: HashMap<String?, String?> = HashMap()
            params.put("exeHeaderId", ofRecord.exeHeaderId.toString())
            params.put("executionName", new_execute_name)
            val res =
                viewModel.changeTestExecutionName(params)
            Log.d(TAG, "changeTestExecutionName: respo : " + res)
            Log.d(TAG, "changeTestExecutionName: respo : " + res.body())
            CustomDialoge.closeDialog(this)
            if (res.isSuccessful) {
                val obj = JSONObject(res.body())
                val status = obj.getString("status")
                CustomToast.showToast(status)
                bottomSheetEditExecutionName.dismiss()
                getExecutionHistoryFirstPage()
            } else {
                CustomToast.showToast(res.message())
            }
            showEmptyLayout()
        }
    }

    fun reExecuteJob() {
        CustomDialoge.showDialog(this, Constant.PROGRESS)
        Coroutines.main {
            val params: HashMap<String?, String?> = HashMap()
            params.put("exeHeaderId", ofRecord.exeHeaderId.toString())
            params.put("exeHistoryId", ofRecord.exeHistoryId.toString())
            params.put("userId", "1")
            val res =
                viewModel.reExecuteJob(params)
            Log.d(TAG, "reExecuteJob: respo : " + res)
            Log.d(TAG, "reExecuteJob: respo : " + res.body())
            CustomDialoge.closeDialog(this)
            if (res.isSuccessful) {
                try {
                    val obj = JSONObject(res.body())
                    CustomToast.showToast("Job has been re-scheduled")
                    bottomSheetReExecute.dismiss()
                    getExecutionHistoryFirstPage()
                } catch (e: JSONException) {
                    Log.d(TAG, "reExecuteJob: JSONException : ${e.message}")
                }
            } else {
                CustomToast.showToast(res.message())
            }
            showEmptyLayout()
        }
    }


    fun getExecutionHistoryBySearchValue(searched_text: String) {
        CustomDialoge.showDialog(this, Constant.SEARCHING)
        Coroutines.main {
            val res = viewModel.getExecutionHistory(PAGE_START, searched_text)
            Log.d(TAG, "getExecutionHistoryFirstPage: respo : " + res)
            Log.d(TAG, "getExecutionHistoryFirstPage: respo : " + res.body()?.listOfRecords)
            CustomDialoge.closeDialog(this)
            if (res.isSuccessful) {
                val list: ArrayList<OfRecords> = res.body()?.listOfRecords as ArrayList<OfRecords>
                binding.rvHistory.adapter = searchAdapter
                searchAdapter.setList(list)

            } else {
                CustomToast.showToast(res.message())
            }
            showEmptyLayout()
        }
    }

}