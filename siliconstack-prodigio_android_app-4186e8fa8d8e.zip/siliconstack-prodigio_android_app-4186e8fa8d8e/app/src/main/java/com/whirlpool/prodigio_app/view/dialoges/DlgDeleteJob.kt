package com.whirlpool.prodigio_app.view.dialoges

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.deishelon.roundedbottomsheet.RoundedBottomSheetDialogFragment
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.databinding.DlgDeleteAllRecordBinding
import com.whirlpool.prodigio_app.databinding.DlgLogoutBinding
import java.lang.ClassCastException

class DlgDeleteJob() : RoundedBottomSheetDialogFragment(), View.OnClickListener {

    lateinit var binding: DlgDeleteAllRecordBinding
    lateinit var mListner: BottomSheetDeleteListener

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding =
            DataBindingUtil.inflate(inflater, R.layout.dlg_delete_all_record, container, false)
        val rootView = binding.root
        reisterClicks()
        return rootView
    }

    private fun reisterClicks() {
        binding.cvCancel.setOnClickListener(this)
        binding.cvDelete.setOnClickListener(this)
    }

    override fun onClick(p0: View?) {
        when (p0?.id) {
            R.id.cv_cancel -> {
              dismiss()
            }
            R.id.cv_delete -> {
                mListner.onDeleteJobButtonClicked(1)
            }
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        try {
            mListner = context as BottomSheetDeleteListener

        } catch (e: ClassCastException) {
            throw ClassCastException(
                context.toString()
                        + " must implement BottomSheetListener"
            )
        }
    }

    interface BottomSheetDeleteListener {
        fun onDeleteJobButtonClicked(type: Int)
    }


}