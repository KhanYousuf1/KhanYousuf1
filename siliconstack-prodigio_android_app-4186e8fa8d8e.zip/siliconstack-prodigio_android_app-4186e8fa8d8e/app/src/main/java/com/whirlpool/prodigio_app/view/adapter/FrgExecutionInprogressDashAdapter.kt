package com.whirlpool.prodigio_app.view.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.ExecutionInProgress
import com.whirlpool.prodigio_app.databinding.ItemExecutionDashInprogressAdapterBinding
import com.whirlpool.prodigio_app.databinding.ItemExecutionInProgressBinding
import com.whirlpool.prodigio_app.view.ScrExecutionInProgress
import com.whirlpool.prodigio_app.view.ScrExecutionInProgressSub

class FrgExecutionInprogressDashAdapter (var context: Context) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var items: ArrayList<ExecutionInProgress> = ArrayList<ExecutionInProgress>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = DataBindingUtil.inflate<ItemExecutionDashInprogressAdapterBinding>(
            LayoutInflater.from(parent.context), R.layout.item_execution_dash_inprogress_adapter,
            parent, false
        )
        return ItemHolder(binding)
    }

    fun setList(items: ArrayList<ExecutionInProgress>) {
        this.items = items
        notifyDataSetChanged()
    }

    fun filteredList(filteredList: ArrayList<ExecutionInProgress>) {
        items = filteredList
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val execution = items[position]
        val viewHolder = holder as FrgExecutionInprogressDashAdapter.ItemHolder

        viewHolder.binding.tvExecId.text = execution.exeHeaderId.toString()
        viewHolder.binding.tvJobName.text = execution.jobName
        viewHolder.binding.tvDateTime.text = execution.startDate

        /*viewHolder.binding.cvView.setOnClickListener {
            val execu = it.tag as ExecutionInProgress
            val intent = Intent(context, ScrExecutionInProgressSub::class.java)
            intent.putExtra("ExecutionInProgress", execu)
            context.startActivity(intent)
            viewHolder.binding.es.resetStatus()
        }

        viewHolder.binding.cvStop.tag = execution
        viewHolder.binding.cvStop.setOnClickListener {
            val execu = it.tag as ExecutionInProgress
            inprogrgessListner.onStopExecutionClicked(execu)
            viewHolder.binding.es.resetStatus()
        }*/


        blinkAnimation(viewHolder.binding.cvBlink)
    }

    fun blinkAnimation(view: MaterialCardView) {
        val anim: Animation = AlphaAnimation(0.5f, 9.0f)
        anim.setDuration(50) //You can manage the blinking time with this parameter

        anim.setStartOffset(20)
        anim.setRepeatMode(Animation.REVERSE)
        anim.setRepeatCount(Animation.INFINITE)
        view.startAnimation(anim)
    }

    override fun getItemCount(): Int {
        return items.count()
    }

    inner class ItemHolder(val binding: ItemExecutionDashInprogressAdapterBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }

}