package com.whirlpool.prodigio_app.view.dialoges

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.deishelon.roundedbottomsheet.RoundedBottomSheetDialogFragment
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.databinding.DlgDeleteAllRecordBinding
import com.whirlpool.prodigio_app.databinding.DlgJobDeletedSuccessfullyBinding
import com.whirlpool.prodigio_app.databinding.DlgLogoutBinding
import java.lang.ClassCastException

class DlgJobDeletedSuccessfully() : RoundedBottomSheetDialogFragment(), View.OnClickListener {

    lateinit var binding: DlgJobDeletedSuccessfullyBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding =
            DataBindingUtil.inflate(inflater, R.layout.dlg_job_deleted_successfully, container, false)
        val rootView = binding.root
        reisterClicks()
        return rootView
    }

    private fun reisterClicks() {
    }

    override fun onClick(p0: View?) {

    }





}