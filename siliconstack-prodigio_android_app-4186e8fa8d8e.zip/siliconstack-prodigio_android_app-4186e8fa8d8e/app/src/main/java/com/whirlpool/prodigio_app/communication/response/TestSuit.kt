package com.whirlpool.prodigio_app.communication.response

data class TestSuit(
    var testSuiteId: Int,
    var testSuiteName: String,
    var testSuiteDesc: String,
    var projectName: String,
    var platformId: Int,
    var projectTypeId: Int,
    var regionId: Int,
    var brandId: Int,
    var applianceId: Int,
    var userId: Int,
    var jiraProjectKey: String,
    var jiraProjectName: String,
    var testSuiteJiraNo: String,
    var createdOn: String,
    var modifiedOn: String,
    var suiteNumber: Int,
    var syncWithJira: Boolean
)