package com.whirlpool.prodigio_app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.whirlpool.prodigio_app.repository.Repository

class DashboardGraphViewModelFactory  (private val repository: Repository,
) :
    ViewModelProvider.NewInstanceFactory() {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return DashboardGraphViewModel( repository) as T
    }

}