package com.whirlpool.prodigio_app.view

import android.annotation.SuppressLint
import android.graphics.Color
import android.opengl.Visibility
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Html
import android.util.Log
import android.view.View
import android.view.View.GONE
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.google.gson.JsonObject
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.databinding.ActivityScrDisplayAppiumLogFileBinding
import com.whirlpool.prodigio_app.databinding.ActivityScrDisplayExtentReportBinding
import org.json.JSONObject
import android.webkit.WebViewClient

import android.webkit.WebChromeClient

import android.webkit.WebSettings


class ScrDisplayExtentReport : AppCompatActivity() {

    companion object {
        var html_data = MutableLiveData<String>()
    }

    private val TAG = ScrDisplayExtentReport::class.java.name
    lateinit var binding: ActivityScrDisplayExtentReportBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = resources.getColor(R.color.white)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            window.statusBarColor = Color.WHITE
        }
        binding = DataBindingUtil.setContentView(this, R.layout.activity_scr_display_extent_report)
        registerClicks()
        initWebView()
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun initWebView() {
        with(binding) {
            webview.settings.useWideViewPort = true
            webview.settings.loadWithOverviewMode = true
            webview.settings.javaScriptEnabled = true
            webview.settings.javaScriptCanOpenWindowsAutomatically = true
            webview.settings.domStorageEnabled = true
            webview.settings.pluginState = WebSettings.PluginState.ON
            webview.settings.loadWithOverviewMode = true
            webview.webChromeClient = WebChromeClient()
            webview.webViewClient = WebViewClient()
//            webview.addJavascriptInterface(WebAppInterface(this), "Android")
        }

        html_data.observe(this, Observer {
//            Log.d(TAG, "initWebView: it $it")
            val obj = JSONObject(it)
            var html_data = obj.get("key")
            html_data = html_data.toString().replace("\\r".toRegex(), "")
            html_data = html_data.toString().replace(Regex("\\r"), "")
            html_data = html_data.toString().replace("\\n".toRegex(), "")
            html_data = html_data.toString().replace(Regex("\\n"), "")
            html_data = html_data.toString().replace("\\t".toRegex(), "")
            html_data = html_data.toString().replace(Regex("\\t"), "")
//            html_data = html_data.toString().replace("\\r\\n\\t".toRegex()," ")
//            html_data = html_data.toString().replace(Regex("\\r\\n\\t")," ")
//            val html_data = it.toString()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                binding.textViewHTML.setText(
                    Html.fromHtml(
                        html_data,
                        Html.FROM_HTML_MODE_COMPACT
                    )
                );
            } else {
                binding.textViewHTML.setText(Html.fromHtml(html_data));
            }
            binding.textViewHTML.visibility = GONE
//            binding.textViewHTML.setText(html_data)
            Log.d(TAG, "initWebView: html_code - $html_data")
            binding.webview.loadDataWithBaseURL("file:///android_asset/Data.html",html_data, "text/html", "UTF-8",null)

//            binding.webview.loadUrl("file:///android_asset/Data.html")
        })
    }

    private fun registerClicks() {
        binding.llBack.setOnClickListener { finish() }
    }


}