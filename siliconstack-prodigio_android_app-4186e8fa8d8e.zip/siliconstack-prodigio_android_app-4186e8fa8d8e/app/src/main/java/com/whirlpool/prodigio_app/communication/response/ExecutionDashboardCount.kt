package com.whirlpool.prodigio_app.communication.response

data class ExecutionDashboardCount(
    val jobCompleted: Int,
    val jobInProgress: Int,
    val jobSchedule: Int,
    val executionHeadeList : ArrayList<ExecutionInProgress>
)