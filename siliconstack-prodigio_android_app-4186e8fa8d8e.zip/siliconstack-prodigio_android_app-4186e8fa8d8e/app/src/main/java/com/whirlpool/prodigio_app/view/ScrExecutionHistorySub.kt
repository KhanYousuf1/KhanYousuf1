package com.whirlpool.prodigio_app.view

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.R.color.execution_all_jobs
import com.whirlpool.prodigio_app.bottomClickInterface.BottomAppBarClickListner
import com.whirlpool.prodigio_app.communication.response.ExecutionHistorySubItem
import com.whirlpool.prodigio_app.databinding.ActivityScrExecutionHistorySubBinding
import com.whirlpool.prodigio_app.databinding.LayoutToolbarNewBinding
import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.utils.CustomToast
import com.whirlpool.prodigio_app.view.adapter.ExecutionHistorySubAdapter
import com.whirlpool.prodigio_app.view.dialoges.DlgExtentReport
import com.whirlpool.prodigio_app.view.dialoges.DlgLogout
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModel
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModelFactory
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance

class ScrExecutionHistorySub : AppCompatActivity(), View.OnClickListener, KodeinAware,
    SwipeRefreshLayout.OnRefreshListener {

    private val TAG = ScrExecutionHistorySub::class.java.name

    override val kodein by kodein()

    lateinit var binding: ActivityScrExecutionHistorySubBinding
    lateinit var toolbarbinding: LayoutToolbarNewBinding
    lateinit var viewModel: ExecutionViewModel
    lateinit var exeHeaderId: String
    lateinit var exeHistoryId: String
    lateinit var exeName: String


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = resources.getColor(R.color.white)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            window.statusBarColor = Color.WHITE
        }

        val factory: ExecutionViewModelFactory by instance() // dependency injection
        viewModel = ViewModelProvider(this, factory).get(ExecutionViewModel::class.java)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_scr_execution_history_sub)

        initUI()
        registerClicks()
        getIntentData()
        setUpToolBar()
    }

    fun getIntentData() {
        val intent = intent.extras
        exeHeaderId = intent?.getString("exeHeaderId").toString()
        exeHistoryId = intent?.getString("exeHistoryId").toString()
        exeName = intent?.getString("exeName").toString()
        Log.d(
            TAG,
            "getIntentData: exeHeaderId : $exeHeaderId exeHistoryId : $exeHistoryId exeName : $exeName"
        )
    }

    fun initUI() {

        binding.swipeRefreshLayout.setOnRefreshListener(this)
        binding.swipeRefreshLayout.setColorSchemeColors(
            ContextCompat.getColor(this, execution_all_jobs),
            ContextCompat.getColor(this, R.color.execution_history),
            ContextCompat.getColor(this, R.color.execution_in_progress),
            ContextCompat.getColor(this, R.color.execution_scheduled)
        )

    }

    fun setUpToolBar() {
        //init toolbar
        toolbarbinding = binding.llToolBar
        toolbarbinding.llBack.setOnClickListener { finish() }
        toolbarbinding.llSearch.visibility = View.GONE
        toolbarbinding.tvToolBarHeader.text = exeName

        toolbarbinding.llSearch.setOnClickListener {
            toolbarbinding.llSearchContainer.visibility = View.VISIBLE
            toolbarbinding.llHeaderMain.visibility = View.GONE
        }
        toolbarbinding.llClose.setOnClickListener {
            if (toolbarbinding.etSearch.text.toString().isNullOrBlank()) {
                toolbarbinding.llSearchContainer.visibility = View.GONE
                toolbarbinding.llHeaderMain.visibility = View.VISIBLE
            } else toolbarbinding.etSearch.text = null
        }


        toolbarbinding.etSearch.doAfterTextChanged {
            var text = it.toString()
            Log.d(TAG, "setUpToolBar: doAfterTextChanged : $text")
        }

    }


    override fun onResume() {
        super.onResume()
        callApi()
    }

    fun callApi() {
        getExecutionHistorySub()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun getExecutionHistorySub() {
        binding.swipeRefreshLayout.isRefreshing = true
        Coroutines.main {
            val res = viewModel.getExecutionHistorySub(exeHeaderId, exeHistoryId)
            Log.d(TAG, "getExecutionHistorySub: res : $res")
            Log.d(TAG, "getExecutionHistorySub: res : ${res.body()}")

            binding.swipeRefreshLayout.isRefreshing = false
            if (res.isSuccessful) {
                binding.rvHistorySub.apply {
                    layoutManager =
                        LinearLayoutManager(
                            this@ScrExecutionHistorySub,
                            RecyclerView.VERTICAL,
                            false
                        )
                    adapter =
                        ExecutionHistorySubAdapter(
                            this@ScrExecutionHistorySub,
                            res.body() as ArrayList<ExecutionHistorySubItem>
                        )
                    binding.rvHistorySub.adapter = adapter
                    binding.rvHistorySub.adapter?.notifyDataSetChanged()
                }
            } else {
                CustomToast.showToast(res.message())
            }
        }
    }


    fun registerClicks() {
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.ll_back -> {
                finish()
            }
        }
    }

    override fun onRefresh() {
        getExecutionHistorySub()
    }

}