package com.whirlpool.prodigio_app.repository

import android.util.Log
import com.whirlpool.prodigio_app.communication.ApiInterface
import com.whirlpool.prodigio_app.communication.HeaderConstant
import com.whirlpool.prodigio_app.communication.NetworkConnectionInterceptor
import com.whirlpool.prodigio_app.communication.response.*
import com.whirlpool.prodigio_app.storage.UserData
import okhttp3.ResponseBody
import retrofit2.Response
import java.net.URLDecoder

class Repository(val networkConnectionInterceptor: NetworkConnectionInterceptor) {

    val TAG: String = Repository::class.java.name

   

    //loggin
    suspend fun login(params: HashMap<String?, String?>): Response<Login> {
        return ApiInterface(networkConnectionInterceptor).login(
            HeaderConstant.requestHeaderLogin(),
            params
        )
    }

    //get Execution History
    suspend fun getExecutionHistory(
        pageNo: Int,
        searched_text: String
    ): Response<ExecutionHistory> {
        val params: HashMap<String?, String?> = HashMap()
        params["pageNo"] = pageNo.toString()
        params["pageSize"] = "25"
        if (!searched_text.isNullOrEmpty()) {
            params["searchBy"] = searched_text
        }
        return ApiInterface(networkConnectionInterceptor).executionHistory(
            UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }

    //delete execution history by id
    suspend fun deleteExecutionHistoryById(
        exeHistoryId: String
    ): Response<String> {
        val params: HashMap<String?, String?> = HashMap()
        params["exeHistoryId"] = exeHistoryId
        return ApiInterface(networkConnectionInterceptor).deleteHistoryById(
            UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }

    //Check for execution history name duplicate
    suspend fun checkForDuplicateForExecutionHistoryName(
        params: HashMap<String?, String?> = HashMap()
    ): Response<String> {
        return ApiInterface(networkConnectionInterceptor).checkForDuplicateForExecutionHistoryName(
            UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }



    //change execution history name
    suspend fun changeTestExecutionName(
        params: HashMap<String?, String?> = HashMap()
    ): Response<String> {
        return ApiInterface(networkConnectionInterceptor).changeTestExecutionName(
            UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }

    //re-execute job from execute history
    suspend fun reExecuteJob(
        params: HashMap<String?, String?> = HashMap()
    ): Response<String> {
        return ApiInterface(networkConnectionInterceptor).reExecuteJob(
            UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }

    //get Execution History Details
    suspend fun getExecutionHistorySub(
        exeHeaderId: String,
        exeHistoryId: String
    ): Response<List<ExecutionHistorySubItem>> {
        val params: HashMap<String?, String?> = HashMap()
        params["exeHeaderId"] = exeHeaderId
        params["exeHistoryId"] = exeHistoryId
        params["seeMore"] = "0"
        return ApiInterface(networkConnectionInterceptor).executionHistorySub(
            UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }


    //get Execution Schedule
    suspend fun getExecutionSchedule(
        pageNo: Int,
        searchBy: String
    ): Response<ExecutionSchedule> {
        val params: HashMap<String?, String?> = HashMap()
        params["pageNo"] = pageNo.toString()
        params["pageSize"] = "25"
        if (!searchBy.equals("")) {
            params["searchBy"] = searchBy
        }
        return ApiInterface(networkConnectionInterceptor).getScheduleList(
            UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }

    //get Execution Schedule
    suspend fun updateSchedule(
        params: HashMap<String?, String?> = HashMap()
    ): Response<String> {
        return ApiInterface(networkConnectionInterceptor).updateSchedule(
            UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }

    //delete Execution Schedule
    suspend fun deleteExecutionSchedule(
        exeHeaderId: Int
    ): Response<String> {
        val params: HashMap<String?, String?> = HashMap()
        params["exeHeaderId"] = exeHeaderId.toString()
        return ApiInterface(networkConnectionInterceptor).deleteSchedule(
            UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }

    //get Execution Dashboard Count
    suspend fun getExecutionDashboardCount(
    ): Response<ExecutionDashboardCount> {
        return ApiInterface(networkConnectionInterceptor).getExecutionCount(
            UserData.getInstance()?.getTOKEN().toString()
        )
    }

    //get Extent Report List
    suspend fun getExtentReportList(
    ): Response<List<ExtentReportList>> {
        val params: HashMap<String?, String?> = HashMap()
        params["exeHeaderId"] = "4"
        params["exeHistoryId"] = "4"
        return ApiInterface(networkConnectionInterceptor).getExtendedReportList(
             UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }


    //get All Project Type
    suspend fun getAllProjectType(
    ): Response<List<ProjectType>> {
        val params: HashMap<String?, String?> = HashMap()
        return ApiInterface(networkConnectionInterceptor).getAllProjectType(
             UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }

    //get All Regions By Project
    suspend fun getAllRegionsByProject(projectTypeId: Int): Response<List<Region>> {
        val params: HashMap<String?, Int?> = HashMap()
        params["projectTypeId"] = projectTypeId
        return ApiInterface(networkConnectionInterceptor).getAllRegionsByProject(
             UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }

    //get All Brands By Regions
    suspend fun getAllBrands(regionId: Int): Response<List<Brand>> {
        val params: HashMap<String?, Int?> = HashMap()
        params["regionId"] = regionId
        return ApiInterface(networkConnectionInterceptor).getAllBrands(
             UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }

    //get All Products
    suspend fun getAllProductNames(
        brandId: Int,
        projectTypeId: Int,
        regionId: Int
    ): Response<List<ProductName>> {
        val params: HashMap<String?, Int?> = HashMap()
        params["brandId"] = brandId
        params["projectTypeId"] = projectTypeId
        params["regionId"] = regionId
        return ApiInterface(networkConnectionInterceptor).getAllProductNames(
             UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }


    //get All Test Suite Name By Project Name
    suspend fun getTestSuiteNameByProjectName(projectName: String): Response<List<TestSuit>> {
        val params: HashMap<String?, String?> = HashMap()
        params["projectName"] = projectName
        return ApiInterface(networkConnectionInterceptor).getTestSuiteNameByProjectName(
             UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }

    //get All Platform
    suspend fun getAllPlatform(projectTypeId: Int): Response<List<Platform>> {
        val params: HashMap<String?, Int?> = HashMap()
        params["projectTypeId"] = projectTypeId
        return ApiInterface(networkConnectionInterceptor).getAllPlatform(
             UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }

    //get All Users
    suspend fun getAllUsers(): Response<List<User>> {
        val params: HashMap<String?, String?> = HashMap()
        return ApiInterface(networkConnectionInterceptor).getAllUser(
             UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }


    //Download Appium Log File
    suspend fun downloadAppiumLogFile(exeHeaderId: Int, exeHistoryId: Int): Response<String> {
        val params: HashMap<String?, String?> = HashMap()
        params["exeHeaderId"] = "4"//exeHeaderId.toString()
        params["exeHistoryId"] = "4"//exeHistoryId.toString()

        return ApiInterface(networkConnectionInterceptor).downloadAppiumLogFile(
             UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }

    //Download Extent Report Log File
    suspend fun downloadExtendReportFile(
        file_name: String
    ): Response<String> {
        val params: HashMap<String?, String?> = HashMap()
        val url = URLDecoder.decode(file_name, "UTF-8")
        params["fileName"] = url
        return ApiInterface(networkConnectionInterceptor).downloadExtendReportFile(
             UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }

    //Download Extent Report Log File
    suspend fun downloadExecutionFiles(
        params: HashMap<String?, String?>
    ): Response<String> {
        return ApiInterface(networkConnectionInterceptor).downloadExecutionFiles(
             UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }

    //Download Extent Report Log File
    suspend fun downloadExecutionLogFiles(
        params: HashMap<String?, String?>
    ): Response<String> {
        return ApiInterface(networkConnectionInterceptor).downloadExecutionLogFiles(
             UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }

    //execution Inprogress Jobs
    suspend fun getRunningJobs(
    ): Response<List<ExecutionInProgress>> {
        return ApiInterface(networkConnectionInterceptor).getRunningJobs(
             UserData.getInstance()?.getTOKEN().toString(),
        )
    }

    //get Dashboard project Types
    suspend fun getDashboardCounts(
    ): Response<List<DashboarProjectType>> {
        return ApiInterface(networkConnectionInterceptor).getDashboardCounts(
             UserData.getInstance()?.getTOKEN().toString(),
            //"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6IlNBUFJBTiIsImlhdCI6MTY0MjA3NDk0MiwiZXhwIjoxNjQyMDgyMTQyfQ.Vg9p4Vu6ty1NY2WM8muEsMTHo7UK-T-53j1NEgs5VxU"
        )
    }

    //getAllDocuments
    suspend fun getAllDocument(
    ): Response<List<Document>> {
        return ApiInterface(networkConnectionInterceptor).getAllDocument(
             UserData.getInstance()?.getTOKEN().toString(),
            //"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6IlNBUFJBTiIsImlhdCI6MTY0MjA3MTkwNCwiZXhwIjoxNjQyMDc5MTA0fQ.3Zw9EgeKhTct96Jlnws3tziOva9tm9bEBK1J7txm23A"
        )
    }


    //getDashboardCountsForTestExecutionTimeTrends
    suspend fun getDashboardCountsForTestExecutionTimeTrends(
        getDashboardCountsForTestExecutionTimeTrendsRequest: DashboardGraphs.GetDashboardCountsForTestExecutionTimeTrendsRequest
    ): Response<ArrayList<DashboardGraphs.GetDashboardCountsForTestExecutionTimeTrendsResponse>> {
        return ApiInterface(networkConnectionInterceptor).getDashboardCountsForTestExecutionTimeTrends(
             UserData.getInstance()?.getTOKEN().toString(), getDashboardCountsForTestExecutionTimeTrendsRequest
        )
    }

    //getDashboardCountsForTestExecutionTrends
    suspend fun getDashboardCountsForTestExecutionTrends(
        getDashboardCountsForTestExecutionTrendsRequest: DashboardGraphs.GetDashboardCountsForTestExecutionTrendsRequest
    ): Response<List<DashboardGraphs.GetDashboardCountsForTestExecutionTrendsResponse>> {
//        val params: HashMap<String?, String?> = HashMap()
//        params["exeHeaderId"] = "4"
//        params["exeHistoryId"] = "4"
        Log.d(
            TAG,
            "getDashboardCountsForTestExecutionTrends: ${getDashboardCountsForTestExecutionTrendsRequest}"
        )
        Log.d(TAG, "getDashboardCountsForTestExecutionTrends: Token - ${ UserData.getInstance()?.getTOKEN().toString()}")
        return ApiInterface(networkConnectionInterceptor).getDashboardCountsForTestExecutionTrends(
             UserData.getInstance()?.getTOKEN().toString(), getDashboardCountsForTestExecutionTrendsRequest
        )
    }

    //getDashboardSuiteCountTrend
    suspend fun getDashboardSuiteCountTrend(
        getDashboardSuiteCountTrendRequest: DashboardGraphs.GetDashboardSuiteCountTrendRequest
    ): Response<DashboardGraphs.GetDashboardSuiteCountTrendResponse> {
        return ApiInterface(networkConnectionInterceptor).getDashboardSuiteCountTrend(
             UserData.getInstance()?.getTOKEN().toString(), getDashboardSuiteCountTrendRequest
        )
    }

    //getDashboardSuiteExeTimeProjectWise
    suspend fun getDashboardSuiteExeTimeProjectWise(
        getDashboardSuiteCountTrendRequest: DashboardGraphs.GetDashboardSuiteExeTimeProjectWiseRequest
    ): Response<ArrayList<DashboardGraphs.GetDashboardSuiteExeTimeProjectWiseResponse>> {
        return ApiInterface(networkConnectionInterceptor).getDashboardSuiteExeTimeProjectWise(
             UserData.getInstance()?.getTOKEN().toString(), getDashboardSuiteCountTrendRequest
        )
    }

    //getDashboardSuiteMonthlyExeStatus
    suspend fun getDashboardSuiteMonthlyExeStatus(
        getDashboardSuiteCountTrendRequest: DashboardGraphs.GetDashboardSuiteMonthlyExeStatusRequest
    ): Response<DashboardGraphs.GetDashboardSuiteMonthlyExeStatusResponse> {
        return ApiInterface(networkConnectionInterceptor).getDashboardSuiteMonthlyExeStatus(
             UserData.getInstance()?.getTOKEN().toString(), getDashboardSuiteCountTrendRequest
        )
    }

    //stop job in-progress
    suspend fun stopJenkinJob(
        params: HashMap<String?, String?> = HashMap()
    ): Response<String> {
        return ApiInterface(networkConnectionInterceptor).stopJenkinJob(
             UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }

    //update stopped job in-progress
    suspend fun updatestoppedJenkinJob(
        params: HashMap<String?, String?> = HashMap()
    ): Response<String> {
        return ApiInterface(networkConnectionInterceptor).updatestoppedJenkinJob(
             UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }


    suspend fun getScheduleListDeatils(
        params: HashMap<String?, String?> = HashMap()
    ): Response<List<ScheduleDetails>> {
        return ApiInterface(networkConnectionInterceptor).getScheduleListDeatils(
             UserData.getInstance()?.getTOKEN().toString(),
            params
        )
    }

    /* //getDashboardCountsForTestExecutionTimeTrends
     suspend fun getDashboardCountsForTestExecutionTimeTrends(
     ): Response<String> {
         val params: HashMap<String?, String?> = HashMap()
         params["exeHeaderId"] = "4"
         params["exeHistoryId"] = "4"
         return ApiInterface(networkConnectionInterceptor).getDashboardCountsForTestExecutionTimeTrends(
             HeaderConstant.requestHeader(),params
         )
     }*/
}
