package com.whirlpool.prodigio_app.view

import android.database.DatabaseUtils
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.Constant
import com.whirlpool.prodigio_app.communication.response.Document
import com.whirlpool.prodigio_app.communication.response.ExecutionInProgress
import com.whirlpool.prodigio_app.communication.response.OfRecords
import com.whirlpool.prodigio_app.databinding.ActivityScrExecutionInProgressBinding
import com.whirlpool.prodigio_app.databinding.LayoutNoDataBinding
import com.whirlpool.prodigio_app.databinding.LayoutToolbarNewBinding
import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.utils.CustomDialoge
import com.whirlpool.prodigio_app.utils.CustomToast
import com.whirlpool.prodigio_app.view.adapter.ExecutionHistoryAdapter
import com.whirlpool.prodigio_app.view.adapter.ExecutionInProgressAdapter
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModel
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModelFactory
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance

class ScrExecutionInProgress : AppCompatActivity(), View.OnClickListener, KodeinAware,
    SwipeRefreshLayout.OnRefreshListener, ExecutionInProgressAdapter.InprogressItemClickListner {

    private val TAG = ScrExecutionInProgress::class.java.name

    override val kodein by kodein()

    lateinit var binding: ActivityScrExecutionInProgressBinding
    lateinit var toolbarbinding: LayoutToolbarNewBinding
    lateinit var noDataBindin: LayoutNoDataBinding
    lateinit var viewModel: ExecutionViewModel

    lateinit var adapter: ExecutionInProgressAdapter

    var list = ArrayList<ExecutionInProgress>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = resources.getColor(R.color.white)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            window.statusBarColor = Color.WHITE
        }
        val factory: ExecutionViewModelFactory by instance() // dependency injection
        viewModel = ViewModelProvider(this, factory).get(ExecutionViewModel::class.java)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_scr_execution_in_progress)

        initUI()
        setUpToolBar()
        registerClicks()
        getExecutionInprogress()
    }

    fun initUI() {
        //inti no data layout
        noDataBindin = binding.llNoData

        binding.swipeRefreshLayout.setOnRefreshListener(this)
        binding.swipeRefreshLayout.setColorSchemeColors(
            ContextCompat.getColor(this, R.color.execution_all_jobs),
            ContextCompat.getColor(this, R.color.execution_history),
            ContextCompat.getColor(this, R.color.execution_in_progress),
            ContextCompat.getColor(this, R.color.execution_scheduled)
        )

        //init recyclerview
        val layoutManager =
            LinearLayoutManager(this, RecyclerView.VERTICAL, false)
        adapter =
            ExecutionInProgressAdapter(
                this@ScrExecutionInProgress
            )
        binding.rvInprogress.layoutManager = layoutManager
        binding.rvInprogress.adapter = adapter
        binding.rvInprogress.adapter?.notifyDataSetChanged()
    }

    fun registerClicks() {
    }

    fun setUpToolBar() {
        //init toolbar
        toolbarbinding = binding.llToolBar
        toolbarbinding.tvToolBarHeader.text = "In Progress"

        toolbarbinding.llBack.setOnClickListener { finish() }
        toolbarbinding.llSearch.setOnClickListener {
            toolbarbinding.llSearchContainer.visibility = View.VISIBLE
            toolbarbinding.llHeaderMain.visibility = View.GONE
        }
        toolbarbinding.llClose.setOnClickListener {
            if (toolbarbinding.etSearch.text.toString().isNullOrBlank()) {
                toolbarbinding.llSearchContainer.visibility = View.GONE
                toolbarbinding.llHeaderMain.visibility = View.VISIBLE
            } else toolbarbinding.etSearch.text = null
        }

        toolbarbinding.etSearch.doAfterTextChanged {
            val text = it.toString()
            Log.d(TAG, "setUpToolBar: doAfterTextChanged : $text")
            filter(text)
        }
    }

    fun filter(text: String) {
        Log.d(TAG, "filter: value : $text list size : " + list.size)
        if (!text.isNullOrBlank()) {
            val arrayList: ArrayList<ExecutionInProgress> = ArrayList<ExecutionInProgress>()
            for (item: ExecutionInProgress in list) {
                if (item.jobName.lowercase().contains(text.lowercase())) {
                    Log.d(
                        TAG,
                        "filter: search for doc name : ${item.jobName} searched Text : ${text.lowercase()}"
                    )
                    arrayList.add(item)
                }
            }
            Log.d(TAG, "filter: arrayListSize : " + arrayList.size)
            Log.d(TAG, "filter: arrayList : " + arrayList.toString())
            adapter.filteredList(arrayList)
        } else {
            adapter.setList(list)
        }
    }


    override fun onClick(p0: View?) {
        when (p0?.id) {
            R.id.ll_back -> {
                finish()
            }
        }
    }


    fun getExecutionInprogress() {
        binding.swipeRefreshLayout.isRefreshing = true
        Coroutines.main {
            val res = viewModel.getRunningJobs()
            Log.d(TAG, "getExecutionInprogress: respo : " + res)
            Log.d(TAG, "getExecutionInprogress: respo : " + res.body())
            binding.swipeRefreshLayout.isRefreshing = false
            if (res.isSuccessful) {
                val tempList = res.body() as ArrayList<ExecutionInProgress>
                if (list.size > 0) {
                    list.clear()
                }
                list.addAll(tempList)
                adapter.setList(list)
            } else {
                CustomToast.showToast(res.message())
            }
            showEmptyLayout()
        }
    }

    fun showEmptyLayout() {
        if (adapter.itemCount == 0) {
            binding.llMain.visibility = View.GONE
            noDataBindin.llNoData.visibility = View.VISIBLE
        } else {
            binding.llMain.visibility = View.VISIBLE
            noDataBindin.llNoData.visibility = View.GONE
        }
    }

    override fun onRefresh() {
        getExecutionInprogress()
    }

    override fun onStopExecutionClicked(executionInProgress: ExecutionInProgress) {
        Log.d(TAG, "onStopExecutionClicked: jenkinsJobId : " + executionInProgress.jenkinsJobId)
        call_stop_execution(executionInProgress)
    }

    fun call_stop_execution(executionInProgress: ExecutionInProgress) {
        CustomDialoge.showDialog(this, Constant.PROGRESS)
        Coroutines.main {
            try {
                val params = HashMap<String?, String?>()
                params.put("jenkinsJobId", executionInProgress.jenkinsJobId.toString())
                val res = viewModel.stopJenkinJob(params)
                Log.d(TAG, "call_stop_execution: respo : " + res)
                Log.d(TAG, "call_stop_execution: respo : " + res.body())
                CustomDialoge.closeDialog(this)
                if (res.isSuccessful) {
                    CustomToast.showToast(res.body().toString())
                    call_update_stopped_job(executionInProgress)
                } else {
                    CustomToast.showToast(res.message())
                }
            } catch (e: Exception) {
                e.printStackTrace()
                CustomDialoge.closeDialog(this)
                Log.d(TAG, "onStopExecutionClicked: jenkinJobId not found")
                CustomToast.showToast("Jenkin Job Id not found")
            }
        }
    }

    fun call_update_stopped_job(executionInProgress: ExecutionInProgress) {
        CustomDialoge.showDialog(this, Constant.PROGRESS)
        Coroutines.main {
            val params = HashMap<String?, String?>()
            params.put("exeHistoryId", executionInProgress.exeHistoryId.toString())
            params.put("jobStatus", "4")
            params.put("runStatus", "4")
            params.put("isStartTime", "1")
            val res = viewModel.updatestoppedJenkinJob(params)
            Log.d(TAG, "call_update_stopped_job: respo : " + res)
            Log.d(TAG, "call_update_stopped_job: respo : " + res.body())
            CustomDialoge.closeDialog(this)
            if (res.isSuccessful) {
                CustomToast.showToast(res.body().toString())
                getExecutionInprogress()
            } else {
                CustomToast.showToast(res.message())
            }
        }
    }


}
    