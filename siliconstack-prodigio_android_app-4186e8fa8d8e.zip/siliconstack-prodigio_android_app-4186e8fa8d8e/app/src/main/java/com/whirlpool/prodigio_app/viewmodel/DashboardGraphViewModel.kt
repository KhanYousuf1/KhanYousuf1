package com.whirlpool.prodigio_app.viewmodel

import androidx.lifecycle.ViewModel
import com.whirlpool.prodigio_app.communication.response.*
import com.whirlpool.prodigio_app.repository.Repository
import retrofit2.Response

class DashboardGraphViewModel(
    val repository: Repository,
) : ViewModel() {

    suspend fun getAllProjectType(): Response<List<ProjectType>> {
        return repository.getAllProjectType()
    }

    suspend fun getAllRegionsByProject(projectTypeId: Int): Response<List<Region>> {
        return repository.getAllRegionsByProject(projectTypeId)
    }

    suspend fun getAllBrands(regionId: Int): Response<List<Brand>> {
        return repository.getAllBrands(regionId)
    }

    suspend fun getAllProductNames(
        brandId: Int,
        projectTypeId: Int,
        regionId: Int
    ): Response<List<ProductName>> {
        return repository.getAllProductNames(brandId, projectTypeId, regionId)
    }

    suspend fun getTestSuiteNameByProjectName(projectName: String): Response<List<TestSuit>> {
        return repository.getTestSuiteNameByProjectName(projectName)
    }

    suspend fun getAllPlatform(projectTypeId: Int): Response<List<Platform>> {
        return repository.getAllPlatform(projectTypeId)
    }

    suspend fun getAllUsers(): Response<List<User>> {
        return repository.getAllUsers()
    }

    suspend fun getDashboardCountsForTestExecutionTrends(
        getDashboardCountsForTestExecutionTrendsRequest: DashboardGraphs.GetDashboardCountsForTestExecutionTrendsRequest
    ): Response<List<DashboardGraphs.GetDashboardCountsForTestExecutionTrendsResponse>> {
        return repository.getDashboardCountsForTestExecutionTrends(
            getDashboardCountsForTestExecutionTrendsRequest
        )
    }

    suspend fun getDashboardCountsForTestExecutionTimeTrends(
        getDashboardCountsForTestExecutionTimeTrendsRequest: DashboardGraphs.GetDashboardCountsForTestExecutionTimeTrendsRequest
    ): Response<ArrayList<DashboardGraphs.GetDashboardCountsForTestExecutionTimeTrendsResponse>> {
        return repository.getDashboardCountsForTestExecutionTimeTrends(
            getDashboardCountsForTestExecutionTimeTrendsRequest
        )
    }

    suspend fun getDashboardSuiteCountTrendRequest(
        getDashboardSuiteCountTrendRequest: DashboardGraphs.GetDashboardSuiteCountTrendRequest
    ): Response<DashboardGraphs.GetDashboardSuiteCountTrendResponse> {
        return repository.getDashboardSuiteCountTrend(
            getDashboardSuiteCountTrendRequest
        )
    }

    suspend fun getDashboardSuiteMonthlyExeStatus(
        getDashboardSuiteCountTrendRequest: DashboardGraphs.GetDashboardSuiteMonthlyExeStatusRequest
    ): Response<DashboardGraphs.GetDashboardSuiteMonthlyExeStatusResponse> {
        return repository.getDashboardSuiteMonthlyExeStatus(
            getDashboardSuiteCountTrendRequest
        )
    }
 suspend fun getDashboardSuiteExeTimeProjectWise(
        getDashboardSuiteCountTrendRequest: DashboardGraphs.GetDashboardSuiteExeTimeProjectWiseRequest
    ): Response<ArrayList<DashboardGraphs.GetDashboardSuiteExeTimeProjectWiseResponse>> {
        return repository.getDashboardSuiteExeTimeProjectWise(
            getDashboardSuiteCountTrendRequest
        )
    }


}