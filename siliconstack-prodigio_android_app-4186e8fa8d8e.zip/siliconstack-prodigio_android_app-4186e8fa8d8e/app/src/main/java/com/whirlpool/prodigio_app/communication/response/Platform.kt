package com.whirlpool.prodigio_app.communication.response

data class Platform(
    var platformId: Int,
    var platformName: String
)