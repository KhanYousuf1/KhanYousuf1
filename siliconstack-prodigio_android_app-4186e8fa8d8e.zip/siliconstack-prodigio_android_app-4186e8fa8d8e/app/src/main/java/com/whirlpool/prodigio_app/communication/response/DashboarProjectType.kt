package com.whirlpool.prodigio_app.communication.response

data class DashboarProjectType(
    val projectType: String,
    val regionView: List<RegionView>
)

data class RegionView(
    val brandView: List<BrandView>,
    val regionName: String
)

data class BrandView(
    val brandName: String,
    val caseCount: Int,
    val projectCount: Int,
    val stepCount: Int,
    val suiteCount: Int
)