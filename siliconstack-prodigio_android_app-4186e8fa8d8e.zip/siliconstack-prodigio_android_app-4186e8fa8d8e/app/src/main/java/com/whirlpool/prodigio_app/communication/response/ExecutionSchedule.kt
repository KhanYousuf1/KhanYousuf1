package com.whirlpool.prodigio_app.communication.response

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize
import kotlinx.android.parcel.RawValue
import java.io.Serializable


data class ExecutionSchedule(
    val count: Int,
    val listOfRecords: List<OfRecordsSchedule>,
    val totalCount: Int
)

data class OfRecordsSchedule(
    val active: Boolean,
    val brand: String,
    val createdOn: String,
    val dateOfMonth: Int,
    val daysOfWeek: String,
    val dbTimeZone: String,
    val endDate: String,
    val exeHeaderId: Int,
    val exeHistoryId: Int,
    val executionMode: String,
    val frequency: Int,
    val jenkinsJobId: @RawValue Any,
    val jobArn: @RawValue Any,
    val jobName: String,
    val jobStatus: Int,
    val modifiedOn: String,
    val nextDates: List<String>,
    val nodeName: String,
    val nodeOs: String,
    val projectTypeId: Int,
    val repeatSchedule: Int,
    val runningLocation: Int,
    val startDate: String,
    val time: String,
    val updatedBy: String
) : Serializable




