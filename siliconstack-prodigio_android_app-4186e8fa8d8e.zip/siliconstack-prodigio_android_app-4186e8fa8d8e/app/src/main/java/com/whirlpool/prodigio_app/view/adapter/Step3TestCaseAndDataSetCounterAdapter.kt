package com.whirlpool.prodigio_app.view.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.whirlpool.prodigio_app.AppApplication
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.databinding.ItemStep3DataSetAndTestCasesBinding
import com.whirlpool.prodigio_app.databinding.ItemStep3DatasetAndTestcaseTopCounterBinding

class Step3TestCaseAndDataSetCounterAdapter(
    var items: ArrayList<String>
) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TAG = "Step3TestCaseAdapter"
    }

    var selectedPos = 0


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = DataBindingUtil.inflate<ItemStep3DatasetAndTestcaseTopCounterBinding>(
            LayoutInflater.from(parent.context), R.layout.item_step_3_dataset_and_testcase_top_counter,
            parent, false
        )
        return ItemHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val viewHolder = holder as ItemHolder
        var item = items.get(position)
        viewHolder.binding.tvCounter.setText(item)
        if(selectedPos == position){
            viewHolder.binding.cvMain.setCardBackgroundColor(ContextCompat.getColor(AppApplication.appContext,R.color.colorPrimary))
            viewHolder.binding.tvCounter.setTextColor(ContextCompat.getColor(AppApplication.appContext,R.color.white))
        }else {
            viewHolder.binding.cvMain.setCardBackgroundColor(ContextCompat.getColor(AppApplication.appContext,R.color.white))
            viewHolder.binding.tvCounter.setTextColor(ContextCompat.getColor(AppApplication.appContext,R.color.colorPrimary))
        }
        viewHolder.binding.cvMain.setOnClickListener {
            selectedPos =  position
            notifyDataSetChanged()
        }

    }

    override fun getItemCount(): Int {
        return items.count()
    }

    inner class ItemHolder(val binding: ItemStep3DatasetAndTestcaseTopCounterBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }


}