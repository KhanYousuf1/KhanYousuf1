package com.whirlpool.prodigio_app.bottomClickInterface;

public interface BottomAppBarClickListner {

    void    onBottomAppBarClicked(int type);

}
