package com.whirlpool.prodigio_app.utils

import android.widget.Toast
import com.whirlpool.prodigio_app.AppApplication

class CustomToast {

    companion object {
        fun showToast(message: String) {
            Toast.makeText(AppApplication.getInstance(), message, Toast.LENGTH_SHORT).show()
        }

    }
}