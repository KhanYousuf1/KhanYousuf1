package com.whirlpool.prodigio_app.view.adapter

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.databinding.ItemExecutionInProgressBinding
import com.whirlpool.prodigio_app.utils.CustomIntent
import com.whirlpool.prodigio_app.view.ScrExecutionInProgress
import com.whirlpool.prodigio_app.view.ScrExecutionInProgressSub
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.card.MaterialCardView
import com.whirlpool.prodigio_app.communication.response.*
import com.whirlpool.prodigio_app.databinding.ItemInprogressScheduleDetailsBinding
import com.whirlpool.prodigio_app.databinding.ItemInprogressScheduleDetailsDevicesBinding
import com.whirlpool.prodigio_app.databinding.ItemInprogressScheduleDetailsDevicesCasesBinding


class ExecutionInProgressScheduleDetailsDevicesCasesAdapter(var context: ScrExecutionInProgressSub) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var items: ArrayList<Case> = ArrayList<Case>()


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = DataBindingUtil.inflate<ItemInprogressScheduleDetailsDevicesCasesBinding>(
            LayoutInflater.from(parent.context), R.layout.item_inprogress_schedule_details_devices_cases,
            parent, false
        )
        return ItemHolder(binding)
    }

    fun setList(items: ArrayList<Case>) {
        this.items = items
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val execution = items[position]
        val viewHolder = holder as ExecutionInProgressScheduleDetailsDevicesCasesAdapter.ItemHolder
        viewHolder.binding.tvTestCaseName.text = execution.testCaseName


    }


    override fun getItemCount(): Int {
        return items.count()
    }

    inner class ItemHolder(val binding: ItemInprogressScheduleDetailsDevicesCasesBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }

}