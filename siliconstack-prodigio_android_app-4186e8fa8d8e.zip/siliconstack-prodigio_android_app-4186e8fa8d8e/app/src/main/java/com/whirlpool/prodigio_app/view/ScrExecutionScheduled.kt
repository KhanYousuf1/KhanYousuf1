package com.whirlpool.prodigio_app.view

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.Constant
import com.whirlpool.prodigio_app.communication.response.OfRecordsSchedule
import com.whirlpool.prodigio_app.databinding.ActivityScrExecutionScheduledBinding
import com.whirlpool.prodigio_app.databinding.LayoutNoDataBinding
import com.whirlpool.prodigio_app.databinding.LayoutToolbarNewBinding
import com.whirlpool.prodigio_app.pagination.PaginationScrollListener
import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.utils.CustomDialoge
import com.whirlpool.prodigio_app.utils.CustomToast
import com.whirlpool.prodigio_app.view.adapter.ExecutionScheduledAdapter
import com.whirlpool.prodigio_app.view.adapter.ExecutionScheduledSearchAdapter
import com.whirlpool.prodigio_app.view.dialoges.DlgDeleteJob
import com.whirlpool.prodigio_app.view.dialoges.DlgDropDownProjectType
import com.whirlpool.prodigio_app.view.dialoges.DlgJobDeletedSuccessfully
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModel
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModelFactory
import org.json.JSONObject
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance

class ScrExecutionScheduled : AppCompatActivity(), KodeinAware,
    SwipeRefreshLayout.OnRefreshListener, ExecutionScheduledAdapter.onScheduledItemClickListner,
    DlgDeleteJob.BottomSheetDeleteListener {

    private val TAG = ScrExecutionScheduled::class.java.name

    override val kodein by kodein()

    lateinit var binding: ActivityScrExecutionScheduledBinding
    lateinit var toolbarbinding: LayoutToolbarNewBinding
    lateinit var noDataBindin: LayoutNoDataBinding
    lateinit var viewModel: ExecutionViewModel

    lateinit var adapter: ExecutionScheduledAdapter
    lateinit var searchAdapter: ExecutionScheduledSearchAdapter

    lateinit var ofRecordsSchedule: OfRecordsSchedule
    var position: Int = 0

    //for pagination setup
    private val PAGE_START = 0

    private var isLoading = false
    private var isLastPage = false
    private val TOTAL_PAGES = 5
    private var currentPage = PAGE_START

    var searchBy: String = ""

    //bottomSheetDialoge
    lateinit var bottomDlgDeleteJob: DlgDeleteJob
    lateinit var bottomDlgJobDeletedSuccessfully: DlgJobDeletedSuccessfully


    companion object {
        var data = MutableLiveData<Boolean>()
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = resources.getColor(R.color.white)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            window.statusBarColor = Color.WHITE
        }
        val factory: ExecutionViewModelFactory by instance() // dependency injection
        viewModel = ViewModelProvider(this, factory).get(ExecutionViewModel::class.java)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_scr_execution_scheduled)
        initUI()
        setUpToolBar()
        registerClicks()

    }


    fun initUI() {
        //init bottom sheet
        bottomDlgDeleteJob = DlgDeleteJob()
        bottomDlgDeleteJob.mListner = this

        bottomDlgJobDeletedSuccessfully = DlgJobDeletedSuccessfully()

        // init recyclerview
        val layoutManager =
            LinearLayoutManager(this@ScrExecutionScheduled, RecyclerView.VERTICAL, false)
        adapter =
            ExecutionScheduledAdapter(
                this@ScrExecutionScheduled,
            )
        binding.rvHistory.layoutManager = layoutManager
        binding.rvHistory.adapter = adapter

        searchAdapter = ExecutionScheduledSearchAdapter(this)

        binding.rvHistory.addOnScrollListener(object :
            PaginationScrollListener(layoutManager) {
            override fun loadMoreItems() {
                isLoading = true
                currentPage += 1
                Log.d(TAG, "loadMoreItems: isLoading : $isLoading  current page: $currentPage")
                getScheduledJobsNextPage(currentPage)

            }

            override fun getTotalPageCount(): Int {
                return TOTAL_PAGES
            }

            override fun isLastPage(): Boolean {
                return isLastPage
            }

            override fun isLoading(): Boolean {
                return isLoading
            }

        })

        //inti no data layout
        noDataBindin = binding.llNoData

        binding.swipeRefreshLayout.setOnRefreshListener(this)
        binding.swipeRefreshLayout.setColorSchemeColors(
            ContextCompat.getColor(this, R.color.execution_all_jobs),
            ContextCompat.getColor(this, R.color.execution_history),
            ContextCompat.getColor(this, R.color.execution_in_progress),
            ContextCompat.getColor(this, R.color.execution_scheduled)
        )
    }

    fun registerClicks() {
    }

    @SuppressLint("SetTextI18n")
    fun setUpToolBar() {
        //init toolbar
        toolbarbinding = binding.llToolBar
        toolbarbinding.tvToolBarHeader.text = "Schedule"

        toolbarbinding.llBack.setOnClickListener { finish() }
        toolbarbinding.llSearch.setOnClickListener {
            toolbarbinding.llSearchContainer.visibility = View.VISIBLE
            toolbarbinding.llHeaderMain.visibility = View.GONE
        }
        toolbarbinding.llClose.setOnClickListener {
            if (toolbarbinding.etSearch.text.toString().isNullOrBlank()) {
                toolbarbinding.llSearchContainer.visibility = View.GONE
                toolbarbinding.llHeaderMain.visibility = View.VISIBLE
                searchBy = ""
            } else {
                toolbarbinding.etSearch.text = null
                binding.rvHistory.adapter = adapter
                getScheduledJobsFirstPage()
            }
        }

        toolbarbinding.etSearch.setOnEditorActionListener(TextView.OnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                val text = toolbarbinding.etSearch.text.toString()
                if (!text.isEmpty()) {
                    Log.d(TAG, "setUpToolBar: text : $text")
                    getScheduledJobsBySearch(text)
                } else {
                    CustomToast.showToast("Please enter something to search")
                }
                return@OnEditorActionListener true
            }
            false
        })

    }

    fun getScheduledJobsFirstPage() {
        Coroutines.main {
            binding.swipeRefreshLayout.isRefreshing = true
            val res = viewModel.getScheduledJOb(PAGE_START, searchBy)
            Log.d(TAG, "getScheduledJobs: respo : " + res)
            Log.d(TAG, "getScheduledJobs: respo : " + res.body()?.listOfRecords)
            binding.swipeRefreshLayout.isRefreshing = false
            if (res.isSuccessful) {
                val list: ArrayList<OfRecordsSchedule> =
                    res.body()?.listOfRecords as ArrayList<OfRecordsSchedule>
                if (adapter.items.count() > 0) {

                } else {
                    adapter.setList(list)
                }
                if (currentPage <= TOTAL_PAGES) adapter.addLoadingFooter() else isLastPage =
                    true
            } else {
                CustomToast.showToast(res.message().toString())
            }
        }
    }

    fun getScheduledJobsNextPage(pageNo: Int) {
        Coroutines.main {
            val res = viewModel.getScheduledJOb(pageNo, searchBy)
            Log.d(TAG, "getScheduledJobs: respo : " + res)
            Log.d(TAG, "getScheduledJobs: respo : " + res.body()?.listOfRecords)
            if (res.isSuccessful) {
                adapter.removeLoadingFooter()
                isLoading = false
                val list: ArrayList<OfRecordsSchedule> =
                    res.body()?.listOfRecords as ArrayList<OfRecordsSchedule>
                adapter.addAll(list)
                if (currentPage != TOTAL_PAGES) adapter.addLoadingFooter() else isLastPage = true
            } else {
                CustomToast.showToast(res.message().toString())
            }
        }
    }


    override fun onResume() {
        data.observe(this, Observer {
            if (it) {
                data.value = false
                getScheduledJobsFirstPage()
            }
        })
        super.onResume()
    }

    override fun onRefresh() {
        getScheduledJobsFirstPage()
    }

    override fun onItemScheduledItemCliked(ofRecordsSchedule: OfRecordsSchedule, position: Int) {
        Log.d(TAG, "onItemScheduledItemCliked: exe_header_id = ${ofRecordsSchedule.exeHeaderId}")
        this.ofRecordsSchedule = ofRecordsSchedule
        this.position = position
        bottomDlgDeleteJob.show(supportFragmentManager, TAG)

    }

    override fun onDeleteJobButtonClicked(type: Int) {
        deleteSchedule()
    }

    fun deleteSchedule() {
        Coroutines.main {
            CustomDialoge.showDialog(this, Constant.PROGRESS)
            val res = viewModel.deleteScheduledJOb(ofRecordsSchedule.exeHeaderId)
            Log.d(TAG, "deleteSchedule: res ${res}")
            Log.d(TAG, "deleteSchedule: res body ${res.body()}")
            CustomDialoge.closeDialog(this)
            if (res.isSuccessful) {
                val res = JSONObject(res.body())
                val status = res.getInt("Status")
                if (status == 1) {
                    bottomDlgDeleteJob.dismiss()
                    adapter.removeItemByPosition(position)
                    bottomDlgJobDeletedSuccessfully.show(supportFragmentManager, TAG)
                } else {
                    CustomToast.showToast(Constant.WENT_WRONG)
                }
            } else {
                CustomToast.showToast(res.message())
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    fun getScheduledJobsBySearch(searched_text: String) {
        Coroutines.main {
            CustomDialoge.showDialog(this, Constant.SEARCHING)
            val res = viewModel.getScheduledJOb(PAGE_START, searched_text)
            Log.d(TAG, "getScheduledJobsBySearch: respo : " + res)
            Log.d(TAG, "getScheduledJobsBySearch: respo : " + res.body()?.listOfRecords)
            CustomDialoge.closeDialog(this)
            if (res.isSuccessful) {

                if (res.body()?.count!! > 0) {
                    currentPage = 0
                    val list: ArrayList<OfRecordsSchedule> =
                        res.body()?.listOfRecords as ArrayList<OfRecordsSchedule>
                    binding.rvHistory.adapter = searchAdapter
                    searchAdapter.setList(list)
                } else {
                    CustomToast.showToast("Record Not Found")
                }
            } else {
                CustomToast.showToast(res.message().toString())
            }
        }
    }

}