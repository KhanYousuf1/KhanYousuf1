package com.whirlpool.prodigio_app

import android.app.Application
import android.content.Context
import com.whirlpool.prodigio_app.repository.Repository
import com.whirlpool.prodigio_app.communication.ApiInterface
import com.whirlpool.prodigio_app.communication.NetworkConnectionInterceptor
import com.whirlpool.prodigio_app.viewmodel.*
import org.kodein.di.Kodein
import org.kodein.di.KodeinAware
import org.kodein.di.android.x.androidXModule
import org.kodein.di.generic.bind
import org.kodein.di.generic.instance
import org.kodein.di.generic.singleton
import java.util.Collections.singleton

class AppApplication : Application(), KodeinAware {

    companion object {
        lateinit var appContext: Context
        lateinit var mInstance: AppApplication

        fun getInstance(): AppApplication {
            return mInstance
        }
    }

    override fun onCreate() {
        super.onCreate()
        mInstance = this
        appContext = this
    }

    override val kodein: Kodein = Kodein.lazy {
        import(androidXModule(this@AppApplication))

        bind() from singleton { NetworkConnectionInterceptor(instance()) }
        bind() from singleton { ApiInterface(instance()) }

        bind() from singleton { Repository(instance()) }

        bind() from singleton { LoginViewModelFactory(instance()) }
        bind() from singleton { ExecutionViewModelFactory(instance()) }
        bind() from singleton { EditExecutionNameViewModelFactory(instance()) }
        bind() from singleton { TestSuiteExecutionStatusViewModelFactory(instance()) }
        bind() from singleton { TestSuitePassViewModelFactory(instance()) }
        bind() from singleton { TestSuitExecutionViewModelFactory(instance()) }
        bind() from singleton { MonthlyExecutionStatusViewModelFactory(instance()) }
        bind() from singleton { ProjectExecutionTimeStatusViewModelFactory(instance()) }
        bind() from singleton { TestSuiteExecutionTimeTrendViewModelFactory(instance()) }
        bind() from singleton { DashboardGraphViewModelFactory(instance()) }
        bind() from singleton { DashBoardViewModelFactory(instance()) }
        bind() from singleton { RunJobViewModelFactory(instance()) }

    }

}