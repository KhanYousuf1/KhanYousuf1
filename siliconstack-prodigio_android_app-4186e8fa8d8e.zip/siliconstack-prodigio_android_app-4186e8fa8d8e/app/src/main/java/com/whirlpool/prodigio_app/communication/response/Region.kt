package com.whirlpool.prodigio_app.communication.response

data class Region(
    var regionId: Int,
    var regionCode: String,
    var regionName: String,
    var regionDesc: String,
    var userId: Int,
    var defaultRegion: Boolean
)

