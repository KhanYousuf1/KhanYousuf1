package com.whirlpool.prodigio_app.communication.response

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize
import kotlinx.android.parcel.RawValue


data class ExecutionHistory(
    val count: Int,
    val listOfRecords: List<OfRecords>,
    val totalCount: Int
)

@Parcelize
data class OfRecords(
    @SerializedName("canJenkinsLogFileDownload")
    val canJenkinsLogFileDownload: Boolean,
    @SerializedName("createdBy")
    val createdBy: String,
    @SerializedName("devicepoolArn")
    val devicepoolArn: String,
    @SerializedName("endDate")
    val endDate: String,
    @SerializedName("endTime")
    val endTime: String,
    @SerializedName("exeHeaderId")
    val exeHeaderId: Int,
    @SerializedName("exeHistoryId")
    val exeHistoryId: Int,
    @SerializedName("executionMode")
    val executionMode: String,
    @SerializedName("failCount")
    val failCount: Int,
    @SerializedName("jenkinsJobId")
    val jenkinsJobId: @RawValue Any,
    @SerializedName("jenkinsLogFilePath")
    val jenkinsLogFilePath: @RawValue Any,
    @SerializedName("jobArn")
    val jobArn: String,
    @SerializedName("jobName")
    val jobName: String,
    @SerializedName("jobStatus")
    val jobStatus: Int,
    @SerializedName("language")
    val language: @RawValue Any,
    @SerializedName("modifiedBy")
    val modifiedBy: @RawValue Any,
    @SerializedName("nodeName")
    val nodeName: String,
    @SerializedName("nodeOs")
    val nodeOs: String,
    @SerializedName("passCount")
    val passCount: Int,
    @SerializedName("platform")
    val platform: String,
    @SerializedName("reportPathUrl")
    val reportPathUrl: @RawValue Any,
    @SerializedName("runStatus")
    val runStatus: Int,
    @SerializedName("startDate")
    val startDate: String,
    @SerializedName("startTime")
    val startTime: String,
    @SerializedName("templateCount")
    val templateCount: Int
) : Parcelable




