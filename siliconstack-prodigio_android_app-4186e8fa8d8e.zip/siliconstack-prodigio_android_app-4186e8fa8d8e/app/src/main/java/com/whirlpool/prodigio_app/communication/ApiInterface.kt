package com.whirlpool.prodigio_app.communication

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.whirlpool.prodigio_app.communication.response.*
import okhttp3.ResponseBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit
import kotlin.collections.HashMap
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException


interface ApiInterface {

    //login
    @POST("Token-Generator")
    suspend fun login(
        @HeaderMap map: HashMap<String, String>,
        @Body params: HashMap<String?, String?>
    ): Response<Login>

    @GET("execution/getJobHistory")
    suspend fun executionHistory(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<ExecutionHistory>

    @DELETE("execution/deleteHistoryById")//exeHeaderId
    suspend fun deleteHistoryById(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<String>

    @GET("execution/checkForDuplicate")
    suspend fun checkForDuplicateForExecutionHistoryName(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<String>

    //update job name from execution history
    @POST("execution/changeTestExecutionName")
    suspend fun changeTestExecutionName(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<String>

    //re-execute hob from execution history
    @GET("execution/reExecuteJob")
    suspend fun reExecuteJob(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<String>

    @GET("execution/getHistoryDetails")
    suspend fun executionHistorySub(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<List<ExecutionHistorySubItem>>

    @GET("execution/getExecutionCount")
    suspend fun getExecutionCount(
        @Header("Authorization") token: String
    ): Response<ExecutionDashboardCount>

    @GET("execution/getExtendedReportList")
    suspend fun getExtendedReportList(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<List<ExtentReportList>>

    @GET("execution/downloadAppiumLogFile")
    suspend fun downloadAppiumLogFile(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<String>

    @GET("execution/downloadExecutionFiles")
    suspend fun downloadExecutionFiles(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<String>

    @GET("execution/getJenkinsBuildLog")
    suspend fun downloadExecutionLogFiles(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<String>


    @GET("execution/downloadExtendReportFile")
    suspend fun downloadExtendReportFile(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<String>

    @GET("masterData/getAllProjectType")
    suspend fun getAllProjectType(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<List<ProjectType>>

    @GET("masterData/getRegionByProjectType")
    suspend fun getAllRegionsByProject(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, Int?>
    ): Response<List<Region>>


    @GET("masterData/getAllBrand")
    suspend fun getAllBrands(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, Int?>
    ): Response<List<Brand>>


    @GET("testCaseManagement/getProjectName")
    suspend fun getAllProductNames(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, Int?>
    ): Response<List<ProductName>>


    @GET("testCaseManagement/getTestSuiteNameByProjectName")
    suspend fun getTestSuiteNameByProjectName(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<List<TestSuit>>


    @GET("frameworkManagement/getAllPlatform")
    suspend fun getAllPlatform(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, Int?>
    ): Response<List<Platform>>

    @GET("userManagement/getAllUsers")
    suspend fun getAllUser(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<List<User>>

    @GET("execution/getScheduleList")
    suspend fun getScheduleList(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<ExecutionSchedule>

    @DELETE("execution/deleteSchedule")//exeHeaderId
    suspend fun deleteSchedule(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<String>

    @POST("execution/updateSchedule")//exeHeaderId
    suspend fun updateSchedule(
        @Header("Authorization") token: String,
        @Body params: HashMap<String?, String?>
    ): Response<String>

    @GET("execution/getRunningJobs")
    suspend fun getRunningJobs(
        @Header("Authorization") token: String
    ): Response<List<ExecutionInProgress>>


    @GET("dashBoard/getDashboardCounts")
    suspend fun getDashboardCounts(
        @Header("Authorization") token: String
    ): Response<List<DashboarProjectType>>

    //get All document
    @GET("masterData/getAllDocument")
    suspend fun getAllDocument(
        @Header("Authorization") token: String
    ): Response<List<Document>>


    // Dashboard


    //  getDashboardCountsForTestExecutionTimeTrends
    @POST("execution/getDashboardCountsForTestExecutionTimeTrends")
    suspend fun getDashboardCountsForTestExecutionTimeTrends(
        @Header("Authorization") token: String,
        @Body params: DashboardGraphs.GetDashboardCountsForTestExecutionTimeTrendsRequest
    ): Response<ArrayList<DashboardGraphs.GetDashboardCountsForTestExecutionTimeTrendsResponse>>


    //  getDashboardCountsForTestExecutionTrends
    @POST("execution/getDashboardCountsForTestExecutionTrends")
    suspend fun getDashboardCountsForTestExecutionTrends(
        @Header("Authorization") token: String,
        @Body params: DashboardGraphs.GetDashboardCountsForTestExecutionTrendsRequest
    ): Response<List<DashboardGraphs.GetDashboardCountsForTestExecutionTrendsResponse>>


    //  getDashboardSuiteCountTrend
    @POST("dashBoard/getDashboardSuiteCountTrend")
    suspend fun getDashboardSuiteCountTrend(
        @Header("Authorization") token: String,
        @Body params: DashboardGraphs.GetDashboardSuiteCountTrendRequest
    ): Response<DashboardGraphs.GetDashboardSuiteCountTrendResponse>


    //  getDashboardSuiteExeTimeProjectWise
    @POST("dashBoard/getDashboardSuiteExeTimeProjectWise")
    suspend fun getDashboardSuiteExeTimeProjectWise(
        @Header("Authorization") token: String,
        @Body params: DashboardGraphs.GetDashboardSuiteExeTimeProjectWiseRequest
    ): Response<ArrayList<DashboardGraphs.GetDashboardSuiteExeTimeProjectWiseResponse>>


    //  getDashboardSuiteMonthlyExeStatus
    @POST("dashBoard/getDashboardSuiteMonthlyExeStatus")
    suspend fun getDashboardSuiteMonthlyExeStatus(
        @Header("Authorization") token: String,
        @Body params: DashboardGraphs.GetDashboardSuiteMonthlyExeStatusRequest
    ): Response<DashboardGraphs.GetDashboardSuiteMonthlyExeStatusResponse>

    //  stopJenkinJob
    @POST("execution/stopJenkinJob")
    suspend fun stopJenkinJob(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<String>

    //  updatestoppedJenkinJob
    @POST("execution/updateHistoryStatus")
    suspend fun updatestoppedJenkinJob(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<String>

    //  getScheduleListDeatils
    @GET("execution/getScheduleListDeatils")
    suspend fun getScheduleListDeatils(
        @Header("Authorization") token: String,
        @QueryMap params: HashMap<String?, String?>
    ): Response<List<ScheduleDetails>>

    /*//  getDashboardCountsForTestExecutionTimeTrends
    @POST("/dashboard/getDashboardCountsForTestExecutionTimeTrends")
    suspend fun getDashboardCountsForTestExecutionTimeTrends(
        @HeaderMap map: HashMap<String, String>,
        @Body params: HashMap<String?, String?>
    ): Response<String>*/

    companion object {
        operator fun invoke(networkConnectionInterceptor: NetworkConnectionInterceptor): ApiInterface {


            val URL = "https://6kd2ewh4cb.execute-api.us-east-1.amazonaws.com/dev/"

            val interceptor: Interceptor = object : Interceptor {
                @Throws(IOException::class)
                override fun intercept(chain: Interceptor.Chain): okhttp3.Response {
                    var request: Request = chain.request()
                    val builder: Request.Builder =
                        request.newBuilder().addHeader("Cache-Control", "no-cache")
                    request = builder.build()
                    return chain.proceed(request)
                }
            }
            val okHttp: OkHttpClient.Builder = OkHttpClient.Builder()
                .retryOnConnectionFailure(true)
                .callTimeout(120, TimeUnit.SECONDS)
                .connectTimeout(120, TimeUnit.SECONDS)
                .readTimeout(120, TimeUnit.SECONDS)
                .writeTimeout(120, TimeUnit.SECONDS)
               // .addInterceptor(interceptor)
            // .addInterceptor(networkConnectionInterceptor)

            /*  .addInterceptor(
                  HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BASIC).setLevel
                      (HttpLoggingInterceptor.Level.BODY)
                      .setLevel(HttpLoggingInterceptor.Level.HEADERS)
              )*/


            val gson: Gson = GsonBuilder().setLenient().create()
            return Retrofit.Builder()
                .baseUrl(URL)
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create(gson))
                .client(okHttp.build())
                .build()
                .create(ApiInterface::class.java)
        }
    }
}