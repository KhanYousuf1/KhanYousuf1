package com.whirlpool.prodigio_app.view.dialoges

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CalendarView
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.deishelon.roundedbottomsheet.RoundedBottomSheetDialogFragment
import com.whirlpool.prodigio_app.AppApplication
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.ProjectType
import com.whirlpool.prodigio_app.databinding.DlgCalendarBinding
import com.whirlpool.prodigio_app.databinding.DlgDropDownProjectTypeBinding
import com.whirlpool.prodigio_app.view.adapter.DropDownProjectTypeAdapter
import org.kodein.di.Kodein
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import java.text.SimpleDateFormat
import java.util.*

class DlgFromDate(
    var mListner: BottomSheetDlgFromDateListner,var calendarMax: Calendar?=null,var calendarMin: Calendar?=null
) : RoundedBottomSheetDialogFragment() {

    lateinit var binding: DlgCalendarBinding
    lateinit var cale : CalendarView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding =
            DataBindingUtil.inflate(inflater, R.layout.dlg_calendar, container, false)
        val rootView = binding.root
        cale = binding.calender
        init()
        reisterClicks()
        return rootView
    }


    fun init() {
        if (calendarMax!=null){
            binding.calender.maxDate = calendarMax!!.time.time
        }
        if (calendarMin!=null){
            binding.calender.minDate = calendarMin!!.time.time
        }
        binding.calender.setOnDateChangeListener { view, year, month, dayOfMonth ->
            // Note that months are indexed from 0. So, 0 means January, 1 means february, 2 means march etc.
            val msg = "Selected date is " + dayOfMonth + "/" + (month + 1) + "/" + year

            var calendarSelected = Calendar.getInstance()
            calendarSelected.set(Calendar.YEAR,year)
            calendarSelected.set(Calendar.MONTH,month)
            calendarSelected.set(Calendar.DAY_OF_MONTH,dayOfMonth)
            Log.d(TAG, "init: Date - ${msg}")
            Log.d(TAG, "init: Selected Date - ${SimpleDateFormat("dd-MM-yyyy").format(calendarSelected.time)}")
            mListner.onFromDateSelected("${SimpleDateFormat("dd-MM-yyyy").format(calendarSelected.time)}",calendarSelected)
            dismiss()
        }
    }

    fun setMaxDate(maxDate: Long) {
        cale.maxDate = maxDate
    }

    fun setMinDate(minDate: Long) {
        Handler(Looper.getMainLooper()).postDelayed({
            binding.calender.minDate = minDate
        }, 500)
    }


    private fun reisterClicks() {

    }


    interface BottomSheetDlgFromDateListner {
        fun onFromDateSelected(date: String,calendar: Calendar)
    }

    companion object {
        private const val TAG = "DlgFromDate"
    }


}