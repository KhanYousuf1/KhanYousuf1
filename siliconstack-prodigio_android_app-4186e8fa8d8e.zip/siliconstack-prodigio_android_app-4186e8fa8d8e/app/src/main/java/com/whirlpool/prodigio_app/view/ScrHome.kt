package com.whirlpool.prodigio_app.view

import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.transition.Visibility
import android.util.Log
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.view.marginTop
import androidx.core.widget.doAfterTextChanged
import androidx.databinding.DataBindingUtil
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.R.drawable
import com.whirlpool.prodigio_app.bottomClickInterface.BottomAppBarClickListner
import com.whirlpool.prodigio_app.communication.Constant
import com.whirlpool.prodigio_app.databinding.ActivityScrHomeBinding
import com.whirlpool.prodigio_app.databinding.BottomNavigationViewBinding
import com.whirlpool.prodigio_app.storage.UserData
import com.whirlpool.prodigio_app.utils.CustomIntent
import com.whirlpool.prodigio_app.view.dialoges.DlgLogout
import com.whirlpool.prodigio_app.view.fragments.FrgDocument
import com.whirlpool.prodigio_app.view.fragments.FrgExecution
import com.whirlpool.prodigio_app.view.fragments.FrgHome

class ScrHome : AppCompatActivity(), BottomAppBarClickListner, View.OnClickListener,
    DlgLogout.BottomSheetLogoutListener {

    val TAG: String = ScrHome::class.java.name

    var binding: ActivityScrHomeBinding? = null
    var bottomNavigationbinding: BottomNavigationViewBinding? = null


    //bottom sheet for logout
    lateinit var bottomSheetLogout: DlgLogout

    //bottom menu
    private var bottomAppBarClickListner: BottomAppBarClickListner? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = resources.getColor(R.color.white)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            window.statusBarColor = Color.WHITE
        }
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_scr_home)
        bottomNavigationbinding = binding?.bottomNavigationMenu
        initUI()
        registerClicks()
        init_BottomNavClickListner()
    }

    override fun onResume() {
        super.onResume()
        val userData = UserData.getInstance()
        Log.d(TAG, "onResume: userData token : " + userData?.getTOKEN())
    }

    fun init_BottomNavClickListner() {
        bottomAppBarClickListner = this
        bottomAppBarClickListner?.onBottomAppBarClicked(Constant.HOME)
    }

    fun initUI() {
        bottomSheetLogout = DlgLogout()
    }

    fun registerClicks() {
        //bottom click handle
        bottomNavigationbinding!!.llDashboard.setOnClickListener(this)
        bottomNavigationbinding!!.llExecution.setOnClickListener(this)
        bottomNavigationbinding!!.llDocument.setOnClickListener(this)

    }

    override fun onBottomAppBarClicked(type: Int) {
        Log.d(TAG, "onBottomAppBarClicked: type : $type")
        when (type) {
            Constant.HOME -> {
                initDashBoard()
            }
            Constant.EXECUTION -> {
                initExecution()
            }
            Constant.DOCUMET -> {
                initDocument()
            }
            Constant.RUN_JOB -> {
                initRunJob()
            }
        }
    }

    override fun onClick(v: View?) {
        when (v!!.id) {
            R.id.ll_dashboard -> bottomAppBarClickListner!!.onBottomAppBarClicked(Constant.HOME)
            R.id.ll_execution -> bottomAppBarClickListner!!.onBottomAppBarClicked(Constant.EXECUTION)
            R.id.ll_document -> bottomAppBarClickListner!!.onBottomAppBarClicked(Constant.DOCUMET)
        }
    }


    fun initDashBoard() {
        supportFragmentManager.beginTransaction().replace(R.id.fl_container, FrgHome())
            .commit() // launching a home fragment


        bottomNavigationbinding!!.ivDashboard.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                drawable.ic_menu_dashboard_selected
            )
        )
        bottomNavigationbinding!!.ivExecution.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                drawable.ic_menu_execution_non_selected
            )
        )
        bottomNavigationbinding!!.ivDocument.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                drawable.ic_menu_document_non_selected
            )
        )
        bottomNavigationbinding!!.ivRunJob.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                drawable.ic_menu_run_job_non_selected
            )
        )

        bottomNavigationbinding!!.tvDashboad.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.white
            )
        )
        bottomNavigationbinding!!.tvExecution.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.text_black4
            )
        )
        bottomNavigationbinding!!.tvDocument.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.text_black4
            )
        )
        bottomNavigationbinding!!.tvRunJob.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.text_black4
            )
        )

    }

    fun initExecution() {
        supportFragmentManager.beginTransaction().replace(R.id.fl_container, FrgExecution())
            .commit()


        bottomNavigationbinding!!.ivDashboard.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                drawable.ic_menu_dashboard_non_selected
            )
        )
        bottomNavigationbinding!!.ivExecution.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                drawable.ic_menu_execution_selected
            )
        )
        bottomNavigationbinding!!.ivDocument.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                drawable.ic_menu_document_non_selected
            )
        )
        bottomNavigationbinding!!.ivRunJob.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                drawable.ic_menu_run_job_non_selected
            )
        )

        bottomNavigationbinding!!.tvDashboad.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.text_black4
            )
        )
        bottomNavigationbinding!!.tvExecution.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.white
            )
        )
        bottomNavigationbinding!!.tvDocument.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.text_black4
            )
        )
        bottomNavigationbinding!!.tvRunJob.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.text_black4
            )
        )
    }

    fun initDocument() {

        supportFragmentManager.beginTransaction().replace(R.id.fl_container, FrgDocument())
            .commit()


        bottomNavigationbinding!!.ivDashboard.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                drawable.ic_menu_dashboard_non_selected
            )
        )
        bottomNavigationbinding!!.ivExecution.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                drawable.ic_menu_execution_non_selected
            )
        )
        bottomNavigationbinding!!.ivDocument.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                drawable.ic_menu_document_selected
            )
        )
        bottomNavigationbinding!!.ivRunJob.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                drawable.ic_menu_run_job_non_selected
            )
        )

        bottomNavigationbinding!!.tvDashboad.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.text_black4
            )
        )
        bottomNavigationbinding!!.tvExecution.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.text_black4
            )
        )
        bottomNavigationbinding!!.tvDocument.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.white
            )
        )
        bottomNavigationbinding!!.tvRunJob.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.text_black4
            )
        )
    }


    fun initRunJob() {

        supportFragmentManager.beginTransaction().replace(R.id.fl_container, FrgDocument())
            .commit()


        bottomNavigationbinding!!.ivDashboard.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                drawable.ic_menu_dashboard_non_selected
            )
        )
        bottomNavigationbinding!!.ivExecution.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                drawable.ic_menu_execution_non_selected
            )
        )
        bottomNavigationbinding!!.ivDocument.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                drawable.ic_menu_document_non_selected
            )
        )
        bottomNavigationbinding!!.ivRunJob.setImageDrawable(
            ContextCompat.getDrawable(
                this,
                drawable.ic_menu_run_job_non_selected
            )
        )

        bottomNavigationbinding!!.tvDashboad.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.text_black4
            )
        )
        bottomNavigationbinding!!.tvExecution.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.text_black4
            )
        )
        bottomNavigationbinding!!.tvDocument.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.text_black4
            )
        )
        bottomNavigationbinding!!.tvRunJob.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.white
            )
        )
    }


    override fun onButtonClicked(type: Int) {
        if (type == 0) {
            bottomSheetLogout.dismiss()
        } else {
            CustomIntent.startActivity(this, ScrLogin::class.java)
        }
    }

}