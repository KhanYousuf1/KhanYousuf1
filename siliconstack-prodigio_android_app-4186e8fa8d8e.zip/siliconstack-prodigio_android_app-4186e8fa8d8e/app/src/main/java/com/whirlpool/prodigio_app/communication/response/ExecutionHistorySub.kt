package com.whirlpool.prodigio_app.communication.response

data class ExecutionHistorySubItem(
    val canJenkinsLogFileDownload: Boolean,
    val createdBy: Any,
    val devicepoolArn: String,
    val endDate: String,
    val endTime: String,
    val exeHeaderId: Int,
    val exeHistoryId: Int,
    val executionMode: String,
    val failCount: Int,
    val jenkinsJobId: Any,
    val jenkinsLogFilePath: Any,
    val jobArn: String,
    val jobName: String,
    val jobStatus: Int,
    val language: String,
    val modifiedBy: Any,
    val nodeName: String,
    val nodeOs: String,
    val passCount: Int,
    val platform: String,
    val reportPathUrl: Any,
    val runStatus: Int,
    val startDate: String,
    val startTime: String,
    val templateCount: Int
)