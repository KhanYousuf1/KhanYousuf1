package com.whirlpool.prodigio_app.view

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.transition.AutoTransition
import androidx.transition.TransitionManager
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.Document
import com.whirlpool.prodigio_app.communication.response.OfRecordsSchedule
import com.whirlpool.prodigio_app.databinding.ActivityScrExecutionScheduledSubBinding
import com.whirlpool.prodigio_app.databinding.LayoutToolbarNewBinding
import com.whirlpool.prodigio_app.view.adapter.ExecutionScheduledSubAdapter
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModel
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModelFactory
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance

class ScrExecutionScheduledSub : AppCompatActivity(), View.OnClickListener, KodeinAware,
    SwipeRefreshLayout.OnRefreshListener {

    private val TAG = ScrExecutionScheduledSub::class.java.name

    override val kodein by kodein()

    lateinit var binding: ActivityScrExecutionScheduledSubBinding
    lateinit var toolbarbinding: LayoutToolbarNewBinding
    lateinit var viewModel: ExecutionViewModel
    lateinit var ofRecordsSchedule: OfRecordsSchedule


    lateinit var adapter: ExecutionScheduledSubAdapter
    var list = ArrayList<OfRecordsSchedule>()
    val arr: ArrayList<String> = ArrayList()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = resources.getColor(R.color.white)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            window.statusBarColor = Color.WHITE
        }

        val factory: ExecutionViewModelFactory by instance() // dependency injection
        viewModel = ViewModelProvider(this, factory).get(ExecutionViewModel::class.java)
        binding =
            DataBindingUtil.setContentView(this, R.layout.activity_scr_execution_scheduled_sub)

        initUI()
        registerClicks()
        getIntentData()
        setUpToolBar()
    }

    fun getIntentData() {
        val intent = intent.extras
        ofRecordsSchedule = intent?.getSerializable("OfRecordsSchedule") as OfRecordsSchedule
        Log.d(
            TAG,
            "getIntentData: exeHeaderId : ${ofRecordsSchedule.exeHeaderId} exeHistoryId : ${ofRecordsSchedule.exeHistoryId} "
        )
        binding.tvBrandName.text = ofRecordsSchedule.brand
        binding.tvOs.text = ofRecordsSchedule.nodeOs
        binding.tvExecutionName.text = ofRecordsSchedule.jobName
        binding.tvCreatedDate.text = ofRecordsSchedule.createdOn
        binding.tvCreatedBy.text = ofRecordsSchedule.updatedBy
        binding.tvModifiedDate.text = ofRecordsSchedule.modifiedOn
        if (ofRecordsSchedule.nextDates.size > 0) {
            binding.tvNextExecution.text = ofRecordsSchedule.nextDates[0]
        }
        binding.tvEndDate.text = ofRecordsSchedule.endDate
        binding.tvExecutionScheduled.text = "missing"
    }

    fun setUpToolBar() {
        //init toolbar
        toolbarbinding = binding.llToolBar

        toolbarbinding.llBack.setOnClickListener { finish() }

        toolbarbinding.llSearch.visibility = View.GONE

        toolbarbinding.llSearch.setOnClickListener {
            toolbarbinding.llSearchContainer.visibility = View.VISIBLE
            toolbarbinding.llHeaderMain.visibility = View.GONE
        }
        toolbarbinding.llClose.setOnClickListener {
            if (toolbarbinding.etSearch.text.toString().isNullOrBlank()) {
                toolbarbinding.llSearchContainer.visibility = View.GONE
                toolbarbinding.llHeaderMain.visibility = View.VISIBLE
            } else toolbarbinding.etSearch.text = null
        }

        toolbarbinding.tvToolBarHeader.text = ofRecordsSchedule.jobName

        toolbarbinding.etSearch.doAfterTextChanged {
            var text = it.toString()
            Log.d(TAG, "setUpToolBar: doAfterTextChanged : $text")
            filter(text)
        }

    }

    fun initUI() {


    }


    override fun onResume() {
        super.onResume()
        callApi()
    }

    fun callApi() {
        getExecutionHistorySub()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun getExecutionHistorySub() {
        val layoutManager =
            LinearLayoutManager(this@ScrExecutionScheduledSub, RecyclerView.VERTICAL, false)


        arr.addAll(ofRecordsSchedule.nextDates)
        list.add(ofRecordsSchedule)

        adapter = ExecutionScheduledSubAdapter(
            this@ScrExecutionScheduledSub,
            arr,
            ofRecordsSchedule
        )
        binding.rvScheduleSub.layoutManager = layoutManager
        binding.rvScheduleSub.adapter = adapter
        binding.rvScheduleSub.adapter?.notifyDataSetChanged()
    }


    fun registerClicks() {
        binding.llPlusMinus.setOnClickListener {
            if (binding.llHiddenView.visibility == View.GONE) {
                TransitionManager.beginDelayedTransition(
                    binding.cvMain,
                    AutoTransition()
                )
                binding.llHiddenView.visibility = View.VISIBLE
                binding.ivPlusMinus.setImageResource(R.drawable.ic_baseline_remove_24)
            } else {
                TransitionManager.beginDelayedTransition(
                    binding.cvMain,
                    AutoTransition()
                )
                binding.llHiddenView.visibility = View.GONE
                binding.ivPlusMinus.setImageResource(R.drawable.ic_baseline_add_24)
            }
        }
    }

    override fun onClick(v: View?) {

    }

    override fun onRefresh() {
        getExecutionHistorySub()
    }

    fun filter(text: String) {
        Log.d(TAG, "filter: value : $text list size : " + list.size)
        if (!text.isNullOrBlank()) {
            lateinit var arrayList: OfRecordsSchedule
            for (item: OfRecordsSchedule in list) {
                if (item.jobName.lowercase().contains(text.lowercase())) {
                    Log.d(
                        TAG,
                        "filter: search for doc name : ${item} searched Text : ${text.lowercase()}"
                    )
                    arrayList = item
                    adapter.filteredList(item)
                }
            }

        } else {
            adapter.setList(ofRecordsSchedule)
        }
    }

}