package com.whirlpool.prodigio_app.communication.response

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize
import kotlinx.android.parcel.RawValue
import java.io.Serializable

data class ExecutionInProgress(
    val active: Boolean,
    val brand: @RawValue Any,
    val createdOn: @RawValue Any,
    val dateOfMonth: @RawValue Int,
    val daysOfWeek: @RawValue Any,
    val dbTimeZone: @RawValue Any,
    val endDate: @RawValue Any,
    val exeHeaderId: Int,
    val exeHistoryId: Int,
    val executionMode: @RawValue Any,
    val frequency: Int,
    val jenkinsJobId: @RawValue Any,
    val jobArn: String,
    val jobName: String,
    val jobStatus: Int,
    val modifiedOn: @RawValue Any,
    val nextDates: @RawValue Any,
    val nodeName: String,
    val nodeOs: String,
    val projectTypeId: Int,
    val repeatSchedule: Int,
    val runningLocation: Int,
    val startDate: String,
    val time: String,
    val updatedBy: @RawValue Any
) : Serializable