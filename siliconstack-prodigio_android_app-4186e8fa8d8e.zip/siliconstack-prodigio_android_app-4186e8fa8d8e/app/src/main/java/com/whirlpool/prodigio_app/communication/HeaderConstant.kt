package com.whirlpool.prodigio_app.communication

class HeaderConstant {

    companion object {
        fun requestHeaderLogin(): HashMap<String, String> {
            val param: HashMap<String, String> = HashMap<String, String>()
            param.put("Content-Type", "application/json")
//            param.put("Content-Length", "<calculated when request is sent>")
//            param.put("Host", "<calculated when request is sent>")
//            param.put("User-Agent", "PostmanRuntime/7.28.4")
//            param.put("Accept", "*/*")
//            param.put("Accept-Encoding", "gzip, deflate, br")
//            param.put("Connection", "keep-alive")
            return param
        }

        fun requestHeader(): HashMap<String, String> {
            val param: HashMap<String, String> = HashMap<String, String>()
            param.put("Host", "<calculated when request is sent>")
            param.put("User-Agent", "PostmanRuntime/7.28.4")
            param.put("Accept", "*/*")
            param.put("Accept-Encoding", "gzip, deflate, br")
            param.put("Connection", "keep-alive")
            return param
        }

        fun downloadRequestHeader(): HashMap<String, String> {
            val param: HashMap<String, String> = HashMap<String, String>()
            param.put("Host", "<calculated when request is sent>")
            param.put("User-Agent", "PostmanRuntime/7.28.4")
            param.put("Accept", "*/*")
            param.put("Accept", "application/octet-stream")
            param.put("Accept-Encoding", "gzip, deflate, br")
            param.put("Connection", "keep-alive")
            // param.put("Content-Type", "text/plain")

            return param
        }


    }
}