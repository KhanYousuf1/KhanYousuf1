package com.whirlpool.prodigio_app.view.adapter

import android.annotation.SuppressLint
import android.content.Intent
import android.os.CountDownTimer
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.Document
import com.whirlpool.prodigio_app.databinding.ItemDocumentBinding
import com.whirlpool.prodigio_app.databinding.ItemExecutionHistoryBinding
import com.whirlpool.prodigio_app.view.ScrWebviewDocument
import com.whirlpool.prodigio_app.view.fragments.FrgDocument

class DocumentAdapter(var context: FrgDocument) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var items: ArrayList<Document> = ArrayList<Document>()


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = DataBindingUtil.inflate<ItemDocumentBinding>(
            LayoutInflater.from(parent.context), R.layout.item_document,
            parent, false
        )
        return ItemHolder(binding)
    }

    @SuppressLint("NotifyDataSetChanged")
    fun setList(items: ArrayList<Document>) {
        this.items = items
        notifyDataSetChanged()
        Log.d(TAG, "setList: items : " + this.items.count())
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val doc = items[position]
        val viewHolder = holder as DocumentAdapter.ItemHolder
        viewHolder.binding.tvDocName.text = doc.documentName
        viewHolder.binding.cvView.tag = doc
        viewHolder.binding.cvView.setOnClickListener {
            val intent = Intent(context.requireActivity(), ScrWebviewDocument::class.java)
            intent.putExtra("url", doc.documentLink)
            context.startActivity(intent)
            viewHolder.binding.es.resetStatus()
        }
    }

    override fun getItemCount(): Int {
        return items.size
    }

    fun filteredList(filteredList: ArrayList<Document>) {
        items = filteredList
        notifyDataSetChanged()
    }

    inner class ItemHolder(val binding: ItemDocumentBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }


    companion object {
        private const val TAG = "DocumentAdapter"
    }
}