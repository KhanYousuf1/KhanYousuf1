package com.whirlpool.prodigio_app.view.adapter

import android.os.CountDownTimer
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.contentValuesOf
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.ExtentReportList
import com.whirlpool.prodigio_app.databinding.ItemDocumentBinding
import com.whirlpool.prodigio_app.databinding.ItemExecutionHistoryBinding
import com.whirlpool.prodigio_app.databinding.ItemExtentReportsBinding
import com.whirlpool.prodigio_app.view.dialoges.DlgExtentReport

class ExtentReportsAdapter(var context: DlgExtentReport, var items: ArrayList<ExtentReportList>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    lateinit var mListner: OnExtentReportItemClickListner

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = DataBindingUtil.inflate<ItemExtentReportsBinding>(
            LayoutInflater.from(parent.context), R.layout.item_extent_reports,
            parent, false
        )
        mListner = context
        return ItemHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = items[position]
        val viewHolder = holder as ItemHolder
        viewHolder.binding.tvSuiteId.text = item.testSuiteId.toString()
        viewHolder.binding.tvDateTime.text = item.executionDateTime
        viewHolder.binding.tvCountUp.text = item.passCount.toString()
        viewHolder.binding.tvCountDown.text = item.failCount.toString()
        viewHolder.binding.tvExtentReportName.text = "Report $position"
        viewHolder.binding.tvExtentReportName.tag = item
        viewHolder.binding.tvExtentReportName.setOnClickListener {
            val extentReportList = it.tag as ExtentReportList
            mListner.reportItemClicked(extentReportList)
        }

    }

    override fun getItemCount(): Int {
        return items.count()
    }

    inner class ItemHolder(val binding: ItemExtentReportsBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }

    interface OnExtentReportItemClickListner {
        fun reportItemClicked(extentReportList: ExtentReportList)
    }

    companion object {
        private val TAG = ExtentReportsAdapter::class.java.name
    }

}