package com.whirlpool.prodigio_app.view.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.ExecutionSchedule
import com.whirlpool.prodigio_app.communication.response.OfRecords
import com.whirlpool.prodigio_app.communication.response.OfRecordsSchedule
import com.whirlpool.prodigio_app.databinding.ItemExecutionHistoryBinding
import com.whirlpool.prodigio_app.databinding.ItemExecutionScheduledBinding
import com.whirlpool.prodigio_app.databinding.ItemProgressBinding
import com.whirlpool.prodigio_app.utils.CustomIntent
import com.whirlpool.prodigio_app.view.ScrExecutionHistorySub
import com.whirlpool.prodigio_app.view.ScrExecutionScheduled
import com.whirlpool.prodigio_app.view.ScrExecutionScheduledSub
import com.whirlpool.prodigio_app.view.ScrUpdateSchedule

class ExecutionScheduledSearchAdapter(var context: ScrExecutionScheduled) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var items = ArrayList<OfRecordsSchedule>()
    lateinit var listner: ExecutionScheduledAdapter.onScheduledItemClickListner

    //item type
    private val ITEM: Int = 0
    private val LOADING = 1

    private var isLoadingAdded = false
    private val retryPageLoad = false

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        var viewHolder: RecyclerView.ViewHolder? = null
        listner = context

        when (viewType) {
            ITEM -> {
                val binding = DataBindingUtil.inflate<ItemExecutionScheduledBinding>(
                    LayoutInflater.from(parent.context), R.layout.item_execution_scheduled,
                    parent, false
                )
                viewHolder = ItemHolder(binding)
            }
            LOADING -> {
                val binding = DataBindingUtil.inflate<ItemProgressBinding>(
                    LayoutInflater.from(parent.context), R.layout.item_progress,
                    parent, false
                )
                    viewHolder = LoadingViewHolder(binding)
            }
        }
        return viewHolder!!
    }

    @SuppressLint("NotifyDataSetChanged")
    fun setList(items: ArrayList<OfRecordsSchedule>) {
        this.items = items
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun setFilteredList(items: ArrayList<OfRecordsSchedule>) {
        this.items.clear()
        this.items = items
        notifyDataSetChanged()
    }

    fun removeItemByPosition(position: Int) {
        items.removeAt(position)
        notifyDataSetChanged()
    }


    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val execution = items[position]
        when (getItemViewType(position)) {
            ITEM -> {
                val viewHolder = holder as ExecutionScheduledSearchAdapter.ItemHolder
                viewHolder.binding.tvBrandName.text = execution.brand
                viewHolder.binding.tvTestExeNme.text = execution.jobName
                viewHolder.binding.tvNextExeDate.text = execution.nextDates[0]


                viewHolder.binding.cvMain.tag = execution
                viewHolder.binding.cvMain.setOnClickListener {
                    val execution1 = it.tag as OfRecordsSchedule
                    val intent = Intent(context, ScrExecutionScheduledSub::class.java)
                    intent.putExtra("OfRecordsSchedule", execution1)
                    context.startActivity(intent)
                }

                viewHolder.binding.cvEdit.tag = execution
                viewHolder.binding.cvEdit.setOnClickListener {
                    val execution2 = it.tag as OfRecordsSchedule
                    val intent = Intent(context, ScrUpdateSchedule::class.java)
                    intent.putExtra("OfRecordsSchedule", execution2)
                    context.startActivity(intent)
                    viewHolder.binding.es.resetStatus()
                }
                viewHolder.binding.cvDelete.tag = execution
                viewHolder.binding.cvDelete.setOnClickListener {
                    val schedule = it.tag as OfRecordsSchedule
                    listner.onItemScheduledItemCliked(schedule, position)
                    viewHolder.binding.es.resetStatus()
                }

            }

            LOADING -> {
                val loadingViewHolder = holder as ExecutionScheduledSearchAdapter.LoadingViewHolder
                /* if (retryPageLoad) {
                     loadingViewHolder.mErrorLayout.setVisibility(View.VISIBLE)
                     loadingViewHolder.mProgressBar.setVisibility(View.GONE)
                     loadingViewHolder.mErrorTxt.setText(
                        // if (errorMsg != null) errorMsg else context.getString(R.string.error_msg_unknown)
                     ""
                     )
                 } else {*/
                loadingViewHolder.binding.loadmoreErrorlayout.setVisibility(View.GONE)
                loadingViewHolder.binding.loadmoreProgress.setVisibility(View.VISIBLE)
                //}
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        val i = if (position == items.size - 1 && isLoadingAdded) LOADING else ITEM
        return i
    }

    override fun getItemCount(): Int {
        return items.count()
    }

    fun addLoadingFooter() {
        isLoadingAdded = true
        val nextDates = ArrayList<String>()
        add(
            OfRecordsSchedule(
                false,
                "",
                "",
                0,
                "",
                "",
                "",
                0,
                0,
                "",
                0,
                "",
                "",
                "",
                0,
                "",
                nextDates,
                "",
                "",
                0,
                0,
                0,
                "",
                "",
                "0"
            )
        )
    }

    fun add(r: OfRecordsSchedule?) {
        if (r != null) {
            items.add(r)
        }
        notifyItemInserted(items.size - 1)
    }


    @SuppressLint("NotifyDataSetChanged")
    fun addAll(item: ArrayList<OfRecordsSchedule>) {
        for (result in item) {
            add(result)
        }
        notifyDataSetChanged()
    }

    @SuppressLint("NotifyDataSetChanged")
    fun remove(position: Int) {
        items.removeAt(position)
        notifyDataSetChanged()
    }

    fun removeLoadingFooter() {
        isLoadingAdded = false
        val position: Int = items.size - 1
        val result = getItem(position)
        if (result != null) {
            items.removeAt(position)
            notifyItemRemoved(position)
        }
    }

    fun getItem(position: Int): OfRecordsSchedule? {
        return items.get(position)
    }


    inner class ItemHolder(val binding: ItemExecutionScheduledBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }

    inner class LoadingViewHolder(val binding: ItemProgressBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }



}