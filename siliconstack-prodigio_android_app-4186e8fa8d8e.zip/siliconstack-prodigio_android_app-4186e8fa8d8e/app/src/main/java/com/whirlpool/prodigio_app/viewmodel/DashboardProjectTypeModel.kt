package com.whirlpool.prodigio_app.viewmodel


data class DashboardProjectTypeModel(
    val projectType: String,
    val region: String,
    val brand: String,
    val product: String,
    val testSuit: String,
    val testCase: String,
    val testStep: String
)