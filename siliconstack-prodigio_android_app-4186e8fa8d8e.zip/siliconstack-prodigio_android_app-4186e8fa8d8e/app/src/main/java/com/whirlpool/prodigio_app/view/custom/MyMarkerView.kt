package com.whirlpool.prodigio_app.view.custom

import android.content.Context
import android.widget.TextView
import com.github.mikephil.charting.components.MarkerView
import com.github.mikephil.charting.data.CandleEntry
import com.github.mikephil.charting.highlight.Highlight
import com.github.mikephil.charting.utils.Utils
import com.github.mikephil.charting.utils.MPPointF
import android.provider.Telephony.Mms.Rate
import com.github.mikephil.charting.data.Entry

class MyMarkerView(context: Context?, layoutResource: Int) : MarkerView(context, layoutResource) {

    lateinit var tvContent: TextView

    override fun refreshContent(e: Entry, highlight: Highlight?) {

        if (e is CandleEntry) {
            val ce = e as CandleEntry
            val rate = ce.data
            val sDate: String = ""
            val sTime: String = ""
            val dRate: Double = 0.0
            tvContent.text =
                """Rate : $ 
Date: $sDate
Time : $sTime"""
        } else {
            val rate = e.getData()
            val sDate: String = ""
            val sTime: String = ""
            val dRate: Double = 0.0
            tvContent.text =
                """Rate : $ 
 Date : $sDate
Time : $sTime"""
        }

        super.refreshContent(e, highlight)
    }

    override fun getOffset(): MPPointF? {
        return MPPointF((-(width / 2)).toFloat(), (-height).toFloat())
    }

}

