package com.whirlpool.prodigio_app.view

import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.view.adapter.DashboardListItemAdapter
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.whirlpool.prodigio_app.communication.response.DashboarProjectType
import com.whirlpool.prodigio_app.databinding.*
import com.whirlpool.prodigio_app.viewmodel.DashboardProjectTypeModel
import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.utils.CustomToast
import com.whirlpool.prodigio_app.viewmodel.DashBoardViewModel
import com.whirlpool.prodigio_app.viewmodel.DashBoardViewModelFactory
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance

class ScrDashboardProjectType : AppCompatActivity(), KodeinAware,
    SwipeRefreshLayout.OnRefreshListener {

    private val TAG = ScrDashboardProjectType::class.java.name

    lateinit var binding: ActivityDashboardProjectTypeBinding
    lateinit var layoutTopbarbinding: LayoutTopBarBinding
    lateinit var noDataBindin: LayoutNoDataBinding
    lateinit var viewModel: DashBoardViewModel

    lateinit var adapter: DashboardListItemAdapter

    override val kodein by kodein()

    var from: String = "Mobile"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = resources.getColor(R.color.white)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            window.statusBarColor = Color.WHITE
        }
        val factory: DashBoardViewModelFactory by instance() // dependency injection
        viewModel = ViewModelProvider(this, factory).get(DashBoardViewModel::class.java)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_dashboard_project_type)

        init()
        getIntentData()
        registerClick()
        getProjectType()
    }

    fun getIntentData() {
        from = intent.getStringExtra("FROM")!!
        layoutTopbarbinding.tvToolBarTitle.setText("" + from)
    }

    fun init() {
        layoutTopbarbinding = binding.llToolBar
        //inti no data layout
        noDataBindin = binding.llNoData


        //init siprefresh
        binding.swipeRefreshLayout.setOnRefreshListener(this)
        binding.swipeRefreshLayout.setColorSchemeColors(
            ContextCompat.getColor(this, R.color.execution_all_jobs),
            ContextCompat.getColor(this, R.color.execution_history),
            ContextCompat.getColor(this, R.color.execution_in_progress),
            ContextCompat.getColor(this, R.color.execution_scheduled)
        )


        val linearLayoutManager = LinearLayoutManager(this)
        binding.recyclerView.setLayoutManager(linearLayoutManager)

        adapter = DashboardListItemAdapter(this, from)
        binding.recyclerView.setAdapter(adapter)
    }

    fun registerClick() {
        layoutTopbarbinding.llBack.setOnClickListener() {
            finish()
        }
    }


    fun getProjectType() {
        Coroutines.main {
            binding.swipeRefreshLayout.isRefreshing = true
            var res = viewModel.getDashboardCounts()
            Log.d(TAG, "getProjectType res : $res")
            Log.d(TAG, "getProjectType res : ${res.body()}")
            binding.swipeRefreshLayout.isRefreshing = false
            var item: ArrayList<DashboardProjectTypeModel> =
                ArrayList<DashboardProjectTypeModel>()
            if (res.isSuccessful) {
                var items: ArrayList<DashboarProjectType> =
                    res.body() as ArrayList<DashboarProjectType>

                item.add(
                    DashboardProjectTypeModel(
                        from,
                        "Region",
                        "Brand",
                        "Products",
                        "Test Suites",
                        "Test Cases",
                        "Test Steps"
                    )
                )

                items.forEach {
                    var projectType = it.projectType
                    var regionName = ""
                    var brandName = ""
                    var projectCount = 0
                    var suiteCount = 0
                    var caseCount = 0
                    var stepCount = 0

                    Log.d(TAG, "getProjectType: projectType : $projectType")
                    it.regionView.forEach {
                        regionName = it.regionName
                        it.brandView.forEach {
                            brandName = it.brandName
                            projectCount = it.projectCount
                            suiteCount = it.suiteCount
                            caseCount = it.caseCount
                            stepCount = it.stepCount

                            Log.d(TAG, "getProjectType: from : $from projectType : $projectType")
                            if (from.equals(projectType)) {
                                Log.d(
                                    TAG,
                                    "getProjectType: from inside if : $from projectType : $projectType"
                                )
                                item.add(
                                    DashboardProjectTypeModel(
                                        from,
                                        regionName,
                                        brandName,
                                        projectCount.toString(),
                                        suiteCount.toString(),
                                        caseCount.toString(),
                                        stepCount.toString()
                                    )
                                )
                            }
                        }
                    }
                }
                adapter.setList(item)
            } else {
                CustomToast.showToast(res.message())
            }
            showEmptyLayout()
        }
    }

    fun showEmptyLayout() {
        if (adapter.itemCount == 0 || adapter.itemCount == 1) {
            binding.llMain.visibility = View.GONE
            noDataBindin.llNoData.visibility = View.VISIBLE
        } else {
            binding.llMain.visibility = View.VISIBLE
            noDataBindin.llNoData.visibility = View.GONE
        }
    }

    override fun onRefresh() {
       getProjectType()
    }

}