package com.whirlpool.prodigio_app.communication.response

data class Brand (
    var brandId: Int,
    var brandCode: String,
    var brandName: String,
    var brandDesc: String,
    var regionId: Int,
    var regionCode: Int,
    var projectTypeName: String,
    var projectTypeId: Int,
    var userId: Int,
    var createdOn: String,
    var modifiedOn: String,
    var deleted: Boolean)