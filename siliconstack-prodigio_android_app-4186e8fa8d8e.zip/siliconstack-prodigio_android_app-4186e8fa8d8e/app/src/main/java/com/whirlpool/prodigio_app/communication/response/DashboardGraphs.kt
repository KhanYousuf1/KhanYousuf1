package com.whirlpool.prodigio_app.communication.response

import com.google.gson.annotations.SerializedName

class DashboardGraphs {

    data class GetDashboardCountsForTestExecutionTrendsRequest(
        @SerializedName("projectTypeId")
        var projectTypeId: Int?=null,
        @SerializedName("regionId")
        var regionId: Int?=null,
        @SerializedName("brandId")
        var brandId: String?=null,
        @SerializedName("projectName")
        var projectName: String?=null,
        @SerializedName("testSuiteName")
        var testSuiteName: String?=null,
        @SerializedName("testSuiteId")
        var testSuiteId: Int?=null,
        @SerializedName("profileId")
        var profileId: Int?=null,
        @SerializedName("platformId")
        var platformId: String?=null,
        @SerializedName("environment")
        var environment: String?=null,
        @SerializedName("startDate")
        var startDate: String?=null,
        @SerializedName("endDate")
        var endDate: String?=null,
    )

    data class GetDashboardCountsForTestExecutionTrendsResponse(
        @SerializedName("date")
        var date: String?=null,
        @SerializedName("unknown")
        var unknown: Int?=null,
        @SerializedName("passed")
        var passed: Int?=null,
        @SerializedName("failed")
        var failed: Int?=null,
        @SerializedName("total")
        var total: Int?=null,
        @SerializedName("executionTime")
        var executionTime: Int?=null,
        @SerializedName("meanExecutionTime")
        var meanExecutionTime: Int?=null,
        @SerializedName("projectName")
        var projectName: String?=null,
    )

    data class GetDashboardSuiteExeTimeProjectWiseRequest(
        @SerializedName("projectTypeId")
        var projectTypeId: Int?=null,
        @SerializedName("regionId")
        var regionId: Int?=null,
        @SerializedName("brandId")
        var brandId: String?=null,
        @SerializedName("projectNames")
        var projectNames: ArrayList<String>?=null,
        @SerializedName("platformId")
        var platformId: String?=null,
        @SerializedName("environment")
        var environment: String?=null,
        @SerializedName("startDate")
        var startDate: String?=null,
        @SerializedName("endDate")
        var endDate: String?=null,
    )

    data class GetDashboardSuiteExeTimeProjectWiseResponse(
        @SerializedName("date")
        var date: String?=null,
        @SerializedName("unknown")
        var unknown: Int?=null,
        @SerializedName("passed")
        var passed: Int?=null,
        @SerializedName("failed")
        var failed: Int?=null,
        @SerializedName("total")
        var total: Int?=null,
        @SerializedName("executionTime")
        var executionTime: Int?=null,
        @SerializedName("meanExecutionTime")
        var meanExecutionTime: Int?=null,
        @SerializedName("projectName")
        var projectName: String?=null,
    )

    data class GetDashboardCountsForTestExecutionTimeTrendsRequest(
        @SerializedName("projectTypeId")
        var projectTypeId: Int?=null,
        @SerializedName("regionId")
        var regionId: Int?=null,
        @SerializedName("brandId")
        var brandId: String?=null,
        @SerializedName("projectName")
        var projectName: String?=null,
        @SerializedName("testSuiteName")
        var testSuiteName: String?=null,
        @SerializedName("testSuiteId")
        var testSuiteId: Int?=null,
        @SerializedName("profileId")
        var profileId: Int?=null,
        @SerializedName("platformId")
        var platformId: String?=null,
        @SerializedName("environment")
        var environment: String?=null,
        @SerializedName("startDate")
        var startDate: String?=null,
        @SerializedName("endDate")
        var endDate: String?=null,
    )

    data class GetDashboardCountsForTestExecutionTimeTrendsResponse(
        @SerializedName("date")
        var date: String?=null,
        @SerializedName("unknown")
        var unknown: Int?=null,
        @SerializedName("passed")
        var passed: Int?=null,
        @SerializedName("failed")
        var failed: Int?=null,
        @SerializedName("total")
        var total: Int?=null,
        @SerializedName("executionTime")
        var executionTime: Int?=null,
        @SerializedName("meanExecutionTime")
        var meanExecutionTime: Float?=null,
        @SerializedName("projectName")
        var projectName: String?=null,
    )



    data class GetDashboardSuiteCountTrendRequest(
        @SerializedName("projectTypeId")
        var projectTypeId: Int?=null,
        @SerializedName("regionId")
        var regionId: Int?=null,
        @SerializedName("brandId")
        var brandId: String?=null,
        @SerializedName("projectNames")
        var projectNames: ArrayList<String>?=null,
        @SerializedName("projectName")
        var projectName: String?=null,
//        @SerializedName("testSuiteName")
//        var testSuiteName: String?=null,
//        @SerializedName("testSuiteId")
//        var testSuiteId: Int?=null,
//        @SerializedName("profileId")
//        var profileId: Int?=null,
        @SerializedName("platformId")
        var platformId: String?=null,
        @SerializedName("environment")
        var environment: String?=null,
        @SerializedName("startDate")
        var startDate: String?=null,
        @SerializedName("endDate")
        var endDate: String?=null,
    ){
        data class Project(
            @SerializedName("projectName")
            var projectName: String?=null,
        )
    }

    data class GetDashboardSuiteCountTrendResponse(
        @SerializedName("totalCount")
        var totalCount: Int?=null,
        @SerializedName("passPercentage")
        var passPercentage: Float?=null,
        @SerializedName("failPercentage")
        var failPercentage: Float?=null,
        @SerializedName("notExecPercentage")
        var notExecPercentage: Float?=null
    )


    data class GetDashboardSuiteMonthlyExeStatusRequest(
        @SerializedName("projectTypeId")
        var projectTypeId: Int?=null,
        @SerializedName("regionId")
        var regionId: Int?=null,
        @SerializedName("brandId")
        var brandId: String?=null,
//        @SerializedName("projectName")
//        var projectName: String?=null,
//        @SerializedName("testSuiteName")
//        var testSuiteName: String?=null,
//        @SerializedName("testSuiteId")
//        var testSuiteId: Int?=null,
//        @SerializedName("profileId")
//        var profileId: Int?=null,
        @SerializedName("platformId")
        var platformId: String?=null,
        @SerializedName("environment")
        var environment: String?=null,
        @SerializedName("startDate")
        var startDate: String?=null,
        @SerializedName("endDate")
        var endDate: String?=null,
    )

    data class GetDashboardSuiteMonthlyExeStatusResponse(
        @SerializedName("suiteMonthly")
        var suiteMonthly: List<SuiteMonthly>?=null,

    ){
        data class SuiteMonthly(
            @SerializedName("regionName")
            var regionName: String?=null,
            @SerializedName("brandName")
            var brandName: String?=null,
            @SerializedName("total")
            var total: Int?=null,
            @SerializedName("passed")
            var passed: Int?=null,
            @SerializedName("failed")
            var failed: Int?=null,
            @SerializedName("unknown")
            var unknown: Int?=null,
        )
    }
}