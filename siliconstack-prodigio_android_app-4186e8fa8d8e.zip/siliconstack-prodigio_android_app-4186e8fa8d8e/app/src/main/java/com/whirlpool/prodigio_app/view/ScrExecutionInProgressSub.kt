package com.whirlpool.prodigio_app.view

import android.content.Intent
import android.database.DatabaseUtils
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Html
import android.util.Log
import android.view.View
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.R.color.colorPrimary
import com.whirlpool.prodigio_app.R.color.grey5
import com.whirlpool.prodigio_app.communication.response.ExecutionInProgress
import com.whirlpool.prodigio_app.communication.response.OfRecords
import com.whirlpool.prodigio_app.communication.response.OfRecordsSchedule
import com.whirlpool.prodigio_app.communication.response.ScheduleDetails
import com.whirlpool.prodigio_app.databinding.ActivityScrExecutionInProgressBinding
import com.whirlpool.prodigio_app.databinding.ActivityScrExecutionInProgressSubBinding
import com.whirlpool.prodigio_app.databinding.LayoutNoDataBinding
import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.utils.CustomDialoge
import com.whirlpool.prodigio_app.utils.CustomToast
import com.whirlpool.prodigio_app.view.adapter.ExecutionHistoryAdapter
import com.whirlpool.prodigio_app.view.adapter.ExecutionInProgressAdapter
import com.whirlpool.prodigio_app.view.adapter.ExecutionInProgressScheduleDetailsAdapter
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModel
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModelFactory
import org.json.JSONException
import org.json.JSONObject
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance

class ScrExecutionInProgressSub : AppCompatActivity(), KodeinAware {

    private val TAG = ScrExecutionInProgressSub::class.java.name

    override val kodein by kodein()

    lateinit var binding: ActivityScrExecutionInProgressSubBinding
    lateinit var noDataBindin: LayoutNoDataBinding
    lateinit var viewModel: ExecutionViewModel

    lateinit var execuInProg: ExecutionInProgress

    lateinit var adapter: ExecutionInProgressScheduleDetailsAdapter


    var isScheduleListLoaded = false
    var isJenkinLogLoaded = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = resources.getColor(R.color.white)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            window.statusBarColor = Color.WHITE
        }
        val factory: ExecutionViewModelFactory by instance() // dependency injection
        viewModel = ViewModelProvider(this, factory).get(ExecutionViewModel::class.java)
        binding =
            DataBindingUtil.setContentView(this, R.layout.activity_scr_execution_in_progress_sub)

        initUI()
        registerClicks()
        getIntentData()
        switchPage(1)
    }

    /*fun getIntentData() {
        val intent = intent.extras
        execuInProg = intent?.getSerializable("ExecutionInProgress") as ExecutionInProgress
        Log.d(
            TAG,
            "getIntentData: exeHeaderId : ${execuInProg.exeHeaderId} exeHistoryId : ${execuInProg.exeHistoryId} "
        )
    }*/

    fun initUI() {
        //inti no data layout
        noDataBindin = binding.llNoData

        //init recyclerview
        val layoutManager =
            LinearLayoutManager(this, RecyclerView.VERTICAL, false)
        adapter =
            ExecutionInProgressScheduleDetailsAdapter(
                this
            )
        binding.rvInprogressSchedule.layoutManager = layoutManager
        binding.rvInprogressSchedule.adapter = adapter
        binding.rvInprogressSchedule.adapter?.notifyDataSetChanged()


    }

    fun registerClicks() {
        binding.llBack.setOnClickListener { finish() }
        binding.llExecutionConsole.setOnClickListener { switchPage(1) }
        binding.llLogConsole.setOnClickListener { switchPage(2) }
    }


    fun getIntentData() {
        val intent = intent.extras
        execuInProg = intent?.getSerializable("ExecutionInProgress") as ExecutionInProgress
        Log.d(
            TAG,
            "getIntentData: exeHeaderId : ${execuInProg.exeHeaderId} exeHistoryId : ${execuInProg.exeHistoryId} "
        )//added this
    }




    fun switchPage(value: Int) {
        if (value == 1) {
            binding.llContentExecutionConsole.visibility = View.VISIBLE
            binding.llContentLogConsole.visibility = View.GONE

            binding.tvExecutionConsole.setTextColor(ContextCompat.getColor(this, colorPrimary))
            binding.tvLogConsole.setTextColor(ContextCompat.getColor(this, grey5))

            if (!isScheduleListLoaded) {
                isScheduleListLoaded = true
                getScheduleListDeatils()
            }

        } else {
            binding.llContentExecutionConsole.visibility = View.GONE
            binding.llContentLogConsole.visibility = View.VISIBLE

            binding.tvExecutionConsole.setTextColor(ContextCompat.getColor(this, grey5))
            binding.tvLogConsole.setTextColor(ContextCompat.getColor(this, colorPrimary))

            if (!isJenkinLogLoaded) {
                isJenkinLogLoaded = true
                getJenkinBuildLog()
            }
        }
    }


    fun getJenkinBuildLog() {
        Coroutines.main {
            Log.d(TAG, "reisterClicks: jenkins job id : " + execuInProg.jenkinsJobId.toString())
            try {
                CustomDialoge.showDialog(this, "Downloading...")
                val params = HashMap<String?, String?>()
                params.put("jenkinsJobId", execuInProg.jenkinsJobId.toString())
                val res = viewModel.downloadExecutionLogFiles(params)
                Log.d(TAG, "downloadExecution: res : $res")
                Log.d(TAG, "downloadExecution: res body: ${res.body()}")
                CustomDialoge.closeDialog(this)

                if (res.isSuccessful) {
                    try {
                        val respo = JSONObject(res.body().toString())

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                            binding.tvJenkinLog.setText(
                                Html.fromHtml(
                                    respo.getString("Message"),
                                    Html.FROM_HTML_MODE_LEGACY
                                )
                            );
                        } else {
                            binding.tvJenkinLog.setText(Html.fromHtml(respo.getString("Message")));
                        }
                        //  binding.tvJenkinLog.text = respo.getString("Message")

                    } catch (e: JSONException) {
                        e.printStackTrace()
                        Log.d(TAG, "reisterClicks: JSONException : " + e.message)
                    }
                } else {
                    CustomToast.showToast(res.message())
                }
            } catch (e: Exception) {
                e.printStackTrace()
                CustomDialoge.closeDialog(this)
                CustomToast.showToast("Jenkins Jod Id not found")
            }
        }
    }

    fun getScheduleListDeatils() {
        Coroutines.main {
            Log.d(TAG, "reisterClicks: jenkins job id : " + execuInProg.jenkinsJobId.toString())
            try {
                CustomDialoge.showDialog(this, "Downloading...")
                val params = HashMap<String?, String?>()
                params.put("exeHeaderId", execuInProg.exeHeaderId.toString())
                params.put("exeHistoryId", execuInProg.exeHistoryId.toString())
                val res = viewModel.getScheduleListDeatils(params)
                Log.d(TAG, "getScheduleListDeatils: res : $res")
                Log.d(TAG, "getScheduleListDeatils: res body: ${res.body()}")
                CustomDialoge.closeDialog(this)
                if (res.isSuccessful) {
                    try {
                        val list = res.body() as ArrayList<ScheduleDetails>
                        adapter.setList(list)
                    } catch (e: JSONException) {
                        e.printStackTrace()
                        Log.d(TAG, "getScheduleListDeatils: JSONException : " + e.message)
                    }
                } else {
                    CustomToast.showToast(res.message())
                }
            } catch (e: Exception) {
                e.printStackTrace()
                CustomDialoge.closeDialog(this)
                CustomToast.showToast("exeHeaderId or exeHistoryId not found")
            }
        }
    }


}
    