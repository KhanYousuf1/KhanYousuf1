package com.whirlpool.prodigio_app.pagination

interface PaignationAdapterCallback {
    fun retryPageLoad()
}