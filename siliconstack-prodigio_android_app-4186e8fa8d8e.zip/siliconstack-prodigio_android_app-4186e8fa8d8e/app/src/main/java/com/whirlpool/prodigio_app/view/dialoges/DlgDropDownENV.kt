package com.whirlpool.prodigio_app.view.dialoges

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.deishelon.roundedbottomsheet.RoundedBottomSheetDialogFragment
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.databinding.*
import com.whirlpool.prodigio_app.view.adapter.*

class DlgDropDownENV() : RoundedBottomSheetDialogFragment() {

    lateinit var binding: DlgDropDownEnvBinding
    lateinit var mListner: BottomSheetDlgENVListner
    lateinit var items:  ArrayList<String>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding =
            DataBindingUtil.inflate(inflater, R.layout.dlg_drop_down_env, container, false)
        val rootView = binding.root
        init()
        reisterClicks()
        return rootView
    }

    fun init() {
        binding.rvOptions.apply {
            layoutManager =
                LinearLayoutManager(requireContext(), RecyclerView.VERTICAL, false)

            adapter = DropDownENVAdapter(items,mListner)
            binding.rvOptions.adapter = adapter
            binding.rvOptions.adapter?.notifyDataSetChanged()
        }
    }

    private fun reisterClicks() {
        binding.ivSearch.setOnClickListener {
            dismiss()
        }
    }


    interface BottomSheetDlgENVListner {
        fun onENVSelected(type: Int)
    }


}