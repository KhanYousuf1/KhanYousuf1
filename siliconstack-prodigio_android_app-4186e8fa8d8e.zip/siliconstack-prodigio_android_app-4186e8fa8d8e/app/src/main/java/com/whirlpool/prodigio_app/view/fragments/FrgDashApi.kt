package com.whirlpool.prodigio_app.view.fragments

class FrgDashApi {
}