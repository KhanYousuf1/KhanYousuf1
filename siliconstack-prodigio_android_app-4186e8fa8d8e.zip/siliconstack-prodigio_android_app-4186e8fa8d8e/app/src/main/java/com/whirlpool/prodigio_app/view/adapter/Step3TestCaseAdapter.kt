package com.whirlpool.prodigio_app.view.adapter

import android.os.CountDownTimer
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.Brand
import com.whirlpool.prodigio_app.databinding.ItemDocumentBinding
import com.whirlpool.prodigio_app.databinding.ItemDropDownOptionsBinding
import com.whirlpool.prodigio_app.databinding.ItemExecutionHistoryBinding
import com.whirlpool.prodigio_app.databinding.ItemStep3DataSetAndTestCasesBinding
import com.whirlpool.prodigio_app.view.dialoges.DlgDropDownBrand

class Step3TestCaseAdapter(
    var items: ArrayList<String>
) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TAG = "Step3TestCaseAdapter"
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = DataBindingUtil.inflate<ItemStep3DataSetAndTestCasesBinding>(
            LayoutInflater.from(parent.context), R.layout.item_step_3_data_set_and_test_cases,
            parent, false
        )
        return ItemHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val viewHolder = holder as ItemHolder
        var item = items.get(position)

    }

    override fun getItemCount(): Int {
        return items.count()
    }

    inner class ItemHolder(val binding: ItemStep3DataSetAndTestCasesBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }


}