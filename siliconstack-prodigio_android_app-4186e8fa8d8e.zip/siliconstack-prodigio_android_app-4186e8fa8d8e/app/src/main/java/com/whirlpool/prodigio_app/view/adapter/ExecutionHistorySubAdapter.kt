package com.whirlpool.prodigio_app.view.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import androidx.transition.AutoTransition
import androidx.transition.TransitionManager
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.ExecutionHistorySubItem
import com.whirlpool.prodigio_app.databinding.ItemExecutionHistorySubBinding

class ExecutionHistorySubAdapter(
    var context: Context,
    var items: ArrayList<ExecutionHistorySubItem>
) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = DataBindingUtil.inflate<ItemExecutionHistorySubBinding>(
            LayoutInflater.from(parent.context), R.layout.item_execution_history_sub,
            parent, false
        )
        return ItemHolder(binding)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val execution = items[position]
        val viewHolder = holder as ExecutionHistorySubAdapter.ItemHolder

        viewHolder.binding.tvTextExeId.text = execution.exeHeaderId.toString()
        viewHolder.binding.tvExecutionName.text = execution.jobName
        viewHolder.binding.tvExecutionMode.text = execution.executionMode
        viewHolder.binding.tvStartDateTime.text = execution.startDate + " | " + execution.startTime
        viewHolder.binding.tvEndDateTime.text = execution.endDate + " | " + execution.endTime
        //viewHolder.binding.tvDuration.text = execution.
        //viewHolder.binding.tvUser.text = execution.
        viewHolder.binding.tvCountDown.text = execution.failCount.toString()
        viewHolder.binding.tvCountUp.text = execution.passCount.toString()


        viewHolder.binding.llPlusMinus.setOnClickListener {
            if (viewHolder.binding.llHiddenView.visibility == View.GONE) {
                TransitionManager.beginDelayedTransition(
                    viewHolder.binding.cvMain,
                    AutoTransition()
                )
                viewHolder.binding.llHiddenView.visibility = View.VISIBLE
                viewHolder.binding.ivPlusMinus.setImageResource(R.drawable.ic_baseline_remove_24)
            } else {
                TransitionManager.beginDelayedTransition(
                    viewHolder.binding.cvMain,
                    AutoTransition()
                )
                viewHolder.binding.llHiddenView.visibility = View.GONE
                viewHolder.binding.ivPlusMinus.setImageResource(R.drawable.ic_baseline_add_24)
            }
        }
    }

    override fun getItemCount(): Int {
        return items.count()
    }

    inner class ItemHolder(val binding: ItemExecutionHistorySubBinding) :
        RecyclerView.ViewHolder(binding.root) {

    }


}