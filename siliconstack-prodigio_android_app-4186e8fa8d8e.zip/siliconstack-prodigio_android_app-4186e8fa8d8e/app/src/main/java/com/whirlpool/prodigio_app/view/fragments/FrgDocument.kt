package com.whirlpool.prodigio_app.view.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.whirlpool.prodigio_app.AppApplication
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.Constant
import com.whirlpool.prodigio_app.communication.response.Document
import com.whirlpool.prodigio_app.databinding.FrgDocumentBinding
import com.whirlpool.prodigio_app.databinding.LayoutNoDataBinding
import com.whirlpool.prodigio_app.storage.UserData
import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.utils.CustomIntent
import com.whirlpool.prodigio_app.utils.CustomToast
import com.whirlpool.prodigio_app.view.ScrHome
import com.whirlpool.prodigio_app.view.ScrLogin
import com.whirlpool.prodigio_app.view.adapter.DocumentAdapter
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModel
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModelFactory
import org.kodein.di.Kodein
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance

class FrgDocument : Fragment(), KodeinAware, SwipeRefreshLayout.OnRefreshListener{

    private val TAG = FrgDocument::class.java.name

    lateinit var binding: FrgDocumentBinding
    lateinit var noDataBindin: LayoutNoDataBinding

    override val kodein: Kodein by kodein(AppApplication.appContext)

    lateinit var viewModel: ExecutionViewModel

    var list = ArrayList<Document>()

    private val adapter = DocumentAdapter(this)

    companion object {
        fun getInstance(): FrgDocument {
            return FrgDocument()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val factory: ExecutionViewModelFactory by instance() // dependency injection
        viewModel = ViewModelProvider(this, factory).get(ExecutionViewModel::class.java)

        binding = DataBindingUtil.inflate(
            inflater, R.layout.frg_document, container, false
        )
        val rootview = binding.root
        initUi()
        setSearchBar()
        callgetAllDocument()
        return rootview
    }


    fun initUi() {
        noDataBindin = binding.llNoData

        ///swipe refresh layout
        binding.swipeRefreshLayout.setOnRefreshListener(this)
        binding.swipeRefreshLayout.setColorSchemeColors(
            ContextCompat.getColor(requireActivity(), R.color.execution_all_jobs),
            ContextCompat.getColor(requireActivity(), R.color.execution_history),
            ContextCompat.getColor(requireActivity(), R.color.execution_in_progress),
            ContextCompat.getColor(requireActivity(), R.color.execution_scheduled)
        )

        val layoutManager =
            LinearLayoutManager(requireContext(), RecyclerView.VERTICAL, false)
        binding.rvDocument.adapter = adapter
        binding.rvDocument.layoutManager = layoutManager
        binding.rvDocument.adapter?.notifyDataSetChanged()
    }

    fun setSearchBar() {
        //init toolbar
        binding.llSearch.setOnClickListener {
            binding.llSearchContainer.visibility = View.VISIBLE
            binding.llToolBarOther.visibility = View.GONE
        }
        binding.llClose.setOnClickListener {
            if (binding.etSearch.text.toString().isNullOrBlank()) {
                binding.llSearchContainer.visibility = View.GONE
                binding.llToolBarOther.visibility = View.VISIBLE
            } else binding.etSearch.text = null
        }

        binding.etSearch.doAfterTextChanged {
            val text = it.toString()
            Log.d(TAG, "setUpToolBar: doAfterTextChanged from fragmgent: $text")
            filter(text)
        }
    }

    fun callgetAllDocument() {
        binding.swipeRefreshLayout.isRefreshing = true
        Coroutines.main {
            val res = viewModel.getAllDocument()
            Log.d(TAG, "callgetAllDocument: respo : " + res)
            Log.d(TAG, "callgetAllDocument: respo : " + res.body())
            binding.swipeRefreshLayout.isRefreshing = false
            if (res.isSuccessful) {
                val tempList = res.body() as ArrayList<Document>
                if(list.size>0){
                    list.clear()
                }
                list.addAll(tempList)
                Log.d(TAG, "callgetAllDocument: list size : " + list.size)
                adapter.setList(list)
            } else {
                CustomToast.showToast(res.message())
                if (res.code() == Constant.RES_ERROR_CODE_FORBIDDEn) {
                    val userData = UserData.getInstance()
                    userData?.clearData()
                    CustomIntent.startActivity(requireActivity(), ScrLogin::class.java)
                }
            }
            showEmptyLayout()
        }
    }

    fun showEmptyLayout() {
        if (adapter.itemCount == 0) {
            binding.llMain.visibility = View.GONE
            noDataBindin.llNoData.visibility = View.VISIBLE
            binding.cvHeader.visibility = View.GONE
        } else {
            binding.llMain.visibility = View.VISIBLE
            noDataBindin.llNoData.visibility = View.GONE
            binding.cvHeader.visibility = View.VISIBLE
        }
    }

    override fun onRefresh() {
        callgetAllDocument()
    }

    fun filter(text: String) {
        Log.d(TAG, "filter: value : $text list size : " + list.size)
        if (!text.isNullOrBlank()) {
            val arrayList: ArrayList<Document> = ArrayList<Document>()
            for (item: Document in list) {
                if (item.documentName.lowercase().contains(text.lowercase())) {
                    Log.d(TAG, "filter: search for doc name : ${item.documentName} searched Text : ${text.lowercase()}")
                    arrayList.add(item)
                }
            }
            Log.d(TAG, "filter: arrayListSize : " + arrayList.size)
            Log.d(TAG, "filter: arrayList : " + arrayList.toString())
            adapter.filteredList(arrayList)
        } else {
            adapter.setList(list)
        }
    }


}