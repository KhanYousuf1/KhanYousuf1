package com.whirlpool.prodigio_app.communication.response

data class User(
    var profileId: Int,
    var userId: String,
    var userName: String,
    var userRoleId: Int,
    var loggedInUserId: Int,
    var userRoleName: String
)