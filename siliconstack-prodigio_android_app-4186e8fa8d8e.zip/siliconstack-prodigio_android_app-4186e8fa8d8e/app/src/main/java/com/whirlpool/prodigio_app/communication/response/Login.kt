package com.whirlpool.prodigio_app.communication.response

data class Login(
    val token: String,
    val userDetail: UserDetail,
    val userId: String
)

data class UserDetail(
    val roleId: Int,
    val roleName: String,
    val userId: Int,
    val userName: String
)