package com.whirlpool.prodigio_app.view.fragments

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.whirlpool.prodigio_app.AppApplication
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.communication.response.*
import com.whirlpool.prodigio_app.databinding.FrgRunJobStep1Binding
import com.whirlpool.prodigio_app.databinding.FrgRunJobStep3Binding
import com.whirlpool.prodigio_app.databinding.LayoutRunJobCounterHeaderBinding
import com.whirlpool.prodigio_app.databinding.LayoutRunJobNextPreviousButtonsBinding
import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.utils.CustomDialoge
import com.whirlpool.prodigio_app.utils.CustomToast
import com.whirlpool.prodigio_app.view.adapter.DropDownExecutionModeAdapter
import com.whirlpool.prodigio_app.view.adapter.Step3TestCaseAndDataSetCounterAdapter
import com.whirlpool.prodigio_app.view.dialoges.*
import com.whirlpool.prodigio_app.viewmodel.DashboardGraphViewModel
import com.whirlpool.prodigio_app.viewmodel.DashboardGraphViewModelFactory
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModel
import com.whirlpool.prodigio_app.viewmodel.ExecutionViewModelFactory
import org.kodein.di.Kodein
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance
import java.util.*
import kotlin.collections.ArrayList

class FrgRunJobStep3 : Fragment(), KodeinAware {

    private val TAG = FrgExecution::class.java.name

    override val kodein: Kodein by kodein(AppApplication.appContext)

    lateinit var viewModel: DashboardGraphViewModel

    var counter: MutableLiveData<ArrayList<String>> =
        MutableLiveData<ArrayList<String>>()

    lateinit var binding: FrgRunJobStep3Binding
    lateinit var counterHeaderBindig: LayoutRunJobCounterHeaderBinding
    lateinit var nextPreviuosButtonsBinding: LayoutRunJobNextPreviousButtonsBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        val factory: DashboardGraphViewModelFactory by instance()  // dependency injection
        viewModel =
            ViewModelProvider(this, factory).get(DashboardGraphViewModel::class.java)

        binding = DataBindingUtil.inflate(
            inflater, R.layout.frg_run_job_step_3, container, false
        )
        counterHeaderBindig = binding.llCounterHeader
        nextPreviuosButtonsBinding = binding.llRunJobsButtons
        val rootview = binding.root
        initUI()
        initCounterHeaderAndBottomButtoms()
        registerClicks()
        return rootview
    }


    fun initUI() {
        val array = ArrayList<String>()
        array.add("1")
        array.add("2")
        array.add("3")
        array.add("4")
        counter.value = array
        counter.observe(requireActivity(), {
            it?.let {
                binding.rvDatasetAndTestcase.apply {
                    layoutManager =
                        LinearLayoutManager(requireContext(), RecyclerView.HORIZONTAL, false)
                    adapter = Step3TestCaseAndDataSetCounterAdapter(it)
                    binding.rvDatasetAndTestcase.adapter = adapter
                    binding.rvDatasetAndTestcase.adapter?.notifyDataSetChanged()
                }
            }
        })
    }


    fun initCounterHeaderAndBottomButtoms() {
        //counter header
        counterHeaderBindig.ivArrowLeft.setOnClickListener {
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.fl_container, FrgRunJobStep2())
                .commit()
        }
        counterHeaderBindig.ivArrowRight.setOnClickListener {
        }
        counterHeaderBindig.tvCounter.text = "3"
        counterHeaderBindig.tvHeader.text = "Select Data set & test cases"

        //bottom buttons
        nextPreviuosButtonsBinding.cvPrevious.setOnClickListener {
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.fl_container, FrgRunJobStep2())
                .commit()
        }
        nextPreviuosButtonsBinding.cvNext.setOnClickListener {


        }

    }

    fun registerClicks() {

    }

    override fun onResume() {
        super.onResume()
        Coroutines.main {

        }
    }


}