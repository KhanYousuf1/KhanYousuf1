package com.whirlpool.prodigio_app.communication.response

data class ProductName(
    var projectName : String,
    var projectKey : String
)