package com.whirlpool.prodigio_app.view

import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
import com.whirlpool.prodigio_app.storage.UserData
import com.whirlpool.prodigio_app.utils.CustomIntent
import com.whirlpool.prodigio_app.R

class ScrSplash : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = resources.getColor(R.color.white)
            window.decorView.systemUiVisibility = SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            window.statusBarColor = Color.WHITE
        }
        setContentView(R.layout.activity_scr_splash)
    }


    override fun onResume() {
        super.onResume()
        startNext()
    }

    fun startNext() {
        Handler(Looper.getMainLooper()).postDelayed({
            val userData = UserData.getInstance()
            if (userData?.isRememberMe() == true && userData.getTOKEN() != null) {
                CustomIntent.startActivity(this, ScrHome::class.java, true)
            } else {
                CustomIntent.startActivity(this, ScrLogin::class.java, true)
            }
        }, 3000)
    }

}