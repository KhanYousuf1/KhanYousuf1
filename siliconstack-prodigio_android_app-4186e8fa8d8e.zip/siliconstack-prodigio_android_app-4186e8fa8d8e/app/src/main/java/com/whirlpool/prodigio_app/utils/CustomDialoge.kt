package com.whirlpool.prodigio_app.utils

import android.app.Activity
import android.app.ProgressDialog
import com.whirlpool.prodigio_app.R
import java.lang.Exception

class CustomDialoge {

    companion object {
        private var dlg: ProgressDialog? = null

        fun showDialog(activity: Activity?, message: String?) {
            if (activity == null) {
                return
            }
            try {
                activity.runOnUiThread(Runnable {
                    try {
                        if (dlg != null) {
                            closeDialog(activity)
                        }
                        dlg = ProgressDialog(activity, R.style.progress_style)
                        dlg!!.setMessage(message)
                        dlg!!.setCanceledOnTouchOutside(false)
                        dlg!!.show()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                })
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }


        fun closeDialog(activity: Activity?) {
            if (activity == null) {
                return
            }
            try {
                activity.runOnUiThread(Runnable {
                    try {
                        if (dlg != null) {
                            dlg!!.dismiss()
                            dlg = null
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                })
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}