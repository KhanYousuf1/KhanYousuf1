package com.whirlpool.prodigio_app.view.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.databinding.ItemDashboardListBinding
import com.whirlpool.prodigio_app.viewmodel.DashboardProjectTypeModel
import com.whirlpool.prodigio_app.view.ScrDashboardProjectType

class DashboardListItemAdapter(var context: ScrDashboardProjectType, var projectType: String) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var items: ArrayList<DashboardProjectTypeModel> = ArrayList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = DataBindingUtil.inflate<ItemDashboardListBinding>(
            LayoutInflater.from(parent.context), R.layout.item_dashboard_list,
            parent, false
        )
        return ItemHolder(binding)
    }

    fun setList(items: ArrayList<DashboardProjectTypeModel>) {
        this.items = items
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val exeInProg = items[position]
        val viewHolder = holder as ItemHolder
        try {
            Log.d(
                TAG,
                "onBindViewHolder: projectType: if $projectType exeInPro projectType: ${exeInProg.brand}"
            )

            if (position == 0) {
                viewHolder.binding.tvRegion.setTextColor(
                    ContextCompat.getColor(
                        context,
                        R.color.dark_blue
                    )
                )
                viewHolder.binding.tvBrand.setTextColor(
                    ContextCompat.getColor(
                        context,
                        R.color.dark_blue
                    )
                )
                viewHolder.binding.tvProducts.setTextColor(
                    ContextCompat.getColor(
                        context,
                        R.color.dark_blue
                    )
                )
                viewHolder.binding.tvTestCases.setTextColor(
                    ContextCompat.getColor(
                        context,
                        R.color.dark_blue
                    )
                )
                viewHolder.binding.tvTestSteps.setTextColor(
                    ContextCompat.getColor(
                        context,
                        R.color.dark_blue
                    )
                )
                viewHolder.binding.tvTestSuites.setTextColor(
                    ContextCompat.getColor(
                        context,
                        R.color.dark_blue
                    )
                )
            } else {
                viewHolder.binding.tvRegion.setTextColor(
                    ContextCompat.getColor(
                        context,
                        R.color.black
                    )
                )
                viewHolder.binding.tvBrand.setTextColor(
                    ContextCompat.getColor(
                        context,
                        R.color.black
                    )
                )
                viewHolder.binding.tvProducts.setTextColor(
                    ContextCompat.getColor(
                        context,
                        R.color.black
                    )
                )
                viewHolder.binding.tvTestCases.setTextColor(
                    ContextCompat.getColor(
                        context,
                        R.color.black
                    )
                )
                viewHolder.binding.tvTestSteps.setTextColor(
                    ContextCompat.getColor(
                        context,
                        R.color.black
                    )
                )
                viewHolder.binding.tvTestSuites.setTextColor(
                    ContextCompat.getColor(
                        context,
                        R.color.black
                    )
                )
            }

            viewHolder.binding.tvRegion.text = exeInProg.region
            viewHolder.binding.tvBrand.text = exeInProg.brand
            viewHolder.binding.tvProducts.text = exeInProg.product
            viewHolder.binding.tvTestCases.text = exeInProg.testCase
            viewHolder.binding.tvTestSteps.text = exeInProg.testStep
            viewHolder.binding.tvTestSuites.text = exeInProg.testSuit
        } catch (e: IndexOutOfBoundsException) {
            Log.d(TAG, "onBindViewHolder: indexOutOfBound : ${e.message}")
        }
    }

    override fun getItemCount(): Int {
        return items.count()
    }

    inner class ItemHolder(val binding: ItemDashboardListBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }

    companion object {
        private const val TAG = "DocumentAdapter"
    }
}