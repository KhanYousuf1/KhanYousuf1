package com.whirlpool.prodigio_app.view.fragments

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.whirlpool.prodigio_app.AppApplication
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.databinding.FrgTestSuitePassBinding
import com.whirlpool.prodigio_app.viewmodel.TestSuitePassViewModel
import com.whirlpool.prodigio_app.viewmodel.TestSuitePassViewModelFactory
import org.kodein.di.Kodein
import org.kodein.di.KodeinAware
import org.kodein.di.android.kodein
import org.kodein.di.generic.instance

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.Legend.LegendForm;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.components.YAxis.AxisDependency;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ColorTemplate;
import androidx.core.content.ContextCompat

import android.graphics.drawable.Drawable

import android.graphics.DashPathEffect

import android.provider.Telephony.Mms.Rate
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.github.mikephil.charting.utils.Utils
import com.whirlpool.prodigio_app.communication.response.*
import com.whirlpool.prodigio_app.utils.Coroutines
import com.whirlpool.prodigio_app.utils.CustomDialoge
import com.whirlpool.prodigio_app.utils.CustomToast
import com.whirlpool.prodigio_app.view.dialoges.*
import com.whirlpool.prodigio_app.viewmodel.DashboardGraphViewModel
import com.whirlpool.prodigio_app.viewmodel.DashboardGraphViewModelFactory
import java.util.*
import kotlin.collections.ArrayList


class FrgTestSuitePass : Fragment(), KodeinAware,
    DlgDropDownProjectType.BottomSheetDlgProjectTypeListner,
    DlgDropDownRegion.BottomSheetDlgRegionListner,
    DlgDropDownBrand.BottomSheetDlgBrandListner,
    DlgDropDownProductName.BottomSheetDlgProductNameListner,
    DlgDropDownTestSuite.BottomSheetDlgTestSuiteListner,
    DlgDropDownPlatform.BottomSheetDlgPlatformListner,
    DlgFromDate.BottomSheetDlgFromDateListner,
    DlgToDate.BottomSheetDlgToDateListner,
    DlgDropDownENV.BottomSheetDlgENVListner {


    private val TAG = FrgTestSuitePass::class.java.name

    override val kodein: Kodein by kodein(AppApplication.appContext)

    lateinit var viewModel: DashboardGraphViewModel
    lateinit var binding: FrgTestSuitePassBinding

    //bottomSheetDialoge
    lateinit var bottomDlgProjectType: DlgDropDownProjectType
    lateinit var bottomDlgRegion: DlgDropDownRegion
    lateinit var bottomDlgBrand: DlgDropDownBrand
    lateinit var bottomDlgProductName: DlgDropDownProductName
    lateinit var bottomDlgTestSuite: DlgDropDownTestSuite
    lateinit var bottomDlgPlatform: DlgDropDownPlatform
    lateinit var bottomDlgEnv: DlgDropDownENV
    lateinit var bottomDlgAll: DlgDropDownAll
    lateinit var bottomDlgFromDate: DlgFromDate
    lateinit var bottomDlgToDate: DlgToDate

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val factory: DashboardGraphViewModelFactory by instance()  // dependency injection
        viewModel = ViewModelProvider(this, factory).get(DashboardGraphViewModel::class.java)

        binding = DataBindingUtil.inflate(
            inflater, R.layout.frg_test_suite_pass, container, false
        )
        val rootview = binding.root
        init()
        registerClicks()
        return rootview
    }


    // run button validate
    /*fun doValidate() {
        val project_type = binding.etProjectType.text.toString()
        val region = binding.etRegion.text.toString()
        // val brand = binding.etBrand.text.toString()
        val product_name = binding.etProductName.text.toString()
        val test_suite = binding.etTestSuite.text.toString()
        val platform = binding.etPlatform.text.toString()
        val env = binding.etEnv.text.toString()
        //val all = binding.etAll.text.toString()
        val fromDate = binding.etFromDate.text.toString()
        val toDate = binding.etToDate.text.toString()

        if (project_type.isEmpty() || project_type.isNullOrBlank()) {
            binding.tvErrorProjectType.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorProjectType.visibility = View.GONE
        }

        if (region.isEmpty() || region.isNullOrBlank()) {
            binding.tvErrorRegion.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorRegion.visibility = View.GONE
        }

        *//* if (brand.isEmpty() || brand.isNullOrBlank()) {
             binding.tvErrorBrand.visibility = View.VISIBLE
             return
         } else {
             binding.tvErrorBrand.visibility = View.GONE
         }*//*

        if (product_name.isEmpty() || product_name.isNullOrBlank()) {
            binding.tvErrorProductName.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorProductName.visibility = View.GONE
        }

        if (test_suite.isEmpty() || test_suite.isNullOrBlank()) {
            binding.tvErrorSuiteName.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorSuiteName.visibility = View.GONE
        }

        if (platform.isEmpty() || platform.isNullOrBlank()) {
            binding.tvErrorPlatform.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorPlatform.visibility = View.GONE
        }

        if (env.isEmpty() || env.isNullOrBlank()) {
            binding.tvErrorEnv.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorEnv.visibility = View.GONE
        }

        *//*if (all.isEmpty() || all.isNullOrBlank()) {
            binding.tvErrorAll.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorAll.visibility = View.GONE
        }*//*

        if (fromDate.isEmpty() || fromDate.isNullOrBlank()) {
            binding.tvErrorFromDate.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorFromDate.visibility = View.GONE
        }

        if (toDate.isEmpty() || toDate.isNullOrBlank()) {
            binding.tvErrorToDate.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorToDate.visibility = View.GONE
        }

        CustomToast.showToast("Call Filter API")

    }*/

    private val fillColor = Color.argb(150, 51, 181, 229)
    private fun init() {

        binding.lineChart.visibility = View.GONE
        binding.linearLayoutGraphInfo.visibility = View.GONE
        binding.linearLayoutMapError.visibility = View.VISIBLE
        Coroutines.main {
            getAllProjects()
//            getAllUsers()
        }
        Observe()

        binding.lineChart.setBackgroundColor(Color.parseColor("#FAFAFA"));
//         binding.lineChart.setOnChartGestureListener(this)
//         binding.lineChart.setOnChartValueSelectedListener(this)
        binding.lineChart.setDrawGridBackground(false)

        // no description text

        // no description text
        binding.lineChart.getDescription().setEnabled(false)

        // enable touch gestures

        // enable touch gestures
        binding.lineChart.setTouchEnabled(true)

        // enable scaling and dragging

        // enable scaling and dragging
        binding.lineChart.setDragEnabled(true)
        binding.lineChart.setScaleEnabled(false)

        // if disabled, scaling can be done on x- and y-axis separately

        // if disabled, scaling can be done on x- and y-axis separately
        binding.lineChart.setPinchZoom(false)

        // create a custom MarkerView (extend MarkerView) and specify the layout
        // to use for it

        // create a custom MarkerView (extend MarkerView) and specify the layout
        // to use for it
//        val mv = MyMarkerView(activity, R.layout.custom_marker_view)
//        mv.setChartView(mChart) // For bounds control

//        mChart.setMarker(mv) // Set the marker to the chart


        // add data

        // add data
        setData(binding.lineChart)

        binding.lineChart.animateX(2500)
        binding.lineChart.getXAxis().setAxisMinimum(0F)
//        minAmount = sMin as Float
//        maxAmount = sMax as Float
        /*if (cryptoCurrency.getsCurrencyName().equals("Bitcoin")) {
            mChart.getAxisLeft().setAxisMinimum(minAmount - 100);
            mChart.getAxisLeft().setAxisMaximum(maxAmount + 100);
        } else if (cryptoCurrency.getsCurrencyName().equals("Litecoin")) {
            mChart.getAxisLeft().setAxisMinimum(minAmount - 40);
            mChart.getAxisLeft().setAxisMaximum(maxAmount + 40);
        } else {
            mChart.getAxisLeft().setAxisMinimum(minAmount - 1);
            mChart.getAxisLeft().setAxisMaximum(maxAmount + 1);
        }*/
        /*if (cryptoCurrency.getsCurrencyName().equals("Bitcoin")) {
            mChart.getAxisLeft().setAxisMinimum(minAmount - 100);
            mChart.getAxisLeft().setAxisMaximum(maxAmount + 100);
        } else if (cryptoCurrency.getsCurrencyName().equals("Litecoin")) {
            mChart.getAxisLeft().setAxisMinimum(minAmount - 40);
            mChart.getAxisLeft().setAxisMaximum(maxAmount + 40);
        } else {
            mChart.getAxisLeft().setAxisMinimum(minAmount - 1);
            mChart.getAxisLeft().setAxisMaximum(maxAmount + 1);
        }*/
        binding.lineChart.getXAxis().setEnabled(false)
        binding.lineChart.getAxisLeft().setEnabled(true)
        binding.lineChart.getAxisRight().setEnabled(false)
        binding.lineChart.getAxisLeft().setTextColor(Color.parseColor("#000000"))
        binding.lineChart.getXAxis().setTextColor(Color.parseColor("#000000"))
        binding.lineChart.getLegend().setTextColor(Color.RED)
        binding.lineChart.legend.isEnabled = false
        binding.lineChart.setDrawBorders(false)

        // add data
//        setData(100, 60F)

        binding.lineChart.invalidate()

//        initBottomDialoge()
    }

    fun initBottomDialoge() {
//        bottomDlgProjectType = DlgDropDownProjectType()
//        bottomDlgProjectType.mListner = this


    }

    private fun setData(mChart: LineChart) {

        val values = ArrayList<Entry>()
        //        values.add(new Entry(0, 0, getResources().getDrawable(R.drawable.star)));
        for (i in 0..40) {
            val Result: Float = (Math.random() * 5).toFloat()
            values.add(Entry(i.toFloat(), Result, null, null))
        }
        val lineDataSet: LineDataSet
        if (mChart.data != null && mChart.data.dataSetCount > 0) {
            lineDataSet = mChart.data.getDataSetByIndex(0) as LineDataSet
            lineDataSet.values = values
            mChart.data.notifyDataChanged()
            mChart.notifyDataSetChanged()
        } else {
            // create a dataset and give it a type
            lineDataSet = LineDataSet(
                values,
                "Rate : "
            )
            lineDataSet.setDrawIcons(false)
            lineDataSet.enableDashedLine(10f, 0f, 0f)
            lineDataSet.enableDashedHighlightLine(10f, 0f, 0f)
            lineDataSet.color = Color.parseColor("#1890FF")
            lineDataSet.setCircleColor(Color.GREEN)
            lineDataSet.lineWidth = 2f
            lineDataSet.circleRadius = 1f
            lineDataSet.setDrawCircleHole(false)
            lineDataSet.valueTextSize = 0f
            lineDataSet.valueTextColor = Color.RED
            lineDataSet.setDrawFilled(true)
            lineDataSet.formLineWidth = 0f
            lineDataSet.formLineDashEffect = DashPathEffect(floatArrayOf(10f, 5f), 0f)
            lineDataSet.formSize = 15f
            if (Utils.getSDKInt() >= 18) {
                // fill drawable only supported on api level 18 and above
                val drawable =
                    ContextCompat.getDrawable(requireContext(), R.drawable.map_background)
                lineDataSet.fillDrawable = drawable
            } else {
                lineDataSet.fillColor = Color.parseColor("#91D5FF")
            }
            /*if (Utils.getSDKInt() >= 18) {
                // fill drawable only supported on api level 18 and above
                Drawable drawable = ContextCompat.getDrawable(this, R.drawable.fade_blue);
//                lineDataSet.setFillDrawable(drawable);
            } else {
                lineDataSet.setFillColor(Color.parseColor("#3bc3ea"));
            }*/
            val dataSets = ArrayList<ILineDataSet>()
            dataSets.add(lineDataSet) // add the datasets

            // create a data object with the datasets
            val data = LineData(dataSets)

            // set data
            mChart.data = data
        }
    }


    private fun setData(count: Int, range: Float) {
        val values1: ArrayList<Entry> = ArrayList()
        for (i in 0 until count) {
            val `val` = (Math.random() * (range / 2f)).toFloat() + 50
            values1.add(Entry(i.toFloat(), `val`))
        }
        val values2: ArrayList<Entry> = ArrayList()
        for (i in 0 until count) {
            val `val` = (Math.random() * range).toFloat() + 450
            values2.add(Entry(i.toFloat(), `val`))
        }
        val values3: ArrayList<Entry> = ArrayList()
        for (i in 0 until count) {
            val `val` = (Math.random() * range).toFloat() + 500
            values3.add(Entry(i.toFloat(), `val`))
        }
        val set1: LineDataSet
        val set2: LineDataSet
        val set3: LineDataSet
        if (binding.lineChart.getData() != null &&
            binding.lineChart.getData().getDataSetCount() > 0
        ) {
            set1 = binding.lineChart.getData().getDataSetByIndex(0) as LineDataSet
            set2 = binding.lineChart.getData().getDataSetByIndex(1) as LineDataSet
            set3 = binding.lineChart.getData().getDataSetByIndex(2) as LineDataSet
            set1.values = values1
            set2.values = values2
            set3.values = values3
            binding.lineChart.getData().notifyDataChanged()
            binding.lineChart.notifyDataSetChanged()
        } else {
            // create a dataset and give it a type
            set1 = LineDataSet(values1, "DataSet 1")
            set1.axisDependency = AxisDependency.LEFT
            set1.color = ColorTemplate.getHoloBlue()
            set1.setCircleColor(Color.WHITE)
            set1.lineWidth = 2f
            set1.circleRadius = 3f
            set1.fillAlpha = 65
            set1.fillColor = ColorTemplate.getHoloBlue()
            set1.highLightColor = Color.rgb(244, 117, 117)
            set1.setDrawCircleHole(false)
            //set1.setFillFormatter(new MyFillFormatter(0f));
            //set1.setDrawHorizontalHighlightIndicator(false);
            //set1.setVisible(false);
            //set1.setCircleHoleColor(Color.WHITE);

            // create a dataset and give it a type
            set2 = LineDataSet(values2, "DataSet 2")
            set2.axisDependency = AxisDependency.RIGHT
            set2.color = Color.RED
            set2.setCircleColor(Color.WHITE)
            set2.lineWidth = 2f
            set2.circleRadius = 3f
            set2.fillAlpha = 65
            set2.fillColor = Color.RED
            set2.setDrawCircleHole(false)
            set2.highLightColor = Color.rgb(244, 117, 117)
            //set2.setFillFormatter(new MyFillFormatter(900f));
            set3 = LineDataSet(values3, "DataSet 3")
            set3.axisDependency = AxisDependency.RIGHT
            set3.color = Color.YELLOW
            set3.setCircleColor(Color.WHITE)
            set3.lineWidth = 2f
            set3.circleRadius = 3f
            set3.fillAlpha = 65
            set3.fillColor = ColorTemplate.colorWithAlpha(Color.YELLOW, 200)
            set3.setDrawCircleHole(false)
            set3.highLightColor = Color.rgb(244, 117, 117)

            // create a data object with the data sets
            val data = LineData(set1, set2, set3)
            data.setValueTextColor(Color.WHITE)
            data.setValueTextSize(9f)

            // set data
            binding.lineChart.setData(data)
        }
    }

    //bottom dialoe interface ==============================================================================================================

    /*private fun init() {
        val cartesian: Cartesian = AnyChart.cartesian()
        cartesian.animation(true)

        cartesian.title("")

        cartesian.yScale().stackMode(ScaleStackMode.VALUE)

        val scalesLinear: Linear = Linear.instantiate()
        scalesLinear.minimum(0.0)
        scalesLinear.maximum(3000.0)
        scalesLinear.ticks("{ interval: 500 }")

        val extraXAxis = cartesian.xAxis(1.0)
        extraXAxis.orientation(Orientation.LEFT)
            .scale(scalesLinear)
        extraXAxis.labels()
            .padding(0.0, 0.0, 0.0, 5.0)
            .format("{%Value}")

        val extraYAxis = cartesian.yAxis(1.0)
        extraYAxis.orientation(Orientation.BOTTOM)
            .scale(scalesLinear)

        var labels =extraYAxis.labels();
        labels.enabled(false);


        val data: MutableList<DataEntry> = ArrayList()
        data.add(CustomDataEntry("P1", 96.5, 440, 1200, 1600, 2900))
        data.add(CustomDataEntry("P2", 77.1, 794, 1124, 1724, 1800))
        data.add(CustomDataEntry("P3", 73.2, 726, 1006, 1806, 1904))
        data.add(CustomDataEntry("P4", 61.1, 441, 1021, 1621, 2040))
        data.add(CustomDataEntry("P5", 70.0, 800, 1500, 1700, 1850))
        data.add(CustomDataEntry("P6", 60.7, 507, 1007, 1907, 2400))
        data.add(CustomDataEntry("P7", 62.1, 401, 921, 1821, 2005))
        data.add(CustomDataEntry("P8", 75.1, 671, 971, 1671, 2000))
        data.add(CustomDataEntry("P9", 80.0, 980, 1080, 1880, 2200))
        data.add(CustomDataEntry("P10", 54.1, 541, 1041, 1641, 1900))
        data.add(CustomDataEntry("P11", 51.3, 813, 1113, 1913, 2170))
        data.add(CustomDataEntry("P12", 59.1, 691, 1091, 1691, 2680))

        val set = Set.instantiate()
        set.data(data)
        val lineData = set.mapAs("{ x: 'x', value: 'value' }")
        val column1Data = set.mapAs("{ x: 'x', value: 'value2' }")
        val column2Data = set.mapAs("{ x: 'x', value: 'value3' }")
        val column3Data = set.mapAs("{ x: 'x', value: 'value4' }")
        val column4Data = set.mapAs("{ x: 'x', value: 'value5' }")
        cartesian.addSeries(set)
//        var label = cartesian.get

//        cartesian.crosshair(true)
//        val line = cartesian.line(lineData)
//        line.yScale(scalesLinear)

        cartesian.column(column1Data).color("#B7EB8F")
        cartesian.column(column2Data).color("#FFE58F")
        cartesian.column(column3Data).color("#91D5FF")
        cartesian.column(column4Data).color("#1890FF")

        binding.anyChartView.setChart(cartesian)
    }

    private class CustomDataEntry internal constructor(
        x: String?,
        value: Number?,
        value2: Number?,
        value3: Number?,
        value4: Number?,
        value5: Number?
    ) :
        ValueDataEntry(x, value) {
        init {
            setValue("value2", value2)
            setValue("value3", value3)
            setValue("value4", value4)
            setValue("value5", value5)
        }
    }*/


    fun Observe() {
        projectTypesObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgProjectType = DlgDropDownProjectType(it, this)
                bottomDlgProjectType.mListner = this
            }
        })

        regionObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgRegion = DlgDropDownRegion()
                bottomDlgRegion.items = it
                bottomDlgRegion.mListner = this

                if (bottomDlgRegion != null && !bottomDlgRegion.isVisible) {
                    bottomDlgRegion.show(parentFragmentManager, TAG)
                }
            }
        })

        brandObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgBrand = DlgDropDownBrand()
                bottomDlgBrand.items = it
                bottomDlgBrand.mListner = this
                if (bottomDlgBrand != null && !bottomDlgBrand.isVisible) {
                    bottomDlgBrand.show(parentFragmentManager, TAG)
                }
            }
        })
        productNameObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgProductName = DlgDropDownProductName()
                bottomDlgProductName.items = it
                bottomDlgProductName.mListner = this
                if (bottomDlgProductName != null && !bottomDlgProductName.isVisible) {
                    bottomDlgProductName.show(parentFragmentManager, TAG)
                }
            }
        })
        testSuitObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgTestSuite = DlgDropDownTestSuite()
                bottomDlgTestSuite.items = it
                bottomDlgTestSuite.mListner = this
                if (bottomDlgTestSuite != null && !bottomDlgTestSuite.isVisible) {
                    bottomDlgTestSuite.show(parentFragmentManager, TAG)
                }
            }
        })
        platformObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgPlatform = DlgDropDownPlatform()
                bottomDlgPlatform.items = it
                bottomDlgPlatform.mListner = this
                if (bottomDlgPlatform != null && !bottomDlgPlatform.isVisible) {
                    bottomDlgPlatform.show(parentFragmentManager, TAG)
                }
            }
        })

        envObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgEnv = DlgDropDownENV()
                bottomDlgEnv.items = it
                bottomDlgEnv.mListner = this
                if (bottomDlgEnv != null && !bottomDlgEnv.isVisible) {
                    bottomDlgEnv.show(parentFragmentManager, TAG)
                }
            }
        })

        /*userObservable.observe(requireActivity(), {
            it?.let {
                bottomDlgAll = DlgDropDownAll()
                bottomDlgAll.items = it
                bottomDlgAll.mListner = this
                if (bottomDlgAll!=null&& !bottomDlgAll.isVisible) {
                    bottomDlgAll.show(parentFragmentManager, TAG)
                }
            }
        })*/
    }

    var projectTypesObservable: MutableLiveData<ArrayList<ProjectType>> =
        MutableLiveData<ArrayList<ProjectType>>()
    var regionObservable: MutableLiveData<ArrayList<Region>> = MutableLiveData<ArrayList<Region>>()
    var brandObservable: MutableLiveData<ArrayList<Brand>> = MutableLiveData<ArrayList<Brand>>()
    var productNameObservable: MutableLiveData<ArrayList<ProductName>> =
        MutableLiveData<ArrayList<ProductName>>()
    var testSuitObservable: MutableLiveData<ArrayList<TestSuit>> =
        MutableLiveData<ArrayList<TestSuit>>()
    var platformObservable: MutableLiveData<ArrayList<Platform>> =
        MutableLiveData<ArrayList<Platform>>()
    var envObservable: MutableLiveData<ArrayList<String>> = MutableLiveData<ArrayList<String>>()
    var userObservable: MutableLiveData<ArrayList<User>> = MutableLiveData<ArrayList<User>>()

    suspend fun getAllProjects() {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllProjectType()
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            projectTypesObservable.value = res.body() as ArrayList<ProjectType>
            Log.d(TAG, "getAllProjects: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllProjects: Error : ")
        }
    }


    suspend fun getAllRegionsByProject(projectTypeId: Int) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllRegionsByProject(projectTypeId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            regionObservable.value = res.body() as ArrayList<Region>
            Log.d(TAG, "getAllRegionsByProject: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllRegionsByProject: Error : ${res.body()} ")
        }
    }

    suspend fun getAllBrands(regionId: Int) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllBrands(regionId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            brandObservable.value = res.body() as ArrayList<Brand>
            Log.d(TAG, "getAllBrands: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllBrands: Error : ${res.body()} ")
        }
    }


    suspend fun getAllProductNames(
        brandId: Int,
        projectTypeId: Int,
        regionId: Int
    ) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllProductNames(brandId, projectTypeId, regionId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            productNameObservable.value = res.body() as ArrayList<ProductName>
            Log.d(TAG, "getAllProductNames: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllProductNames: Error : ${res.body()} ")
        }
    }


    suspend fun getTestSuiteNameByProjectName(projectName: String) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getTestSuiteNameByProjectName(projectName)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            testSuitObservable.value = res.body() as ArrayList<TestSuit>
            Log.d(TAG, "getTestSuiteNameByProjectName: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getTestSuiteNameByProjectName: Error : ${res.body()} ")
        }
    }

    suspend fun getAllPlatform(projectTypeId: Int) {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllPlatform(projectTypeId)
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            platformObservable.value = res.body() as ArrayList<Platform>
            Log.d(TAG, "getAllPlatform: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllPlatform: Error : ${res.body()} ")
        }
    }

    suspend fun getAllUsers() {
        CustomDialoge.showDialog(context as Activity?, "Loading...")
        val res = viewModel.getAllUsers()
        if (res.isSuccessful) {
            CustomDialoge.closeDialog(context as Activity?)
            userObservable.value = res.body() as ArrayList<User>
            Log.d(TAG, "getAllUsers: ${res.body()!!.size}")
        } else {
            CustomDialoge.closeDialog(context as Activity?)
            Log.d(TAG, "getAllUsers: Error : ${res.body()} ")
        }
    }


    fun registerClicks() {

        binding.llProjectType.setOnClickListener {
            if (this::bottomDlgProjectType.isInitialized) {
                if (bottomDlgProjectType != null) {
                    bottomDlgProjectType.show(parentFragmentManager, TAG)
                }
            }
        }
        binding.llRegion.setOnClickListener {
            if (selectedProjectType != null) {
                binding.tvErrorProjectType.visibility = View.GONE
                Coroutines.main {
                    getAllRegionsByProject(selectedProjectType!!.projectTypeId)
                }
            } else {
                binding.tvErrorProjectType.visibility = View.VISIBLE
            }
//            bottomDlgRegion.show(parentFragmentManager, TAG)
        }
        binding.cvBrand.setOnClickListener {
            if (selectedRegion != null) {
                binding.tvErrorRegion.visibility = View.GONE
                Coroutines.main {
                    getAllBrands(selectedRegion!!.regionId)
                }
            } else {
                binding.tvErrorRegion.visibility = View.VISIBLE
            }
//            bottomDlgBrand.show(parentFragmentManager, TAG)
        }
        binding.llProoductName.setOnClickListener {
            if (selectedProjectType != null && selectedBrand != null && selectedRegion != null) {
                binding.tvErrorProjectType.visibility = View.GONE
                binding.tvErrorRegion.visibility = View.GONE
                binding.tvErrorBrand.visibility = View.GONE
                Coroutines.main {
                    getAllProductNames(
                        selectedBrand!!.brandId,
                        selectedProjectType!!.projectTypeId,
                        selectedRegion!!.regionId
                    )
                }
            } else {
                if (selectedProjectType == null) {
                    binding.tvErrorProjectType.visibility = View.VISIBLE
                }
                if (selectedRegion == null) {
                    binding.tvErrorRegion.visibility = View.VISIBLE
                }
                if (selectedBrand == null) {
                    binding.tvErrorBrand.visibility = View.VISIBLE
                }
            }
//            bottomDlgRegion.show(parentFragmentManager, TAG)
        }/*
        binding.llTestSuite.setOnClickListener {
            if (selectedProductName != null) {
                binding.tvErrorProductName.visibility = View.GONE
                Coroutines.main {
                    getTestSuiteNameByProjectName(selectedProductName!!.projectName)
                }
            } else {
                binding.tvErrorProductName.visibility = View.VISIBLE
            }
        }*/
        binding.llPlatform.setOnClickListener {
            if (selectedProjectType != null) {
                binding.tvErrorProjectType.visibility = View.GONE
                Coroutines.main {
                    getAllPlatform(selectedProjectType!!.projectTypeId)
                }
            } else {
                binding.tvErrorProjectType.visibility = View.VISIBLE
            }
        }

        binding.llEnv.setOnClickListener {
            var list: ArrayList<String> = arrayListOf()
            list.add("ENV")
            list.add("STG")
            list.add("DEV")
            list.add("Prod")
            list.add("QA")
            envObservable.value = list
//            bottomDlgEnv.show(parentFragmentManager, TAG)
        }
        /*binding.llUsers.setOnClickListener {
            Coroutines.main {
                getAllUsers()
            }
//            bottomDlgAll.show(parentFragmentManager, TAG)
        }*/
        binding.llFrom.setOnClickListener {
            var calendarMax = Calendar.getInstance()
            bottomDlgFromDate = DlgFromDate(this, calendarMax, null)
            bottomDlgFromDate.show(parentFragmentManager, TAG)
//            bottomDlgFromDate.setMaxDate(calendar.time.time)
        }
        binding.llTo.setOnClickListener {
            if (calendarFrom != null) {
                binding.tvErrorFromDate.visibility = View.GONE
                var calendarMax = Calendar.getInstance()
                bottomDlgToDate = DlgToDate(this, calendarMax, calendarFrom)
                bottomDlgToDate.show(parentFragmentManager, TAG)
            } else {
                binding.tvErrorFromDate.visibility = View.VISIBLE
            }
//            bottomDlgFromDate.setMaxDate(calendar.time.time)
        }

        binding.btRun.setOnClickListener {
            doValidate()
        }
    }

    // run button validate
    fun doValidate() {
        val project_type = binding.etProjectType.text.toString()
        val region = binding.etRegion.text.toString()
        val brand = binding.etBrand.text.toString()
        val product_name = binding.etProductName.text.toString()
//        val test_suite = binding.etTestSuite.text.toString()
        val platform = binding.etPlatform.text.toString()
        val env = binding.etEnv.text.toString()
        val fromDate = binding.etFromDate.text.toString()
        val toDate = binding.etToDate.text.toString()

        if (project_type.isEmpty() || project_type.isNullOrBlank()) {
            binding.tvErrorProjectType.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorProjectType.visibility = View.GONE
        }

        if (region.isEmpty() || region.isNullOrBlank()) {
            binding.tvErrorRegion.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorRegion.visibility = View.GONE
        }

        if (brand.isEmpty() || brand.isNullOrBlank()) {
            binding.tvErrorBrand.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorBrand.visibility = View.GONE
        }

        if (product_name.isEmpty() || product_name.isNullOrBlank()) {
            binding.tvErrorProductName.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorProductName.visibility = View.GONE
        }

        /*if (test_suite.isEmpty() || test_suite.isNullOrBlank()) {
            binding.tvErrorSuiteName.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorSuiteName.visibility = View.GONE
        }*/

        if (platform.isEmpty() || platform.isNullOrBlank()) {
            binding.tvErrorPlatform.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorPlatform.visibility = View.GONE
        }

        if (env.isEmpty() || env.isNullOrBlank()) {
            binding.tvErrorEnv.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorEnv.visibility = View.GONE
        }



        if (fromDate.isEmpty() || fromDate.isNullOrBlank()) {
            binding.tvErrorFromDate.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorFromDate.visibility = View.GONE
        }

        if (toDate.isEmpty() || toDate.isNullOrBlank()) {
            binding.tvErrorToDate.visibility = View.VISIBLE
            return
        } else {
            binding.tvErrorToDate.visibility = View.GONE
        }

//        CustomToast.showToast("Call Filter API")

    }

    //bottom dialoe interface ==============================================================================================================

    var selectedProjectType: ProjectType? = null
    var selectedRegion: Region? = null
    var selectedBrand: Brand? = null
    var selectedProductName: ProductName? = null
    var selectedTestSuite: TestSuit? = null
    var selectedPlatform: Platform? = null
    var selectedEnv: String? = null
    var selectedUser: User? = null

    override fun onProjectTypeSelected(type: Int) {
        selectedProjectType = projectTypesObservable.value!!.get(type)
        binding.etProjectType.setText(selectedProjectType!!.projectTypeName)
        bottomDlgProjectType.dismiss()
    }

    override fun onRegionSelected(type: Int) {
        selectedRegion = regionObservable.value!!.get(type)
        binding.etRegion.setText(selectedRegion!!.regionName)
        bottomDlgRegion.dismiss()
    }

    override fun onBrandSelected(type: Int) {
        selectedBrand = brandObservable.value!!.get(type)
        binding.etBrand.setText(selectedBrand!!.brandName)
        bottomDlgBrand.dismiss()
    }

    override fun onProductNameSelected(type: Int) {
        selectedProductName = productNameObservable.value!!.get(type)
        binding.etProductName.setText(selectedProductName!!.projectName)
        bottomDlgProductName.dismiss()
    }

    override fun onTestSuiteSelected(type: Int) {
        selectedTestSuite = testSuitObservable.value!!.get(type)
//        binding.etTestSuite.setText(selectedTestSuite!!.testSuiteName)
        bottomDlgTestSuite.dismiss()
    }

    override fun onPlatformSelected(type: Int) {
        selectedPlatform = platformObservable.value!!.get(type)
        binding.etPlatform.setText(selectedPlatform!!.platformName)
        bottomDlgPlatform.dismiss()
    }

    override fun onENVSelected(type: Int) {
        selectedEnv = envObservable.value!!.get(type)
        binding.etEnv.setText(selectedEnv!!)
        bottomDlgEnv.dismiss()
    }


    override fun onFromDateSelected(date: String, calendar: Calendar) {
        calendarFrom = calendar
        binding.etFromDate.setText("${date}")
    }

    override fun onToDateSelected(date: String, calendar: Calendar) {
        calendarTo = calendar
        binding.etToDate.setText("${date}")
    }

    var calendarFrom: Calendar? = null
    var calendarTo: Calendar? = null


}