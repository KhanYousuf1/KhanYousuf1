package com.whirlpool.prodigio_app.viewmodel

import androidx.lifecycle.ViewModel
import com.whirlpool.prodigio_app.communication.response.Login
import com.whirlpool.prodigio_app.repository.Repository
import com.whirlpool.prodigio_app.utils.CustomToast.Companion.showToast
import retrofit2.Response

class RunJobViewModel(
    val repository: Repository,
) : ViewModel() {


}