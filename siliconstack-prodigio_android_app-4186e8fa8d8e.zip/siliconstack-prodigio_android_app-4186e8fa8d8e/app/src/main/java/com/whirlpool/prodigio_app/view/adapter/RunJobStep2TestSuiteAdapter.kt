package com.whirlpool.prodigio_app.view.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.whirlpool.prodigio_app.R
import com.whirlpool.prodigio_app.databinding.ItemDashboardListBinding
import com.whirlpool.prodigio_app.databinding.ItemRunJobStep2TestSuiteBinding
import com.whirlpool.prodigio_app.viewmodel.DashboardProjectTypeModel
import com.whirlpool.prodigio_app.view.ScrDashboardProjectType
import com.whirlpool.prodigio_app.view.fragments.FrgRunJobStep2

class RunJobStep2TestSuiteAdapter(var context: FrgRunJobStep2, var projectType: String) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var items: ArrayList<String> = ArrayList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = DataBindingUtil.inflate<ItemRunJobStep2TestSuiteBinding>(
            LayoutInflater.from(parent.context), R.layout.item_run_job_step_2_test_suite,
            parent, false
        )
        return ItemHolder(binding)
    }

    fun setList(items: ArrayList<String>) {
        this.items = items
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val exeInProg = items[position]
        val viewHolder = holder as ItemHolder
        try {
            Log.d(
                TAG,
                "onBindViewHolder: projectType: if $projectType exeInPro projectType: ${exeInProg}"
            )

            if (position == 0) {
                viewHolder.binding.content.setCardBackgroundColor(
                    ContextCompat.getColor(
                        context.requireActivity(),
                        R.color.light_blue
                    ))
            }



            viewHolder.binding.cbExecute.text = exeInProg
            viewHolder.binding.tvTestSuiteName.text = exeInProg
            viewHolder.binding.tvAppliance.text = exeInProg
            viewHolder.binding.tvTestCase.text = exeInProg
        } catch (e: IndexOutOfBoundsException) {
            Log.d(TAG, "onBindViewHolder: indexOutOfBound : ${e.message}")
        }
    }

    override fun getItemCount(): Int {
        return items.count()
    }

    inner class ItemHolder(val binding: ItemRunJobStep2TestSuiteBinding) :
        RecyclerView.ViewHolder(binding.root) {
    }

    companion object {
        private const val TAG = "DocumentAdapter"
    }
}